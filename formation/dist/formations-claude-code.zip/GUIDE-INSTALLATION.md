---
title: "Guide complet — Claude Code et formations"
subtitle: "Installation, configuration, usage, parler à Claude"
author: "Formations Claude Code FR"
date: "2026"
---

# Guide complet — Claude Code et formations

Document de référence à remettre à chaque apprenant. Couvre l'installation, la configuration, l'usage, et **comment parler efficacement à Claude Code**.

> **Note de conversion PDF** : ce fichier est en Markdown. Pour le convertir en PDF :
> ```bash
> # Avec pandoc (recommandé)
> pandoc GUIDE-INSTALLATION.md -o GUIDE.pdf --pdf-engine=xelatex --toc --number-sections
>
> # Ou avec md-to-pdf (npm)
> npx md-to-pdf GUIDE-INSTALLATION.md
> ```

---

# Partie 1 — Avant de commencer

## 1.1 Qui est cette formation pour ?

Tu codes déjà (en JS, Python, Go, Rust ou autre). Tu utilises ou tu veux utiliser Claude Code en série pour développer plus vite, mieux, et sans ajouter de dette technique.

Tu n'as pas besoin d'être senior. Tu as besoin d'être **honnête** : avec toi-même sur ce que tu comprends, et avec Claude Code sur ce que tu veux.

## 1.2 Ce que tu vas obtenir

- Un environnement Claude Code configuré, sécurisé, partageable en équipe
- Des skills, sub-agents, slash commands prêts à l'emploi
- Au moins un MCP server custom pour ton workflow
- Une méthode de prompting fiable (ne plus jamais "ça hallucine")
- Un workflow Git/déploiement où Claude Code accélère sans casser

## 1.3 Engagement honnête

- 30 min à 2h par jour pendant la durée de la formation choisie
- Pratique sur tes vrais projets (pas juste suivre des vidéos)
- Discord communautaire utilisé activement

Si tu ne peux pas tenir ça : attends d'avoir le temps. Lire ne change rien.

---

# Partie 2 — Installation pas à pas

## 2.1 Prérequis système

Tu as besoin :
- macOS, Linux, ou Windows + WSL2
- Node.js 18 ou plus récent
- Git
- VSCode (ou un éditeur compatible avec l'extension)
- Un compte Anthropic (Claude Code Max recommandé pour ne pas se restreindre)
- (Optionnel) Python 3.11+ si tu vises les modules MCP en Python
- (Optionnel) Compte GitHub avec `gh` CLI installé pour les workflows Git

### Vérifier tes versions

```bash
node --version       # doit être >= 18
git --version
python3 --version    # >= 3.11 si tu vises Python
```

## 2.2 Installation de Claude Code (CLI)

```bash
npm install -g @anthropic-ai/claude-code
claude --version
```

Premier lancement (ouvre une auth OAuth dans ton navigateur) :
```bash
claude
```

Tes credentials sont stockées dans `~/.claude/`.

## 2.3 Installation de l'extension VSCode

1. Ouvre VSCode
2. Marketplace → recherche "Claude Code" (officiel Anthropic)
3. Clique Install
4. Raccourci par défaut : `Cmd+Esc` (macOS) / `Ctrl+Esc` (Linux/Windows)

L'extension reprend automatiquement tes credentials de la CLI.

## 2.4 Vérification

Dans un projet existant :
```bash
cd ~/projects/mon-projet
claude
```

Premier prompt de test :
```
Décris-moi l'architecture de ce projet en 5 points.
```

Si ça répond, tout est OK.

---

# Partie 3 — Configuration

## 3.1 Hiérarchie des fichiers de configuration

```
~/.claude/CLAUDE.md                       # global perso (instructions toutes machines)
~/.claude/settings.json                   # global perso (préférences techniques)
<projet>/CLAUDE.md                        # projet (commité, partagé en équipe)
<projet>/.claude/settings.json            # projet (commité, standards équipe)
<projet>/.claude/settings.local.json      # projet (NON commité, perso à toi sur ce projet)
```

Le plus spécifique gagne. Les `deny` du projet ne peuvent pas être levés en local (sécurité).

## 3.2 Setup du `~/.claude/CLAUDE.md` global

Ouvre (ou crée) `~/.claude/CLAUDE.md` :

```markdown
# CLAUDE.md global

## Mon profil
- Dev [TON_NIVEAU] avec [X] ans d'XP
- Stack principale : [TES_LANGAGES_PRINCIPAUX]
- Tutoiement, ton direct.

## Préférences générales
- Réponses concises, pas de filler
- Code testé, pas de pseudo-code
- Fais référence aux conventions du projet (CLAUDE.md projet)
- Si tu hésites entre 2 approches, propose les 2 avec impact + risque
```

Garde-le court (< 30 lignes). Les conventions techniques vont dans le `CLAUDE.md` du projet, pas ici.

## 3.3 Setup du `~/.claude/settings.json` global

Recopie le template **`_deliverable/settings/settings.minimal.json`** dans `~/.claude/settings.json` :

```bash
mkdir -p ~/.claude
cp _deliverable/settings/settings.minimal.json ~/.claude/settings.json
```

Ce template inclut :
- Modèle par défaut (Opus 4.7)
- `allow` pour les commandes courantes (git, npm, rg, Read, Edit, Write)
- `deny` pour les commandes destructives (`git push --force`, `rm -rf`, etc.)

## 3.4 Setup d'un projet : le `CLAUDE.md` projet

Pour chaque projet où tu vas utiliser Claude Code :

1. Choisis le bon template selon ta stack dans `_deliverable/claude-md/` :
   - `vanilla-supabase.md` — pour solo founder Vanilla JS
   - `react-typescript.md` — pour React + TS
   - `python-fastapi.md` — pour Python + FastAPI
   - `astro-content.md` — pour blog/marketing Astro
   - `monorepo.md` — pour monorepo

2. Copie dans la racine de ton projet :
   ```bash
   cp _deliverable/claude-md/vanilla-supabase.md ~/projects/mon-saas/CLAUDE.md
   ```

3. Adapte : stack exacte, conventions spécifiques, règles métier non évidentes

4. Vise < 100 lignes. Les `CLAUDE.md` longs ne sont pas lus attentivement.

5. Commit dans Git (ce fichier est partagé en équipe).

## 3.5 Setup d'un projet : le `.claude/settings.json`

Pour les projets équipe, copie le template `team` :

```bash
mkdir -p ~/projects/mon-projet/.claude
cp _deliverable/settings/settings.team.json ~/projects/mon-projet/.claude/settings.json
```

Ce template inclut :
- Modèle par défaut
- `allow`/`deny` adaptés
- Hook `PreToolUse` qui log toutes les commandes Bash dans `~/.claude/logs/audit.log`
- Hook `PostToolUse` qui auto-formate les fichiers modifiés (prettier)

Crée le dossier de logs :
```bash
mkdir -p ~/.claude/logs
```

Commit `.claude/settings.json` (partagé) mais **PAS** `.claude/settings.local.json` (perso).

Mets dans `.gitignore` :
```
.claude/settings.local.json
.claude/logs/
```

## 3.6 Setup des skills, sub-agents et commandes

Les fichiers réutilisables sont dans `_deliverable/`. Tu peux les copier au niveau global ou projet.

### Au niveau global (disponible partout)

```bash
# Skills
cp -r _deliverable/skills/* ~/.claude/skills/

# Sub-agents
cp _deliverable/agents/*.md ~/.claude/agents/

# Slash commands
cp _deliverable/commands/*.md ~/.claude/commands/
```

### Au niveau projet (commité, partagé en équipe)

```bash
# Skills spécifiques au projet
cp -r _deliverable/skills/supabase-rls-checker .claude/skills/
cp -r _deliverable/skills/pre-deploy-check .claude/skills/

# Slash commands utiles à l'équipe
cp _deliverable/commands/scope.md .claude/commands/
cp _deliverable/commands/commit.md .claude/commands/
cp _deliverable/commands/review-pr.md .claude/commands/
```

### Vérification

Lance `claude` dans le projet, puis :
```
/commit
```
Si la commande `/commit` existe et répond, ton setup est bon.

## 3.7 Setup d'un MCP server

Un MCP server donne à Claude Code accès à un service externe (ta DB, une API, GitHub, etc.).

Exemple : MCP Lemonsqueezy en TypeScript depuis `_deliverable/mcp-servers/lemonsqueezy-ts/` :

1. Build le serveur :
   ```bash
   cd _deliverable/mcp-servers/lemonsqueezy-ts
   npm install
   npm run build
   ```

2. Ajoute la config dans `~/projects/mon-projet/.claude/settings.local.json` (NE PAS commit, contient ta clé API) :
   ```json
   {
     "mcpServers": {
       "lemonsqueezy": {
         "command": "node",
         "args": ["/chemin/absolu/vers/_deliverable/mcp-servers/lemonsqueezy-ts/dist/server.js"],
         "env": {
           "LEMONSQUEEZY_API_KEY": "ls_TA_CLE"
         }
       }
     }
   }
   ```

3. Lance Claude Code dans ton projet :
   ```bash
   cd ~/projects/mon-projet
   claude
   ```

4. Test :
   ```
   Combien d'abonnements actifs on a sur Lemonsqueezy ?
   ```
   Claude Code invoque automatiquement `list_subscriptions(status="active")`.

---

# Partie 4 — Comment parler à Claude Code

C'est la section la plus importante du guide.

## 4.1 Le squelette de prompt qui marche 9 fois sur 10

Un bon prompt n'est pas long. Il est **structuré** :

```
[Contexte minimal — 1-2 phrases]
[Objectif — 1 phrase, verbe d'action]
[Contraintes — 2-5 puces]
[Format de sortie attendu — 1 phrase]
```

### Exemple

```
Contexte: src/api/users.js a une fonction createUser() de 80 lignes qui fait validation + insert + email.

Objectif: extraire la validation dans validateUserInput() et l'envoi d'email dans sendWelcomeEmail().

Contraintes:
- l'API publique createUser(input) reste identique
- pas de nouvelle dépendance
- les 3 fonctions vivent dans le même fichier

Format de sortie: diff unique sur src/api/users.js.
```

Réponse en moins d'une minute, généralement bonne au premier essai.

## 4.2 Le protocole de debug à 5 points

90 % des sessions Claude Code "qui ne marchent pas" sur un bug viennent du même problème : info manquante.

Pour chaque bug, donne :

1. **Stack trace complète** (jamais tronquée)
2. **Repro steps** : ce que tu as fait, dans l'ordre
3. **Comportement attendu**
4. **Comportement observé**
5. **Hypothèse(s)** (les tiennes, même fausses)

### Exemple

```
L'endpoint POST /api/users (src/routes/users.js) renvoie 500.

Stack:
TypeError: Cannot read property 'email' of undefined
  at validateUser (src/routes/users.js:23)
  at handler (src/routes/users.js:14)

Repro:
1. POST /api/users avec body {"name": "Test"}
2. Pas de champ email dans le body

Attendu: 400 avec {error: 'email_required'}
Observé: 500 avec stack trace en clair

Hypothèse: la validation accède à user.email avant de vérifier que user et email existent.

Trouve la racine et propose un fix minimal.
```

Avec ça, Claude Code va droit au but. Sans ces 5 éléments, il devine.

## 4.3 La règle des 3 essais

Si Claude Code échoue 3 fois de suite à fixer un bug :
- **Stop**. Ne tente pas un 4e essai en escaladant tes prompts.
- Lis ce que tu lui as donné. Tu as probablement omis une info clé.
- Reformule en repartant de zéro avec les 5 points ci-dessus.
- Si encore échec : c'est probablement un bug que tu dois résoudre toi-même avec un debugger. L'IA n'a pas accès à un signal nécessaire (logs runtime, état réseau, race condition).

## 4.4 Mode "patch" plutôt que "réécriture"

Quand la première réponse est presque bonne mais pas exactement, **n'ordonne pas une réécriture totale**. Demande un patch :

```
Le diff précédent est OK sauf le point 3: tu as supprimé l'import de bcrypt
qu'on utilise dans une autre partie du fichier. Modifie uniquement cet import,
ne retouche pas le reste.
```

Tu économises des tokens, tu réduis le risque de régression.

## 4.5 Mode "iterate" : propose 3 options

Quand tu n'es pas sûr de ce que tu veux :

```
Voici la fonction X. Ne modifie rien.
Liste 3 améliorations possibles, chacune avec:
- description en 1 phrase
- impact (faible/moyen/fort)
- risque de régression (faible/moyen/fort)

Je choisirai laquelle appliquer.
```

Tu transformes "fais quelque chose" en "propose, je décide".

## 4.6 Gestion du contexte

Le "contexte" de Claude Code = sa mémoire de session. Il est composé de tes prompts + les fichiers lus + les `CLAUDE.md` chargés + les réponses précédentes.

Plus la session est longue, plus chaque tour est cher et plus la qualité dégrade.

### 3 leviers

- **`/clear`** — reset complet, destructif. Pour quand la conversation dérive.
- **`/compact`** — résume et garde l'essentiel. Pour des sessions longues productives.
- **Sessions courtes** (recommandé par défaut) — 1 tâche = 1 session. Tu fermes en finissant. Tu rouvres pour la suivante.

### Quand utiliser quoi

| Situation | Action |
|---|---|
| Nouvelle tâche, pas liée | Fermer + rouvrir |
| Même tâche depuis 1h, contexte chargé | `/compact` |
| Conversation partie en vrille | `/clear` |
| Tu veux garder une décision importante | Tu l'écris dans `CLAUDE.md` |

## 4.7 Sécurité dans tes interactions

### Ce que Claude Code NE doit PAS faire en autonomie

Même si tu as `auto-accept`, ces commandes doivent toujours être manuelles :

- `git push --force` (réécrit l'historique distant)
- `git reset --hard` (perd des changements locaux)
- `git branch -D` (supprime une branche)
- `git rebase` (peut casser l'historique)
- `rm -rf` (suppression destructive)

Si Claude Code propose une de ces commandes, tu la lis, tu comprends, tu la lances **toi-même** dans un terminal séparé.

Le `settings.json` recommandé du `_deliverable/` les bloque par `deny` — le hook bloque même si tu acceptes par fatigue.

### Avant tout commit

Vérifie qu'aucun secret n'a été ajouté par accident :
```bash
git diff --staged | grep -iE 'sk_live_|service_role|api_key|password='
```

Si quelque chose remonte → STOP, retire le secret avant de commit.

## 4.8 Workflow type d'une session

```
1. Tu ouvres Claude Code dans ton projet :
   cd ~/projects/mon-saas
   claude

2. Tu décris la tâche en utilisant le squelette à 4 sections.

3. Pour les actions Git, tu utilises les slash commands :
   /scope
   /commit
   /review-pr
   /ship

4. Pour les recherches, tu lances le sub-agent explorer :
   "Lance un sub-agent explorer : où est défini le composant X ?"

5. Pour la review avant push, tu lances le sub-agent code-reviewer :
   "Lance code-reviewer sur la branche courante."

6. Tu fermes la session quand la tâche est finie.
```

---

# Partie 5 — Aller plus loin

## 5.1 Choisir ta formation

| Formation | Niveau | Durée | Pour |
|---|---|---|---|
| F6 — Vibe Coding Workflow | 🟢 | ~5h | Workflow quotidien Claude Code |
| F1 — Mastery FR | 🟡 | ~12h | Référence complète Claude Code |
| F2 — Solo Founder Stack | 🟡 | ~8h | Ship un SaaS en 30 jours |
| F3 — Skills MCP Builder Pro | 🔴 | ~10h | Construire skills/MCP avancés |
| F5 — AI Agency Toolkit | 🟡 | ~8h | Workflow freelance/agence |
| F4 — Quant Macro | 🔴 | ~10h | Niche finance/quant |

Recommandation parcours :
1. F6 (entrée)
2. F1 (cœur de gamme)
3. F2 / F5 / F3 / F4 selon profil

Détails dans `INDEX.md` et `BUNDLE-STRATEGY.md` à la racine du dépôt.

## 5.2 Pratique recommandée

À la fin de chaque module / formation :
- 1 exercice pratique sur un de tes vrais projets
- 1 partage dans le Discord (snippet, prompt, retour)
- 1 mesure : qu'est-ce qui a changé dans ton temps de dev ?

## 5.3 Mises à jour

Claude Code évolue. Anthropic sort des features nouvelles régulièrement. Les formations sont mises à jour à chaque release majeure.

Tu reçois automatiquement les mises à jour via le portail formation.

## 5.4 Communauté

Discord par formation (cf. chaque dossier `community/`). Niveau d'exigence et focus différent selon la formation.

## 5.5 Support

- Discord public : entraide entre apprenants (réponses sous 24h en moyenne)
- Email support : pour problèmes admin / accès / facturation

Pas de DM directs au créateur.

---

# Partie 6 — Annexes

## 6.1 Cheatsheet ultra-condensée

### Raccourcis VSCode

```
Cmd+Esc / Ctrl+Esc        Invoquer Claude Code
Tab                       Accepter
Esc                       Rejeter
Cmd+P                     Switch fichiers
F12                       Aller à la définition
```

### Slash commands built-in

```
/clear        Reset complet
/compact      Compresser session
/exit         Fermer
/help         Aide
```

### Slash commands custom (depuis _deliverable)

```
/scope        Scope d'une tâche avant exécution
/commit       Commit message conventionnel
/review-pr    Review de la branche courante vs main
/from-issue   Démarrer depuis une issue GitHub
/ship         Workflow lint + tests + commit + push + PR
```

### Sub-agents (depuis _deliverable)

```
explorer          Recherche read-only dans la codebase
code-reviewer     Review de PR
security-auditor  Audit OWASP top 10
```

### Squelette de prompt

```
Contexte: ...
Objectif: ...
Contraintes:
- ...
Format: ...
```

### Protocole debug

```
1. Stack trace complète
2. Repro steps
3. Attendu
4. Observé
5. Hypothèse
```

## 6.2 Checklist installation complète

- [ ] Node 18+, Git, VSCode installés
- [ ] Claude Code CLI installé (`claude --version` répond)
- [ ] Extension VSCode installée (raccourci `Cmd+Esc` fonctionne)
- [ ] Compte Anthropic actif (Pro ou Max)
- [ ] `~/.claude/CLAUDE.md` global créé (< 30 lignes)
- [ ] `~/.claude/settings.json` global avec `allow`/`deny` configurés
- [ ] `~/.claude/logs/` créé pour les hooks audit
- [ ] Pour 1 projet pilote : `CLAUDE.md` projet + `.claude/settings.json` + `.gitignore`
- [ ] Skills, agents, commandes copiés depuis `_deliverable/`
- [ ] (Optionnel) 1 MCP server branché et testé
- [ ] Test E2E : `/commit` répond, `claude` lance une session

## 6.3 Anti-patterns à éviter (récap)

- Lancer `claude` dans `~` ou un dossier énorme
- `CLAUDE.md` à 300 lignes
- Sessions de 4h sur 8 tâches différentes
- Accepter un diff sans le lire
- Stack trace tronquée donnée pour debug
- Mettre des secrets dans `settings.json` (commité)
- Laisser Claude Code lancer `git push --force` en autonomie
- `select('*')` sur Supabase
- Mutation `is_premium` côté client
- Lancer Opus partout par "principe de qualité" (utiliser Haiku/Sonnet selon tâche)

## 6.4 FAQ rapide

**J'ai une erreur "command not found: claude" après installation**
→ Vérifie ton PATH npm global : `npm config get prefix` puis ajoute le `/bin` à ton PATH.

**Mon `CLAUDE.md` n'est pas lu**
→ Vérifie qu'il est à la **racine** du projet où tu lances `claude`, pas dans un sous-dossier.

**Mon skill ne se déclenche pas**
→ Le `description` du frontmatter manque de mots-clés concrets. Vois `_deliverable/skills/csp-auditor/SKILL.md` pour un exemple optimisé.

**Mon MCP server ne démarre pas**
→ Lance-le en standalone : `node dist/server.js` ou `python server.py`. Si tu as une erreur de variable d'env, ajoute-la dans `settings.local.json`.

**Combien ça coûte par mois ?**
→ Variable selon usage. Compte $20-50 sur un compte Pro pour usage modéré, $200-500 sur Max pour usage intensif. Mesure avec `claude usage` ou via dashboard Anthropic.

**Je n'utilise pas VSCode, ça marche quand même ?**
→ Oui, la CLI marche partout. Tu perds juste l'intégration UI éditeur. Tout le reste fonctionne identique.

**Je peux utiliser Claude Code en équipe ?**
→ Oui. `.claude/settings.json` projet + `.claude/skills/` + `.claude/commands/` sont commités via Git, partagés naturellement. Chaque dev a ses overrides perso dans `.claude/settings.local.json` (gitignoré).

## 6.5 Conventions formations

- **Indentation** : 2 espaces (JS/TS), 4 espaces (Python)
- **Quotes JS** : simples, sans point-virgule
- **Supabase** : colonnes explicites, jamais `select('*')`
- **Sécurité** : `is_premium` (et flags de droits) jamais muté côté client
- **Marketing** : aucun prix dans les fichiers (placeholders `[PRIX]`)
- **Témoignages** : aucun inventé (placeholders `[TÉMOIGNAGE X]`)

Détails dans `MASTER-CLAUDE.md` à la racine.

---

# Conclusion

Ce guide est ta référence permanente. Reviens-y à chaque fois que tu as un doute sur la config, le workflow, ou comment formuler un prompt.

Le savoir non appliqué s'évapore. Code aujourd'hui.

---

**Version du guide** : 1.0
**Date** : 2026
**À convertir en PDF avec** : `pandoc GUIDE-INSTALLATION.md -o GUIDE.pdf --pdf-engine=xelatex --toc --number-sections --highlight-style=tango`
