# LAUNCH-CHECKLIST.md

30 actions à mener pour lancer les 6 formations. À cocher dans l'ordre.

---

## Tech (1–8)

- [ ] **1. Choisir la plateforme d'hébergement de cours** (Podia, Teachable, Systeme.io, ou self-hosted via Vercel + Supabase). Décision selon volume vidéo et budget.
- [ ] **2. Acheter le domaine** (`tonsite.fr` ou `tonsite.com`) et configurer DNS.
- [ ] **3. Configurer la passerelle de paiement** (Lemonsqueezy recommandé pour FR : facturation TVA OSS gérée).
- [ ] **4. Créer un repo Git pour les contenus** (privé, avec ce dépôt comme base).
- [ ] **5. Mettre en place un backup automatique** des contenus (S3, Backblaze) — critique si tu héberges toi-même.
- [ ] **6. Configurer un outil d'email marketing** (Resend + boucle custom, ou ConvertKit/MailerLite).
- [ ] **7. Préparer un environnement de tournage** (lumière neutre, micro cardioïde, fond simple, screencast OBS ou ScreenStudio).
- [ ] **8. Tester le pipeline de publication** (montage → upload → diffusion) sur 1 vidéo pilote.

## Légal (9–14)

- [ ] **9. Rédiger les CGV** (cf. `LEGAL-NOTES.md`).
- [ ] **10. Rédiger les mentions légales** (statut juridique de l'entité émettrice).
- [ ] **11. Rédiger la politique de confidentialité RGPD**.
- [ ] **12. Mettre en place le droit de rétractation 14 jours** (ou y renoncer explicitement avec consentement formel à l'achat — cf. exception formation immédiate).
- [ ] **13. Configurer la facturation automatique** (numéro de facture séquentiel obligatoire en FR).
- [ ] **14. Vérifier le seuil TVA** (auto-entrepreneur ou société : régimes différents).

## Contenu (15–20)

- [ ] **15. Tourner les vidéos pilotes** de F6 (priorité car produit d'entrée).
- [ ] **16. Faire relire chaque module** par un dev externe pour valider les snippets.
- [ ] **17. Construire les ressources annexes** (cheatsheets PDF, templates téléchargeables).
- [ ] **18. Préparer une démo gratuite** (1 module de F6 offert) comme lead magnet.
- [ ] **19. Tourner les vidéos restantes** dans l'ordre F6 → F1 → F2 → F3 → F5 → F4.
- [ ] **20. Sous-titrer les vidéos** (FR a minima, EN si tu veux toucher l'international).

## Marketing (21–27)

- [ ] **21. Construire la landing principale** (variante de la landing F1, agrégée).
- [ ] **22. Construire les landing pages** spécifiques par formation (cf. `marketing/landing-page.md` de chaque dossier).
- [ ] **23. Lancer la séquence email** de pré-launch (4 semaines avant ouverture).
- [ ] **24. Programmer 30 posts X/LinkedIn** (5 par formation × 6, base dans `marketing/social-posts.md`).
- [ ] **25. Identifier 10 partenaires** pour relais (devs FR avec audience, podcasts tech FR).
- [ ] **26. Préparer un kit affiliation** (lien, copywriting, swipe file).
- [ ] **27. Définir une stratégie de prix** (jamais dans ce dépôt — décision externe au repo).

## Communauté & support (28–30)

- [ ] **28. Ouvrir le serveur Discord/Slack** avec la structure de canaux décrite dans `community/discord-channels.md`.
- [ ] **29. Mettre en place un support client** (email dédié + canal #support sur la communauté + FAQ vivante).
- [ ] **30. Préparer un onboarding automatisé** (email J0 + message communauté + checklist apprenant) — cf. `community/onboarding-message.md` de chaque formation.

---

## Critères de "go/no-go" pour ouvrir les ventes

Tu n'ouvres PAS les ventes tant que :
- F6 n'a pas été testée en bêta auprès de 5 personnes minimum
- Les CGV et mentions légales sont validées (idéalement par un avocat)
- Le pipeline de paiement + facturation a été testé en conditions réelles (achat test, remboursement test)
- Au moins 3 testimonials réels sont collectés (placeholders à remplacer dans les marketing/landing-page.md)
