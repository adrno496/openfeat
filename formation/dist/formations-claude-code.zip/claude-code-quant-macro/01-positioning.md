# Positioning — Claude Code Quant & Macro

## USP

La seule formation FR qui te montre comment construire un **lab quant/macro IA-augmenté** avec Claude Code, en gardant le contrôle de tes data sources, sans vendor lock-in (pas de Refinitiv/Bloomberg obligatoire).

## Cible

- Trader indépendant (crypto, actions, FX, indices)
- Quant junior qui veut accélérer son output
- Analyste macro / portfolio manager d'un fonds boutique
- Curieux finance qui veut systématiser sa recherche

## Pas la cible

- Débutants en finance (apprends d'abord les bases — sharpe, drawdown, position sizing, etc.)
- Quants seniors avec stack Bloomberg/Refinitiv déjà en place (cette formation est plus DIY)
- Day traders en quête de signaux magiques (cette formation enseigne l'outillage, pas une stratégie)

## Promesse

À la fin :
- Tu as 2-4 MCP servers personnels pour ta data (prix, on-chain, macro)
- Tu génères des backtests Pine Script en quelques minutes au lieu d'1 jour
- Tu reçois alertes Telegram automatiques sur tes signaux
- Tu produis des notes hebdo en 30 min au lieu de 4h
- Tu n'es plus dépendant d'un vendor unique

## Anti-promesse

- Aucune stratégie de trading n'est partagée comme garantie
- Aucune promesse de revenu ou de PnL
- Tu restes responsable de tes décisions financières
- On ne couvre pas l'execution (broker APIs) en profondeur

## Format

Très technique. Code Python testé. Pine Script fonctionnel. Disclaimers explicites partout.
