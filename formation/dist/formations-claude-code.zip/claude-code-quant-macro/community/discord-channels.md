# Structure Discord — Quant & Macro

Communauté builders quant. Rigueur intellectuelle attendue.

## ⚠️ Règles spécifiques quant
**Aucun conseil d'investissement échangé**. Discussion outillage, code, méthodologie. Si tu partages une "view marché", elle est annotée comme telle, jamais comme un signal.

## 👋 Bienvenue
- `#règles`
- `#présente-toi` (format imposé)
- `#annonces`

## 📚 Formation
- `#questions-mcps-data` (modules 02, 03)
- `#questions-skills-macro` (module 04)
- `#questions-pine-script` (module 05)
- `#questions-dashboards` (module 06)
- `#questions-alertes` (module 07)
- `#questions-rapports` (module 08)

## 🔬 Lab
- `#vos-mcps` — montre tes MCPs custom (anonymisé OK)
- `#vos-skills-macro` — analyses FED/NFP/COT etc.
- `#vos-strategies-pine` — Pine Script à reviewer (pas de "ça gagne")
- `#vos-dashboards` — captures
- `#vos-rapports` — newsletters / notes hebdo (lien Substack OK)

## 📊 Discussion macro
- `#fed-watch`
- `#crypto-onchain`
- `#fx-rates`
- `#equities-sectors`

## 💼 Business
- `#monetisation` — newsletter / Discord premium / consulting fonds

## 💬 Off-topic
- `#café`

## Règles
- Rigueur intellectuelle (pas d'affirmation sans source)
- Pas de "ça va monter / descendre"
- Disclaimers respectés
- Pas de DM spam
- Pas de partage du contenu de la formation
