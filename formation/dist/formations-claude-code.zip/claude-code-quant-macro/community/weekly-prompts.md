# Weekly Prompts — Quant & Macro

12 prompts.

## S1 — Ton stack actuel
"Quels outils data tu utilises aujourd'hui ? Combien tu paies / mois ? Quelle est la friction principale ?"

## S2 — Premier MCP
"Tu as construit un MCP custom ? Lequel, en combien de temps ?"

## S3 — Skill macro le plus utile
"Si tu avais 1 seul skill macro à automatiser, ce serait quoi (FED, NFP, COT, ISM, autre) ?"

## S4 — Anti-patterns Pine Script
"Le pire backtest Pine Script que tu aies vu (lookahead, overfitting, fees ignorées) ?"

## S5 — Dashboard
"Marimo ou Streamlit ? Pourquoi ? Capture de ton dashboard si tu en as un."

## S6 — Routine matinale
"Combien de temps prend ta routine matinale (avant marché ouvre) ? Cible 15 min ?"

## S7 — Bot Telegram
"Tu as un bot Telegram d'alertes ? Quelles conditions tu as automatisées ? Combien de fois par semaine ça vibre ?"

## S8 — Rapport hebdo
"Tu publies (Substack / interne / pour clients) ? Format, fréquence, audience ?"

## S9 — Vendor lock-in
"Tu es coincé avec un vendor cher (Bloomberg, Refinitiv, autre) ? Plan de migration vers stack DIY ?"

## S10 — Monétisation
"Pour ceux qui monétisent : modèle (newsletter, Discord, consulting) ? Premier $ payant venu d'où ?"

## S11 — Erreur de PnL
"Une fois où tu as fait confiance à ton outillage et perdu de l'argent → leçon retenue ?"

## S12 — Plan trimestre
"Tes 3 priorités builder pour le trimestre suivant."

## Notes facilitation
- Lundi matin
- Le créateur poste en exemple
- Show monthly avec démos de MCPs / dashboards
- Pas de "quel ticker acheter" → bannir immédiatement
