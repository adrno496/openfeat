# Onboarding — Quant & Macro

## DM automatique

```
Salut [PRENOM] et bienvenue chez les builders quant.

Cette communauté = rigueur intellectuelle + outillage. Pas de "ça monte / ça descend" sans source.

3 étapes :
1. Lis #règles (esprit du groupe + disclaimers stricts)
2. Présente-toi (format imposé)
3. Engage-toi dans #vos-mcps ou #vos-skills-macro

Pour tes questions :
- #questions-mcps-data pour modules 02-03
- #questions-skills-macro pour 04
- #questions-pine-script pour 05
- etc.

⚠️ Aucun conseil d'investissement n'est échangé ici. Discussions outillage, code, méthodologie.

Pas de DM directs. Tout passe par les canaux publics.

Build ton lab.
[SIGNATURE]
```

## Template présente-toi

```
Prénom: [PRENOM]
Profil: [trader indé / quant junior / analyste macro / autre]
Marchés suivis: [crypto / actions / FX / commos / mix]
Stack actuel: [outils utilisés aujourd'hui]
Objectif Quant & Macro: [1 ligne, ex: réduire ma plomberie matinale]

Je n'attends aucun conseil d'investissement ici, juste de l'outillage et de la méthodologie.
```
