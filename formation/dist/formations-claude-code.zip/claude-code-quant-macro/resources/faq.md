# FAQ — Quant & Macro

### Faut-il être quant pro pour suivre ?
Non, mais il faut connaître les bases : sharpe, drawdown, position sizing, mean reversion vs trend. Si ces termes te sont étrangers, fais d'abord un fondamentaux quant en ligne.

### Faut-il payer Glassnode/Dune pour suivre ?
Non. yfinance + CoinGecko (gratuits) suffisent pour 80 % des modules. Glassnode/Dune sont au module 03, optionnel si tu n'es pas crypto-focused.

### Pine Script vs Python pour backtest ?
Pine Script : rapide pour prototyper, intégré à TradingView, communauté énorme.
Python (backtesting.py, vectorbt) : plus de contrôle, peut intégrer des MCPs custom, gratuit.
Cette formation couvre Pine Script (module 05) et te donne les bases pour aller en Python ensuite.

### Cette formation me donne une stratégie qui gagne ?
Non. Elle te donne l'**outillage**. La stratégie reste ta responsabilité. Aucune n'est garantie.

### Combien de temps pour finir ?
~10h de contenu + 10-15h pratique = 3-5 semaines à raison de 1h/jour.

### Est-ce que ça marche si je trade FX et pas crypto ?
Oui. yfinance couvre FX (EURUSD=X, etc.). Les modules macro et Pine Script sont indépendants de la crypto.

### Bot Telegram peut être public ?
Si tu envoies du PnL réel : non, jamais. Si tu envoies juste signal d'analyse macro : oui, c'est un modèle Substack-like.

### Garantie de remboursement ?
Cf. CGV.

### Je peux monétiser ce que je construis ?
Oui — newsletter, Substack, alertes premium, consulting fonds. Cf. module 09 + F3 module 07.

### Communauté ?
Discord builders quant. Niveau exigé. Disclaimers respectés (pas de conseil financier en partage).
