# Ressources externes — Quant & Macro

## Data sources

- yfinance : Yahoo Finance via Python (`pip install yfinance`)
- CoinGecko API : `coingecko.com/en/api`
- Glassnode : `glassnode.com` (Studio + API)
- Dune Analytics : `dune.com`
- FRED : `fred.stlouisfed.org` (API gratuite)
- BLS (Bureau of Labor Statistics) : `bls.gov`
- ECB Statistical Data Warehouse : `sdw.ecb.europa.eu`
- TradingView : `tradingview.com`

## Tools

- Marimo : `marimo.io` (notebook réactif)
- Streamlit : `streamlit.io` (dashboard)
- pandas, numpy, scipy, plotly
- ccxt (multi-exchange crypto trading API)
- pandas_ta (technical indicators)
- backtesting.py (backtest framework Python)

## Lectures (sélection)

- "Inside the House of Money" (Steven Drobny) — interviews macro hedge funds
- "Trading Systems and Methods" (Perry Kaufman) — référence stratégies quant
- Articles QuantPedia
- Substack macro-finance (Concoda, Doomberg, etc.)

## Communautés

- Twitter / X — comptes macro et quant ciblés
- Discord serveurs trading (qualité variable, lire avec esprit critique)
- Discord builders quant de cette formation

## Disclaimers répétés

Aucune ressource ci-dessus n'est un conseil d'investissement. La performance passée ne garantit pas la performance future. Tout l'outillage de cette formation sert à automatiser ta recherche, pas à remplacer ton jugement.

## Pour aller plus loin

- F3 — `skills-mcp-builder-pro/` — monétiser tes MCPs
- F5 — `ai-agency-toolkit/` — consulting fonds
- F2 — `solo-founder-stack/` — newsletter / SaaS finance
- F1 — `claude-code-mastery-fr/` — référence Claude Code
