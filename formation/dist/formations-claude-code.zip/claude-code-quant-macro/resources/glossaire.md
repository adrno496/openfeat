# Glossaire — Quant & Macro

**Backtest** — Simulation d'une stratégie sur données historiques.

**COT (Commitments of Traders)** — Rapport hebdo CFTC sur positions des traders sur futures US.

**CPI (Consumer Price Index)** — Inflation des prix à la consommation.

**Drawdown** — Perte maximum depuis un sommet de la courbe equity.

**FED / FOMC** — Federal Reserve / Federal Open Market Committee. Définit la politique monétaire US.

**FRED** — Federal Reserve Economic Data. API gratuite avec milliers d'indicateurs macro US.

**Glassnode** — Plateforme de métriques on-chain Bitcoin / Ethereum.

**Hawkish / Dovish** — Hawkish = en faveur d'une politique restrictive (taux haussiers). Dovish = en faveur d'accommodation (taux baissiers ou status quo).

**Lookahead bias** — Erreur de backtest où la stratégie utilise une info qui ne sera connue qu'après le moment du trade.

**Mean reversion** — Stratégie qui parie sur le retour à la moyenne après écart.

**MRR / MTR** — Monthly Recurring Revenue / Monthly Tracked Revenue (RevenueCat).

**NFP (Non-Farm Payrolls)** — Rapport mensuel emploi US (1er vendredi du mois).

**On-chain** — Données extraites directement de la blockchain (BTC, ETH).

**Pine Script** — Langage de scripting de TradingView pour stratégies + indicateurs.

**RSI (Relative Strength Index)** — Indicateur de momentum 0-100.

**Sharpe ratio** — Mesure de rendement ajusté du risque.

**SOPR** — Spent Output Profit Ratio (Glassnode). Indicateur on-chain BTC.

**Trend following** — Stratégie qui parie sur la continuation d'un trend.

**Vendor lock-in** — Dépendance forte à un fournisseur de data unique (Bloomberg, Refinitiv).

**Win rate** — Pourcentage de trades gagnants sur un backtest.

**yfinance** — Bibliothèque Python pour data Yahoo Finance (actions, indices, FX).
