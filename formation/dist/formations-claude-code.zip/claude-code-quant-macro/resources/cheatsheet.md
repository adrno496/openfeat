# Cheatsheet — Claude Code Quant & Macro

## Stack data + coût mensuel

```
yfinance      gratuit        actions/indices/FX
CoinGecko     gratuit/$129   crypto prix
Glassnode     $30/$700       on-chain BTC/ETH
Dune          gratuit/$399   queries SQL on-chain
FRED          gratuit        macro indicators US
TradingView   $30            charts + Pine Script
```

Coût démarrage : $30-100/mois. Avancé : $1000+/mois.

## MCP servers à construire

```
mcps/
├── yfinance/server.py
├── coingecko/server.py
├── glassnode/server.py
├── dune/server.py
└── fred/server.py
```

## Skills macro recommandés

- fed-meeting-analyzer
- nfp-analyzer
- cpi-analyzer
- ism-analyzer
- cot-report-analyzer

## Stack analyse + viz

- Notebooks : Marimo (réactif, gratuit) ou Jupyter
- Dashboards : Marimo Cloud / Streamlit Cloud
- Charts : plotly express
- Stats : pandas + numpy + scipy

## Pine Script v5 minimal

```pinescript
//@version=5
strategy("Nom", overlay=true, initial_capital=10000, default_qty_type=strategy.percent_of_equity, default_qty_value=100)

// Inputs
length = input.int(20, "MA Length")

// Indicators
ma = ta.sma(close, length)

// Conditions
if close > ma
    strategy.entry("Long", strategy.long)
if close < ma
    strategy.close("Long")

// Plot
plot(ma)
```

## Alertes Telegram setup

1. @BotFather Telegram → /newbot → token
2. @userinfobot → ton chat_id
3. send_alert via httpx POST /sendMessage

## Cron typique

```
30 14 * * 5    NFP analyzer (1er vendredi du mois 14h30)
0 9 * * 1-5   Morning snapshot
0 18 * * 0    Weekly report generation
```

## Disclaimers obligatoires

À mettre sur chaque rapport / alerte / dashboard :
"Document à titre informatif. Aucun conseil d'investissement. La performance passée ne garantit pas la performance future."

## Anti-patterns

- Stratégie backtested sur 1 an de bull market → conclusion fausse
- Pas de fees/slippage dans backtest
- Lookahead bias en Pine Script
- API keys hardcoded
- Bot Telegram public (PnL leak)
- Pas de séparation paper / live trading
- Vendor lock-in ($1000+/mois sans value validée)

## Sécurité

- Bot Telegram : chat privé uniquement si PnL réel
- API keys : env vars only, jamais commit
- Service keys (broker) : strictly env, rotation 90j
- Logs structurés (audit cron jobs + API calls)
