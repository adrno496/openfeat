# Script vidéo — Intro hook (≤ 90 sec)

### 0:00 — 0:20 — Hook
"Tu es trader indé, quant junior, ou analyste macro. Tu passes la moitié de ta journée en plomberie : récupérer des data, structurer des notes, manipuler des CSV, écrire des résumés."

### 0:20 — 0:50 — Solution
"Quant & Macro te montre comment construire un lab IA-augmenté avec Claude Code. MCPs custom pour data prix (yfinance, CoinGecko) et on-chain (Glassnode, Dune), skills d'analyse macro, backtests Pine Script générés, dashboards Marimo, alertes Telegram, rapports PDF institutionnels."

### 0:50 — 1:10 — Différenciation
"Pas un cours de trading. Pas de signal magique. L'outillage qui te libère des 4h de plomberie quotidienne."

### 1:10 — 1:25 — Disclaimer
"Aucune stratégie garantie. Tu restes responsable de tes décisions financières."

### 1:25 — 1:30 — CTA
"[LIEN]"

## Notes
- Plan poitrine
- B-roll : screencast d'un dashboard Marimo + un PDF rapport ouvert
- Pas de musique
