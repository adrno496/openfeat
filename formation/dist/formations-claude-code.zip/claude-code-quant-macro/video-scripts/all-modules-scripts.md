# Scripts vidéo — Quant & Macro (consolidé)

## 00 — Intro hook (≤ 90 sec)
- "Tu es trader indé, quant junior, ou analyste macro. Tu passes 4-8h/jour en plomberie de data."
- "Quant & Macro te montre comment construire un lab IA-augmenté avec Claude Code. MCPs custom pour data prix + on-chain + macro, skills d'analyse, backtests Pine Script, dashboards, alertes Telegram, rapports PDF."
- "Pas un cours de trading. Aucune stratégie garantie. Tu restes responsable."
- CTA.

## 01 — Architecture lab (8-10 min)
- Stack data + analyse + alerting + reporting
- Coûts mensuels selon profondeur
- Structure projet type

## 02 — MCP yfinance + CoinGecko (12-15 min)
- Code Python complet
- Test "Compare YTD SPY/BTC/ETH/GLD"
- Disclaimers latence

## 03 — MCP Glassnode + Dune (12-15 min)
- API on-chain
- Auth + rate limit
- Use case "SOPR BTC + perf 30j"

## 04 — Skills macro (10-12 min)
- fed-meeting-analyzer (démo complète)
- nfp-analyzer, cot-analyzer
- Format de sortie + disclaimers

## 05 — Pine Script généré (12-15 min)
- Skill `pine-script-generator`
- Démo : trend-following + RSI
- Anti-patterns (lookahead, overfitting, fees ignorées)

## 06 — Dashboard Marimo (10-12 min)
- Marimo vs Streamlit
- Démo PnL temps réel
- Hébergement + sécurité

## 07 — Alertes Telegram (6-8 min)
- Bot setup
- Skill send-telegram-alert
- Cron pour alertes périodiques

## 08 — Rapports institutionnels (10-12 min)
- Template Markdown
- Pandoc → PDF
- Workflow weekly-report skill

## 09 — Conclusion (3-4 min)
- Récap, plan 90 jours, monétisation possible (Substack, Discord, consulting)

## Notes
- Captures terminal + Marimo + TradingView side-by-side
- Disclaimers à l'écran à chaque démo trading
- Pas de musique épique
