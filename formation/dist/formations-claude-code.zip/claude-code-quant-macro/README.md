# 📊 Claude Code — Quant & Macro

**Automatiser ta recherche macro et tes backtests avec Claude Code.**

Pour traders indépendants, quants juniors, analystes macro, fonds boutique. Niche finance, ton sec et quantitatif, sourcé.

## Pour qui

- Trader indépendant qui veut automatiser sa recherche
- Quant junior qui veut accélérer son output
- Analyste macro qui veut systématiser ses notes
- Fonds boutique qui veut un lab IA-augmenté sans vendor lock-in

## Ce que tu obtiens

- 8 modules approfondis (~10h)
- MCP servers custom (TradingView, yfinance, CoinGecko, Glassnode, Dune)
- Skills d'analyse macro
- Backtests Pine Script générés
- Dashboards trading (HTML/Streamlit/Marimo)
- Alertes Telegram
- Templates rapports institutionnels
- Communauté quants et traders

## Prérequis

- F1 (`claude-code-mastery-fr/`) ou maîtrise sub-agents/MCP
- Connaissance des concepts financiers (PnL, drawdown, sharpe, position sizing)
- Python solide
- (Optionnel) Notions Pine Script

## Disclaimers

Cette formation enseigne l'**outillage**. Pas le trading. Aucune stratégie n'est garantie de gagner. Tu restes responsable de tes décisions financières.

## Structure

Standard formation. Voir `00-syllabus.md`.
