# Testimonials — Quant & Macro

## Email type J+60

**Sujet** : Tu as construit ton lab ?

3 questions :
1. Avant : combien d'heures par jour de plomberie data ?
2. Maintenant : tu as construit quoi ? (MCPs, skills, dashboard, alertes, rapports)
3. Heures économisées par jour ?

Confirme aussi si je peux utiliser publiquement avec ton nom + lien (LinkedIn / X).

## Format type
```
"J'ai construit 3 MCPs (yfinance, CoinGecko, Glassnode) en 2 semaines après Quant & Macro.
Ma routine matinale est passée de 1h30 à 15 min. Le skill `fed-meeting-analyzer` me fait gagner
1h par FOMC. Je publie maintenant une newsletter hebdo générée à 70% via le pipeline du module 08."

— [PRENOM] [NOM], [trader indé / quant / analyste]
[LIEN_PROFIL]
```

## Critères
- Personne réelle
- Chiffres mesurables (heures économisées, revenus si applicable)
- Pas de claim de "PnL grâce à la formation" (interdit + faux)
- Consentement écrit explicite

## Si pas de témoignages
Placeholders sur landing.
