# Social Posts — Quant & Macro

10 posts. Ton sec, sourcé, disclaimers.

## 1 — X
```
Combien tu paies par mois pour ta data quant/macro ?

Bloomberg : $2400+
Refinitiv : $2000+
Glassnode Advanced : $700
Dune Pro : $399

Stack équivalent DIY :
yfinance (gratuit) + CoinGecko free + Glassnode Standard ($30) + Dune free + FRED gratuit = $30/mois.

Moins de fonctionnalités, mais 90% de ce dont un quant indé a besoin.
```

## 2 — LinkedIn
```
La majorité des analystes macro passent 50% de leur temps en plomberie de data.

Plomberie typique :
- Récupérer prix sur Yahoo Finance
- Copier coller dans Excel
- Réécrire des résumés FOMC à la main
- Régénérer des charts pour le rapport

Avec Claude Code + 3-4 MCPs custom : 30 min au lieu de 4h.

Quant & Macro montre comment construire ce lab en 4 semaines.
[LIEN]
```

## 3 — X
```
Skill macro auto-déclenché qui économise 1h par FOMC :

`fed-meeting-analyzer` = analyse hawkish/dovish + implications USD/taux/SPX/Gold/BTC en sortie structurée.

Tu lis le statement Powell. Tu copies dans Claude Code. Tu obtiens le rapport pro en 30 sec.
```

## 4 — LinkedIn
```
3 anti-patterns Pine Script que je vois constamment :

❌ Lookahead bias (`barmerge.lookahead_on` mal utilisé) → backtest mensonger
❌ Stratégie testée sur 1 an de bull market → overfitting évident
❌ Pas de fees ni slippage dans `strategy()` → PnL fictif

Module 05 de Quant & Macro couvre la génération propre + détection des biais.
[LIEN]
```

## 5 — X
```
Setup minimal lab quant indé :

mcps/yfinance/      data prix actions/indices/FX
mcps/coingecko/     data crypto
alerts/telegram/    notifs auto
notebooks/          analyse Marimo
strategies/         Pine Script
reports/            templates rapport

Coût démarrage : $30/mois. Time savings : 3-5h/jour.
```

## 6 — LinkedIn
```
Notes hebdo macro = livrable type d'un fonds boutique.

Avant Claude Code : 4-6h pour rédiger une note de 6 pages.
Après pipeline `weekly-report` skill + Pandoc : 30 min de review humaine sur un brouillon généré.

Module 08 Quant & Macro montre la stack complète (Markdown → PDF avec template LaTeX).
[LIEN]
```

## 7 — X
```
Bot Telegram + cron pour alerte morning snapshot :

0 9 * * 1-5  python alerts/morning_snapshot.py

Ton téléphone vibre à 9h avec :
*Morning Snapshot*
BTC: $XX,XXX (+1.2%)
SPY: $XXX (-0.3%)
Gold: $X,XXX (+0.5%)

Setup : 30 min. Habitude qui change la journée.
```

## 8 — LinkedIn
```
Vendor lock-in en quant/macro indé : danger #1.

Si tu paies $1500/mois pour Bloomberg Terminal + $400/mois pour Dune + $700 pour Glassnode :
- Tu ne peux pas tester librement
- Tu ne peux pas migrer
- Tu es coincé même si la valeur diminue

Stack DIY avec Claude Code + MCPs custom : tu gardes le contrôle.

Quant & Macro montre comment.
[LIEN]
```

## 9 — X (disclaimer)
```
RAPPEL : Aucun outil ne te donne une stratégie qui gagne.

Outillage = levier sur ta thèse.
Pas de thèse = outillage inutile.

Construis ta conviction. L'IA accélère la recherche, pas le jugement.
```

## 10 — LinkedIn (CTA)
```
Tu es trader indé / quant junior / analyste macro.

Quant & Macro : 8 modules pour construire ton lab IA-augmenté avec Claude Code.

MCPs custom, skills d'analyse, backtests, dashboards, alertes, rapports PDF.

Pas de stratégie magique. L'outillage qui libère ta journée.

[LIEN]
```
