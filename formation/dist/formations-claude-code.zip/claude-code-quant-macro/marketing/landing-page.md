# Landing — Quant & Macro

Aucun prix.

## Hero
**Headline** : Construis ton lab quant/macro IA-augmenté avec Claude Code.
**Sous-headline** : MCPs custom (yfinance, CoinGecko, Glassnode, Dune), skills d'analyse macro, backtests Pine Script, dashboards, alertes Telegram, rapports PDF.
**CTA** : `Accéder à la formation →`

## Problème
Tu passes la moitié de ta journée en plomberie de data. Tu n'as pas le temps de creuser tes thèses. Les outils SaaS coûtent 1000+ €/mois et créent du vendor lock-in.

## Promesse
8 modules pour transformer ton workflow :
- MCPs custom Python pour TES sources data
- Skills auto-déclenchés pour analyses récurrentes (FED, NFP, COT, etc.)
- Pine Script généré rapidement
- Dashboards Marimo / Streamlit
- Bot Telegram + cron pour alertes
- Pipeline rapport PDF (Pandoc)

À la fin : 30 min/jour de plomberie au lieu de 4h. Reste de la journée sur ce qui compte.

## Pour qui
- Trader indépendant (crypto, actions, FX)
- Quant junior
- Analyste macro / portfolio manager fonds boutique
- Curieux finance qui veut systématiser

## Disclaimers
Aucune stratégie partagée n'est garantie. Aucune promesse de PnL. Tu restes responsable de tes décisions.

## Programme
01 Architecture lab quant
02 MCP yfinance + CoinGecko
03 MCP Glassnode + Dune
04 Skills analyse macro (FED, NFP, COT, ISM)
05 Backtests Pine Script
06 Dashboards Marimo
07 Alertes Telegram + automation
08 Rapports PDF institutionnels
09 Conclusion + monétisation

## Ce que tu obtiens
- 8 modules approfondis (~10h)
- 5 exercices pratiques + solutions
- Code complet des 4 MCPs (yfinance, CoinGecko, Glassnode, Dune)
- 3 skills macro (FED, NFP, COT)
- 1 stratégie Pine Script de référence
- Template dashboard Marimo
- Bot Telegram + cron jobs
- Template rapport hebdo PDF
- Communauté Discord builders quant
- Mises à jour à vie

## Preuve sociale
[TÉMOIGNAGE 1 — quant junior qui a libéré 3h/jour]
[TÉMOIGNAGE 2 — trader indé qui automatise sa newsletter]
[TÉMOIGNAGE 3 — analyste fonds boutique qui a remplacé un service SaaS à 800€/mois]

## FAQ
(Cf. resources/faq.md)

## CTA final
**Titre** : Lab quant IA-augmenté en 4 semaines.
**CTA** : `Accéder à la formation →`
