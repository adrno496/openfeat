# Email Sequence — Quant & Macro

5 emails.

## E1 — J0 — Welcome
**Sujet** : Accès Quant & Macro
Salut [PRENOM]. Accès : [LIEN]. Discord builders quant : [LIEN_DISCORD]. Démarre par module 01 puis 02 (MCPs gratuits yfinance + CoinGecko).

## E2 — J+5 — Premier MCP
**Sujet** : Tu as ton MCP yfinance ?
Si tu as fait l'exercice 01, tu peux maintenant demander à Claude Code "Compare YTD SPY/BTC/ETH/GLD" et obtenir une réponse en 5 secondes au lieu d'ouvrir 4 tabs.
[CTA Module 02]

## E3 — J+12 — Skills macro
**Sujet** : Le skill qui économise 1h par FOMC
Module 04 : skill `fed-meeting-analyzer` qui structure ton analyse hawkish/dovish + implications par actif. Économie : 1h par meeting.
[CTA Module 04]

## E4 — J+25 — Pine Script
**Sujet** : Backtest en 30 min au lieu d'1 jour
Module 05 : skill `pine-script-generator` te donne du Pine v5 valide directement. Tu testes, tu itères, tu optimises. Et tu lis bien les anti-patterns (lookahead, overfitting).
[CTA Module 05]

## E5 — J+45 — Monétisation possible
**Sujet** : Tu peux en faire un revenu ?
Substack macro/quant payante, alertes Discord/Patreon premium, consulting fonds, SaaS dashboard pour traders indé.
Module 09 ouvre les pistes. F3 (Builder Pro) creuse les modèles génériques.
