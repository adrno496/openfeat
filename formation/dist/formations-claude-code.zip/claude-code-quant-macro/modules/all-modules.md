# Modules — Claude Code Quant & Macro (consolidé)

À splitter en 10 fichiers individuels au moment de la prod.

---

## Module 00 — Introduction (🟢, 15 min)

### Pourquoi cette formation
Le quant/macro indé d'aujourd'hui combine 3 piliers :
1. Data sources multiples (prix, on-chain, macro indicators)
2. Analyse + backtest rapides
3. Communication (rapports, alertes)

Sans Claude Code : 4-8h/jour de plomberie. Avec Claude Code + MCPs custom : 1-2h/jour.

### Disclaimers
- Pas de signal magique
- Aucune garantie de PnL
- Tu restes responsable de tes décisions
- Aucun de mes exemples n'est un conseil d'investissement

### Engagement
Pratiquer sur tes propres données et stratégies réelles.

---

## Module 01 — Architecture lab quant (🟡, 35 min lecture + 15 min pratique)

### Stack cible

```
DATA SOURCES                    →  MCP SERVERS                →  ANALYSE / DASHBOARD       →  ALERTING
- yfinance (actions)               - mcp-yfinance (Python)       - notebooks (Marimo)         - bot Telegram
- CoinGecko (crypto)               - mcp-coingecko (Python)      - dashboards (Streamlit)     - email
- Glassnode (on-chain)             - mcp-glassnode (Python)
- Dune (queries SQL)               - mcp-dune (Python)
- TradingView (charts)             - (manuel via webhooks)
- FRED (macro indicators)          - mcp-fred (Python)
```

### Coûts mensuels typiques

- yfinance : gratuit
- CoinGecko : gratuit (rate-limited) ou Pro ~$129/mois
- Glassnode : Standard $30/mois, Advanced $700/mois
- Dune Analytics : gratuit (rate limited) ou Pro $399/mois
- FRED API : gratuit
- TradingView : Pro $30/mois (pour Pine Script avancé + alertes)
- Hébergement bot Telegram + dashboard : ~$5-15/mois (Fly.io, Railway)
- Anthropic API ou Claude Code Max : ~$100-200/mois usage intensif

**Total démarrage : $50-100/mois**. **Stack avancée (Glassnode Advanced + Dune Pro) : $1000+/mois**. Choisir selon profil.

### Structure projet type

```
lab-quant/
├── mcps/
│   ├── yfinance/
│   ├── coingecko/
│   ├── glassnode/
│   └── dune/
├── notebooks/
│   ├── macro-weekly.ipynb
│   └── btc-onchain.ipynb
├── strategies/
│   ├── trend-following.pine
│   └── mean-reversion.pine
├── reports/
│   └── templates/
├── alerts/
│   └── telegram-bot/
├── .claude/
│   ├── settings.json
│   ├── settings.local.json (secrets)
│   └── skills/
└── CLAUDE.md
```

### Anti-patterns

- Vouloir tout en SaaS payant dès le départ ($1000+/mois sans avoir validé sa value)
- Mélanger code de prod (alertes auto) et notebook exploratoire dans le même fichier
- Pas de séparation paper trading / live trading

---

## Module 02 — MCP yfinance + CoinGecko (🔴, 50 min lecture + 25 min pratique)

### MCP yfinance (actions, indices, FX)

```python
# mcps/yfinance/server.py
import yfinance as yf
import json
from mcp.server.fastmcp import FastMCP

mcp = FastMCP("yfinance")

@mcp.tool()
def get_price(ticker: str, period: str = "5d") -> str:
    """
    Récupère les prix OHLCV d'un ticker.
    period : 1d, 5d, 1mo, 3mo, 6mo, 1y, 2y, 5y, 10y, ytd, max
    """
    data = yf.Ticker(ticker).history(period=period)
    if data.empty:
        return json.dumps({"error": "no data", "ticker": ticker})
    return data.tail(20).to_json(date_format="iso")

@mcp.tool()
def get_quote(ticker: str) -> str:
    """Quote temps réel (15 min delay sur la plupart des tickers)."""
    info = yf.Ticker(ticker).info
    return json.dumps({
        "symbol": ticker,
        "price": info.get("currentPrice"),
        "marketCap": info.get("marketCap"),
        "pe": info.get("trailingPE"),
        "dividendYield": info.get("dividendYield"),
    })

@mcp.tool()
def compare_tickers(tickers: list[str], period: str = "1y") -> str:
    """Compare la performance de plusieurs tickers (% return)."""
    data = yf.download(tickers, period=period, progress=False)["Close"]
    returns = ((data.iloc[-1] / data.iloc[0]) - 1) * 100
    return json.dumps(returns.round(2).to_dict())

if __name__ == "__main__":
    mcp.run(transport="stdio")
```

Config Claude Code :
```json
{
  "mcpServers": {
    "yfinance": {
      "command": "python",
      "args": ["/path/to/mcps/yfinance/server.py"]
    }
  }
}
```

Test :
```
"Donne-moi la perf YTD de SPY, QQQ, IWM, GLD"
```
Claude Code invoque `compare_tickers` automatiquement.

### MCP CoinGecko (crypto)

```python
# mcps/coingecko/server.py
import os
import httpx
import json
from mcp.server.fastmcp import FastMCP

mcp = FastMCP("coingecko")

API_KEY = os.environ.get("COINGECKO_API_KEY")  # Optionnel, gratuit sans
BASE = "https://api.coingecko.com/api/v3"

async def fetch(path: str, params: dict = None):
    headers = {"x-cg-pro-api-key": API_KEY} if API_KEY else {}
    async with httpx.AsyncClient(timeout=10) as client:
        res = await client.get(f"{BASE}{path}", headers=headers, params=params)
        res.raise_for_status()
        return res.json()

@mcp.tool()
async def get_coin_price(coin_id: str, vs_currency: str = "usd") -> str:
    """Prix actuel + variations (24h, 7d, 30d)."""
    data = await fetch(f"/coins/{coin_id}", {"localization": "false", "market_data": "true"})
    md = data["market_data"]
    return json.dumps({
        "id": coin_id,
        "price_usd": md["current_price"][vs_currency],
        "market_cap_usd": md["market_cap"][vs_currency],
        "change_24h_pct": md["price_change_percentage_24h"],
        "change_7d_pct": md.get("price_change_percentage_7d"),
        "change_30d_pct": md.get("price_change_percentage_30d"),
    })

@mcp.tool()
async def get_top_coins(limit: int = 10, vs_currency: str = "usd") -> str:
    """Top N coins par market cap."""
    data = await fetch("/coins/markets", {
        "vs_currency": vs_currency,
        "order": "market_cap_desc",
        "per_page": limit,
        "sparkline": "false"
    })
    summary = [{"id": c["id"], "symbol": c["symbol"], "price": c["current_price"], "mcap": c["market_cap"], "change_24h": c["price_change_percentage_24h"]} for c in data]
    return json.dumps(summary)

if __name__ == "__main__":
    mcp.run(transport="stdio")
```

### Cas d'usage typique

```
"BTC est à combien ? Compare avec sa moyenne sur 30j et donne-moi le RSI."
```

Claude Code :
1. Invoque `get_coin_price("bitcoin")` (CoinGecko MCP)
2. Pour le RSI : invoque `get_price("BTC-USD", period="1mo")` (yfinance MCP)
3. Calcule le RSI (ou utilise un sub-skill custom)
4. Synthétise

### Disclaimers

Les prix CoinGecko ont quelques minutes de délai. Pour décisions d'execution réelles : utilise l'API d'un exchange direct (Binance, Coinbase, etc.).

---

## Module 03 — MCP on-chain : Glassnode + Dune (🔴, 50 min lecture + 25 min pratique)

### MCP Glassnode (métriques on-chain Bitcoin / Ethereum)

```python
# mcps/glassnode/server.py
import os
import httpx
import json
from mcp.server.fastmcp import FastMCP

mcp = FastMCP("glassnode")

API_KEY = os.environ["GLASSNODE_API_KEY"]
BASE = "https://api.glassnode.com/v1"

@mcp.tool()
async def get_metric(metric: str, asset: str = "BTC", since_days: int = 30) -> str:
    """
    Récupère une métrique on-chain Glassnode.
    Exemples métric : 'addresses/active_count', 'market/marketcap_usd', 'indicators/sopr'.
    """
    import time
    since = int(time.time()) - since_days * 86400
    async with httpx.AsyncClient(timeout=15) as client:
        res = await client.get(
            f"{BASE}/metrics/{metric}",
            params={"a": asset, "s": since, "api_key": API_KEY}
        )
        if not res.ok:
            return json.dumps({"error": f"api_error_{res.status_code}", "metric": metric})
        data = res.json()
    return json.dumps(data[-30:])  # last 30 points
```

### MCP Dune (queries SQL custom)

```python
# mcps/dune/server.py
import os
import httpx
import json
from mcp.server.fastmcp import FastMCP

mcp = FastMCP("dune")

API_KEY = os.environ["DUNE_API_KEY"]
BASE = "https://api.dune.com/api/v1"

@mcp.tool()
async def execute_query(query_id: int, parameters: dict = None) -> str:
    """Exécute une query Dune existante par son ID. Renvoie résultats."""
    async with httpx.AsyncClient(timeout=60) as client:
        # Trigger execution
        res = await client.post(
            f"{BASE}/query/{query_id}/execute",
            headers={"x-dune-api-key": API_KEY},
            json={"query_parameters": parameters or {}}
        )
        execution_id = res.json()["execution_id"]

        # Poll for results
        while True:
            status = await client.get(
                f"{BASE}/execution/{execution_id}/status",
                headers={"x-dune-api-key": API_KEY}
            )
            state = status.json()["state"]
            if state == "QUERY_STATE_COMPLETED":
                break
            if state.startswith("QUERY_STATE_FAILED"):
                return json.dumps({"error": "query_failed"})

        results = await client.get(
            f"{BASE}/execution/{execution_id}/results",
            headers={"x-dune-api-key": API_KEY}
        )
        rows = results.json()["result"]["rows"]
        return json.dumps(rows[:50])  # max 50 rows

@mcp.tool()
async def get_query(query_id: int) -> str:
    """Récupère les derniers résultats d'une query Dune (cached)."""
    async with httpx.AsyncClient(timeout=30) as client:
        res = await client.get(
            f"{BASE}/query/{query_id}/results",
            headers={"x-dune-api-key": API_KEY}
        )
        return json.dumps(res.json()["result"]["rows"][:50])
```

### Cas d'usage type

```
"Quelle est la SOPR Bitcoin actuelle ? Et l'évolution sur 30j ?"
```

Claude Code → Glassnode MCP → `get_metric("indicators/sopr", "BTC", 30)` → analyse + interprétation.

```
"Lance la query Dune #1234567 (mes top wallets ETH) et résume."
```

Claude Code → Dune MCP → `execute_query(1234567)` → résumé structuré.

### Sécurité

- API keys en env, jamais hardcoded
- Rate limit côté MCP (limiter à X requêtes/min)
- Audit log de chaque query (utile pour comprendre coûts API)

---

## Module 04 — Skills d'analyse macro (🔴, 40 min lecture + 20 min pratique)

### Skill `fed-meeting-analyzer`

```yaml
---
name: fed-meeting-analyzer
description: Analyse les minutes/statements de la FED, détecte les changements de ton (hawkish/dovish) et signale les implications pour les actifs (USD, taux, actions, gold, BTC). Trigger quand l'utilisateur mentionne "FOMC", "FED", "Powell", "minutes FOMC", "FED dot plot".
---

# FED Meeting Analyzer

## Quand t'appliquer
- Documents FED (minutes, statements, speeches)
- Demande explicite d'analyse hawkish/dovish

## Méthode
1. Identifier les changements vs meeting précédent (mots-clés à comparer)
2. Détecter les indicateurs hawkish (inflation persistante, marché du travail tendu, "patient", "data dependent" → durée)
3. Détecter les indicateurs dovish (signe de ralentissement, mention de cuts, "well-positioned to ease")
4. Évaluer le ton global (échelle -2 dovish à +2 hawkish)
5. Implications par actif

## Format de sortie

```
### FED Meeting Analysis — [DATE]

**Ton global** : [score -2 à +2] [interprétation]

**Changements clés vs meeting précédent**
- ...

**Hawkish signals**
- ...

**Dovish signals**
- ...

**Implications par actif**
- USD : ...
- US 2y : ...
- US 10y : ...
- SPX : ...
- Gold : ...
- BTC : ...

**Disclaimer** : ce n'est pas un conseil d'investissement.
```
```

### Skill `cot-report-analyzer`

Pour le COT (Commitments of Traders) report hebdomadaire de la CFTC :

```yaml
---
name: cot-report-analyzer
description: Analyse le COT report de la CFTC pour détecter positionnements extrêmes (large speculators vs commercials). Trigger quand mentionné "COT", "Commitments of Traders", "large specs", "commercial hedgers".
---
```

Pareil pour : ISM, NFP, CPI, retail sales, PMI Eurozone, etc.

### Démo

Skill `nfp-analyzer` qui se déclenche le 1er vendredi du mois quand on parle de "Non-Farm Payrolls" et qui :
- Récupère le headline number, le révisé, le unemployment rate
- Compare aux estimations consensus
- Évalue surprise (positive/negative)
- Implications taux + USD

---

## Module 05 — Backtests Pine Script générés (🔴, 50 min lecture + 25 min pratique)

### Pourquoi Pine Script via Claude Code

Pine Script v5 = langage TradingView pour stratégies + indicateurs. Syntaxe spécifique. Claude Code génère 80 % du code valide directement.

### Skill `pine-script-generator`

```yaml
---
name: pine-script-generator
description: Génère du Pine Script v5 valide pour stratégie ou indicateur TradingView. Trigger quand l'utilisateur demande "stratégie Pine Script", "indicateur TradingView", "backtest Pine".
---
```

### Exemple : stratégie trend-following simple

Prompt :
```
Génère une stratégie Pine Script v5 :
- Entrée long : prix > MA200 ET RSI(14) cross above 50
- Sortie : RSI(14) cross below 70 OU stop loss à -5%
- Position size : 100% equity
- Affiche backtest stats (PnL, drawdown, sharpe)
```

Sortie attendue (Claude Code génère) :
```pinescript
//@version=5
strategy("Trend Following + RSI", overlay=true, initial_capital=10000, default_qty_type=strategy.percent_of_equity, default_qty_value=100)

// Inputs
maLength = input.int(200, "MA Length")
rsiLength = input.int(14, "RSI Length")
stopLossPct = input.float(5.0, "Stop Loss %") / 100

// Indicators
ma = ta.sma(close, maLength)
rsi = ta.rsi(close, rsiLength)

// Conditions
longCondition = close > ma and ta.crossover(rsi, 50)
exitCondition = ta.crossunder(rsi, 70)

// Trades
if longCondition
    strategy.entry("Long", strategy.long)

if exitCondition
    strategy.close("Long")

// Stop loss
strategy.exit("SL", "Long", stop = strategy.position_avg_price * (1 - stopLossPct))

// Plot
plot(ma, color=color.blue, linewidth=2)
```

### Anti-patterns Pine Script

- Lookahead bias (`barmerge.lookahead_on` mal utilisé)
- Ne pas tester sur multiple timeframes
- Backtester sur 1000 barres de bull market et conclure que la stratégie marche
- Oublier les fees / slippage dans les paramètres `strategy()`

### Disclaimers obligatoires

Aucun backtest ≠ live trading. La performance passée ne garantit pas la performance future. Toute stratégie générée est un point de départ, pas un signal.

---

## Module 06 — Dashboards trading (Marimo / Streamlit) (🟡, 40 min lecture + 20 min pratique)

### Marimo vs Streamlit

- **Marimo** : notebook reactif moderne, code Python pur, idéal pour exploration
- **Streamlit** : app web interactive, plus riche en widgets, idéal pour dashboard partageable

Pour démarrer : Marimo (gratuit, exécution locale, pas d'auth nécessaire).

### Dashboard "PnL temps réel" en Marimo

```python
import marimo as mo
import yfinance as yf
import pandas as pd

# Cell 1 : config
tickers = mo.ui.multiselect(["BTC-USD", "ETH-USD", "SPY", "QQQ", "GLD"], value=["BTC-USD", "ETH-USD"])
period = mo.ui.dropdown(["1mo", "3mo", "6mo", "1y", "ytd"], value="1y")

# Cell 2 : data fetch (auto-rerun quand inputs changent)
data = yf.download(tickers.value, period=period.value, progress=False)["Close"]
returns = (data / data.iloc[0] - 1) * 100

# Cell 3 : chart
import plotly.express as px
fig = px.line(returns, title="Returns %")
mo.ui.plotly(fig)

# Cell 4 : stats
stats = pd.DataFrame({
    "Total Return %": returns.iloc[-1],
    "Max Drawdown %": ((returns.cummax() - returns) / returns.cummax() * 100).max(),
    "Volatility %": returns.pct_change().std() * (252 ** 0.5) * 100
})
mo.ui.table(stats)
```

Lance :
```bash
marimo edit dashboard.py
```

### Hébergement

- **Local** : `marimo edit` puis serveur local
- **Marimo Cloud** : payant, hébergé
- **Streamlit Cloud** : gratuit, GitHub-deploy

### Sécurité

- Si dashboard contient ton PnL réel → auth obligatoire (Streamlit native auth ou reverse proxy)
- Pas de credentials de broker hardcoded (toujours env)

---

## Module 07 — Alertes Telegram + automation (🟡, 30 min lecture + 15 min pratique)

### Bot Telegram minimal

```python
# alerts/telegram_bot.py
import os
import asyncio
import httpx

BOT_TOKEN = os.environ["TELEGRAM_BOT_TOKEN"]
CHAT_ID = os.environ["TELEGRAM_CHAT_ID"]

async def send_alert(message: str, parse_mode: str = "Markdown"):
    async with httpx.AsyncClient() as client:
        await client.post(
            f"https://api.telegram.org/bot{BOT_TOKEN}/sendMessage",
            json={"chat_id": CHAT_ID, "text": message, "parse_mode": parse_mode}
        )
```

### Skill `send-telegram-alert`

```yaml
---
name: send-telegram-alert
description: Envoie une alerte Telegram si conditions de marché remplies. Trigger quand l'utilisateur demande "envoie alerte Telegram", "ping moi si X".
---

Quand on te demande d'envoyer une alerte :
1. Confirme la condition (ex : "BTC > 70k", "RSI 30m de SPY < 30")
2. Vérifie la condition via les MCPs data
3. Si remplie : appelle `python alerts/telegram_bot.py "<message>"`
4. Si pas remplie : reporte sans envoyer
```

### Cron pour alertes périodiques

```bash
# Crontab : check NFP au 1er vendredi du mois à 14h30
30 14 * * 5 cd /path/to/lab && /usr/bin/python alerts/check_nfp.py
```

`check_nfp.py` peut invoquer Claude Code en mode headless pour générer l'analyse + envoyer Telegram :
```bash
claude --print "Lance le skill nfp-analyzer pour aujourd'hui et envoie le résumé via send-telegram-alert"
```

### Sécurité

- Bot token = secret. Jamais dans le code, toujours env.
- Chat ID = ton ID privé ou un canal privé. Jamais public si tu envoies du PnL réel.
- Rate limit (Telegram : ~30 messages/sec max).

---

## Module 08 — Rapports institutionnels (🟡, 40 min lecture + 20 min pratique)

### Pourquoi rapports

Note hebdo macro/quant = livrable type d'un fonds boutique ou d'un consultant. Format PDF propre. 4-10 pages.

### Workflow

1. Skill `weekly-report` qui :
   - Liste les data à collecter (macro indicators, prix actifs surveillés, positions ouvertes)
   - Invoque les MCPs nécessaires
   - Génère le Markdown du rapport
2. Pandoc convertit Markdown → PDF avec template LaTeX

### Template Markdown rapport

```markdown
# Weekly Macro & Markets — Semaine du [DATE]

## Executive Summary
- 3-5 bullets

## Macro
### États-Unis
- FED, NFP, CPI, ISM
### Europe
- ECB, PMI, inflation
### Émergents / Asie
- Chine, Japon

## Marchés
### Actions
- Indices, sectoriels
### Taux
- US 2y/10y, courbe
### FX
- DXY, EUR, JPY
### Commodities
- Gold, Oil, Copper
### Crypto
- BTC, ETH, dominance, on-chain

## Positions actuelles (si applicable)
- Long / Short, taille, conviction

## Watchlist semaine prochaine
- 5-10 events à suivre

## Disclaimers
Ce document est fourni à titre informatif. Aucune information ici ne constitue un conseil d'investissement personnalisé. La performance passée ne garantit pas la performance future.
```

### Conversion PDF

```bash
pandoc weekly-report.md -o weekly-report.pdf \
  --pdf-engine=xelatex \
  --template=template.latex \
  --variable=geometry:margin=2cm \
  --toc
```

`template.latex` peut être customisé pour ajouter logo, footer, header.

### Démo

Skill `weekly-report` lancé un dimanche soir → 30 min plus tard, PDF prêt à envoyer aux clients/lecteurs.

---

## Module 09 — Conclusion + croissance (🟢, 15 min)

### Récap

Tu as :
- Lab quant avec MCPs custom (data prix + on-chain + macro)
- Skills d'analyse macro auto-déclenchés
- Backtests Pine Script générés rapidement
- Dashboards Marimo / Streamlit
- Alertes Telegram automatiques
- Pipeline rapport PDF

### Plan 90 jours

S1-S2 : MCP yfinance + CoinGecko en place
S3-S4 : MCP Glassnode + Dune (si payant, sinon skip)
S5-S6 : 2-3 skills d'analyse macro
S7-S8 : 1 stratégie Pine Script complète backtested
S9-S10 : Dashboard Marimo + alertes Telegram opérationnels
S11-S12 : 1 rapport hebdo PDF généré + envoyé

### Monétisation possible

- Newsletter macro/quant payante (Substack)
- Discord/Patreon avec alertes premium
- Consulting pour fonds qui veulent se moderniser
- SaaS dashboard pour traders indépendants

Cf. F3 module 07 pour modèles génériques.

### Vers où ensuite

- F3 (`skills-mcp-builder-pro/`) si tu veux monétiser tes MCPs au-delà de la finance
- F5 (`ai-agency-toolkit/`) si tu vises consulting fonds
- F2 (`solo-founder-stack/`) si tu construis un produit (newsletter SaaS, terminal, etc.)

### Final

Quant/macro indé n'est pas un sprint. C'est une discipline.

L'outillage te donne du levier. Reste à appliquer ta thèse.

Bonne recherche.
