# Solutions — Quant & Macro

## Ex 01 — MCP yfinance + CoinGecko
Code complet dans `modules/all-modules.md` section Module 02.
Settings :
```json
{
  "mcpServers": {
    "yfinance": { "command": "python", "args": ["./mcps/yfinance/server.py"] },
    "coingecko": { "command": "python", "args": ["./mcps/coingecko/server.py"], "env": { "COINGECKO_API_KEY": "" } }
  }
}
```
Test attendu : Claude Code répond avec données alignées avec ce que tu vois sur Yahoo Finance / CoinGecko web.

## Ex 02 — Skill macro
Voir module 04 pour `fed-meeting-analyzer` complet. Adapter pour NFP/CPI/COT en suivant la même structure (description précise, Méthode, Format de sortie, Disclaimers).

Test triggering : 3 prompts type "Donne-moi ton analyse du dernier FOMC", "Le statement Powell d'hier était hawkish ou dovish ?", "Comment lire les minutes de la FED de janvier ?".

## Ex 03 — Pine Script
Voir module 05 pour stratégie type. Test sur TradingView : copier dans Pine Editor, ajouter au chart, ouvrir Strategy Tester.

Stats à documenter :
- Net Profit / Equity initial
- Max Drawdown
- Sharpe Ratio
- Win Rate
- Profit Factor
- Nb trades

Si performance trop belle : suspect d'overfitting ou de lookahead bias. Tester sur out-of-sample (autre période).

## Ex 04 — Dashboard Marimo
Code complet dans module 06.
```bash
pip install marimo yfinance pandas plotly
marimo edit dashboard.py
```

## Ex 05 — Bot Telegram + cron
Setup bot : créer via @BotFather Telegram, récupérer token. Récupérer ton chat_id via @userinfobot.

```python
# alerts/morning_snapshot.py
import asyncio, os
from telegram_bot import send_alert
import yfinance as yf

async def main():
    tickers = ["BTC-USD", "SPY", "QQQ", "GLD"]
    data = yf.download(tickers, period="2d", progress=False)["Close"]
    msg = "*Morning Snapshot*\n\n"
    for t in tickers:
        last = data[t].iloc[-1]
        prev = data[t].iloc[-2]
        change = ((last / prev) - 1) * 100
        msg += f"{t}: ${last:.2f} ({change:+.2f}%)\n"
    await send_alert(msg)

asyncio.run(main())
```

Crontab :
```
0 9 * * 1-5 cd /path/to/lab && /usr/bin/python alerts/morning_snapshot.py
```
