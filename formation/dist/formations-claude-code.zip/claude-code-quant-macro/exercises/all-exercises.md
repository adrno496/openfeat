# Exercices — Quant & Macro

5 exercices.

---

## Ex 01 — Setup MCP yfinance + CoinGecko (🔴, 2h)
Construis et branche les 2 MCP servers du module 02. Test : "Compare la perf YTD de SPY, BTC, ETH, GLD".

**Critères** : 2 MCPs fonctionnels, requête depuis Claude Code donne données cohérentes.

## Ex 02 — Skill macro analyzer (🔴, 1h30)
Crée 1 skill d'analyse macro auto-déclenché (FED meeting OU NFP OU CPI OU COT, ton choix). Test sur 3 prompts.

**Critères** : skill se déclenche correctement sur 2/3 prompts, output structuré.

## Ex 03 — Stratégie Pine Script (🔴, 2h)
Génère une stratégie Pine Script v5 (trend-following + RSI ou autre) avec Claude Code. Backteste sur TradingView. Documente : trades, PnL, drawdown, sharpe.

**Critères** : Pine Script valide compile sans erreur, backtest sur 2+ ans de données, stats documentées.

## Ex 04 — Dashboard Marimo (🟡, 1h30)
Construis un dashboard Marimo qui affiche : prix temps réel de tes 5 actifs surveillés + perf YTD + drawdown.

**Critères** : Marimo lance sans erreur, dashboard affiche les 5 actifs avec stats à jour.

## Ex 05 — Bot Telegram + cron (🟡, 1h)
Configure le bot Telegram + cron qui envoie chaque matin à 9h le snapshot de marché.

**Critères** : message Telegram reçu chaque matin avec snapshot des actifs.
