# Syllabus — Claude Code Quant & Macro

8 modules. ~10h.

## M00 — Introduction
🟢 — 15 min — Pour qui, philosophie research-as-code, disclaimers.

## M01 — Architecture lab quant
🟡 — 50 min — Stack data + analyse + alerting + reporting. Sources data (TradingView, yfinance, CoinGecko, Glassnode, Dune). Coûts.

## M02 — MCP servers data : yfinance + CoinGecko
🔴 — 75 min — Construire 2 MCP servers Python pour data prix/marché crypto + actions.

## M03 — MCP server on-chain : Glassnode + Dune
🔴 — 75 min — Data crypto on-chain. Auth API, queries, parsing.

## M04 — Skills d'analyse macro
🔴 — 60 min — Skills auto-déclenchés pour analyse FED, ECB, ISM, NFP, COT report, etc.

## M05 — Backtests Pine Script générés
🔴 — 75 min — Générer du Pine Script v5 valide depuis Claude Code, debug, optimisation.

## M06 — Dashboards trading (Marimo / Streamlit)
🟡 — 60 min — Dashboards interactifs pour suivre PnL, positions, alertes. Hébergement.

## M07 — Alertes Telegram + automation
🟡 — 45 min — Bot Telegram, alertes conditionnelles, intégration MCP.

## M08 — Rapports institutionnels
🟡 — 60 min — Génération de notes hebdo / mensuelles. Templates LaTeX/Markdown → PDF.

## M09 — Conclusion + plan croissance
🟢 — 15 min — Récap, plan 90 jours, monétisation possible.

## Total

~10h structuré + 10-15h pratique selon profondeur.
