# CLAUDE.md — Astro + Content Collections

## Stack
- Astro 4+
- Markdown + MDX pour contenu (`src/content/`)
- Tailwind CSS
- Déploiement : Vercel ou Cloudflare Pages

## Conventions code
- Indentation 2 espaces, quotes simples, sans point-virgule
- Composants `.astro`, pas de React/Vue (sauf island justifié)
- Slugs en kebab-case
- Frontmatter Markdown : champs typés via Content Collection schema

## Trucs à ne pas faire
- Pas d'island JavaScript sans raison (perf SEO)
- Pas de modification du content schema sans confirmer (régénération full)
- Pas de framework client (React, Vue) ajouté
- Pas d'inline-styles (Tailwind only)

## Commandes utiles
- `npm run dev` — :4321
- `npm run build && npm run preview` — test prod local
- `npm run check` — type check Astro
- `npm run astro -- add <integration>` — ajouter intégration
