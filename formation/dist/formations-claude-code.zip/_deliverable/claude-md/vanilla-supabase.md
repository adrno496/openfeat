# CLAUDE.md — Vanilla JS + Supabase

## Stack
- Frontend : Vanilla JS (ES Modules natifs, pas de bundler)
- Mobile : Capacitor 6 (si applicable)
- Backend : Supabase (Postgres + Auth + Storage + Edge Functions)
- Paiements : Lemonsqueezy (web) + RevenueCat (mobile)
- Hébergement : Vercel + Play Store

## Conventions code
- Indentation 2 espaces, quotes simples, sans point-virgule
- ES Modules natifs, pas de require, pas de bundler
- Pas de framework JS (React, Vue, Svelte) ajouté sans validation explicite
- Tests : Vitest pour utils, Playwright pour e2e

## Règles métier non-négociables
- is_premium muté UNIQUEMENT via RPC `set_premium_status` côté serveur
- Toute table publique a RLS activé
- Aucun select('*'), toujours colonnes explicites
- Abonnements mobile : RevenueCat → webhook → Supabase
- Abonnements web : Lemonsqueezy → webhook → Supabase

## Sécurité
- CSP strict en prod (pas de unsafe-inline ni unsafe-eval)
- Sanitize tout input utilisateur avant innerHTML, ou utiliser textContent
- Variables client : aucun secret (anon key OK, service key JAMAIS)
- Service key Supabase : Edge Functions seulement
- Webhook signatures vérifiées avant logique métier

## Trucs à ne pas faire
- Pas de require, pas de bundler, pas de framework JS
- Pas de select('*') Supabase
- Pas de mutation is_premium côté client
- Pas de innerHTML avec input utilisateur sans escapeHtml
- Pas de secret en variable d'env client

## Commandes utiles
- `npx serve public/` — serveur local
- `npx supabase start/stop` — Postgres local
- `npx supabase migration new <nom>` — nouvelle migration
- `npx supabase functions deploy <fn> --no-verify-jwt` — déployer webhook
- `npx cap sync android` — sync Capacitor
- `git push` — Vercel auto-deploy
