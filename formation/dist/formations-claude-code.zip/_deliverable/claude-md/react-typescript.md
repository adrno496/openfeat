# CLAUDE.md — React + TypeScript (Vite/Next)

## Stack
- Frontend : React 18+ + TypeScript strict
- Build : Vite (ou Next.js selon projet)
- State : Zustand ou React Context (pas Redux sauf besoin spécifique)
- Backend : [à préciser : Supabase / API Node / Fastify]
- Tests : Vitest + Testing Library

## Conventions code
- Indentation 2 espaces, quotes simples, sans point-virgule
- TypeScript strict, jamais `any` sans commentaire d'exception
- Composants en PascalCase (.tsx), hooks en camelCase préfixés `use`
- Imports : libs externes / libs internes / locaux, séparés par lignes vides

## Architecture
- `src/components/` — composants réutilisables
- `src/features/<feature>/` — composants + hooks + services par feature
- `src/lib/` — utilitaires partagés
- `src/types/` — types TypeScript globaux

## Trucs à ne pas faire
- Pas de `any` non commenté
- Pas de `dangerouslySetInnerHTML` avec données externes
- Pas de prop drilling au-delà de 2 niveaux → state ou context
- Pas de side-effect dans render (toujours useEffect)
- Pas de secret en `.env.local` committé

## Commandes utiles
- `npm run dev`
- `npm run build`
- `npm run test`
- `npm run typecheck`
- `npm run lint`
