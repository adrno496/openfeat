# CLAUDE.md — Python + FastAPI

## Stack
- Backend : FastAPI 0.110+
- Python 3.11+
- DB : SQLAlchemy 2 + Alembic (Postgres)
- Tests : pytest + httpx async

## Conventions code
- Indentation 4 espaces
- Type hints partout (PEP 484+)
- f-strings, jamais `.format()` ou `%`
- snake_case pour fonctions/variables, PascalCase pour classes
- Imports : stdlib / third-party / local, groupés et triés

## Architecture
- `app/main.py` — point d'entrée
- `app/api/v1/` — routes versionnées
- `app/models/` — modèles SQLAlchemy
- `app/schemas/` — Pydantic schemas (input/output)
- `app/services/` — logique métier
- `app/db/` — session, migrations
- `tests/` — pytest

## Trucs à ne pas faire
- Pas de query SQL en string concaténée (toujours paramétrée ou ORM)
- Pas de `print()` en prod (logger structuré)
- Pas de catch `Exception` générique sans re-raise
- Pas de fonction async qui appelle du blocking I/O sans `to_thread`
- Pas de secret hardcodé (toujours `os.environ` ou Pydantic Settings)

## Commandes utiles
- `uv venv` puis `source .venv/bin/activate`
- `uv pip install -e ".[dev]"`
- `uvicorn app.main:app --reload`
- `pytest`
- `alembic revision --autogenerate -m "..."`
- `alembic upgrade head`
