# CLAUDE.md — Monorepo (racine)

Conventions générales du monorepo. Chaque sous-projet a aussi son propre `CLAUDE.md` plus spécifique.

## Structure
```
mon-monorepo/
├── apps/
│   ├── web/          (CLAUDE.md spécifique)
│   ├── api/          (CLAUDE.md spécifique)
│   └── mobile/
├── packages/
│   ├── shared/
│   └── ui/
├── CLAUDE.md         (ce fichier)
└── package.json
```

## Outils
- pnpm workspaces (ou npm/yarn workspaces)
- Turborepo (ou Nx) pour orchestration
- TypeScript strict en racine, héritage par projet

## Conventions générales
- 2 espaces, quotes simples, sans point-virgule
- TS strict partout
- Tests obligatoires pour chaque package
- Commits avec scope du package : `feat(web): ...`, `fix(api): ...`

## Trucs à ne pas faire
- Pas de dépendance circulaire entre packages
- Pas d'import depuis `apps/X` vers `apps/Y` (passer par `packages/shared`)
- Pas de version désynchronisée des libs partagées
- Pas de mutation de `packages/shared` sans tests à jour

## Commandes utiles
- `pnpm install` — install racine
- `pnpm -r build` — build tous les packages
- `pnpm --filter web dev` — lancer un seul app
- `pnpm -r test` — tests sur tous les packages
- `pnpm changeset` — créer un changeset (versionning)
