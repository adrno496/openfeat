---
name: ship
description: Workflow complet pour shipper une PR (lint, tests, commit, push, PR via gh).
---

Workflow de ship :

1. Affiche le résumé : `git diff main` (ou master), liste fichiers modifiés
2. Lance lint : `npm run lint` (si configuré)
3. Lance tests : `npm test` (ou commande équivalente du projet)
4. Si lint ou tests échouent → stop, demande-moi de fixer
5. Génère un commit message conventionnel depuis le diff staged (cf. /commit)
6. Demande-moi confirmation avant de commit
7. Push la branche : `git push -u origin <branche>`
8. Crée la PR via `gh pr create --fill` (ou `--web` si tu veux ouvrir le browser)
9. Vérifie que la preview Vercel/CI build sans erreur

Ne push **jamais** sans avoir lancé tests + lint.
Ne commit **jamais** sans avoir montré le message et reçu validation.
