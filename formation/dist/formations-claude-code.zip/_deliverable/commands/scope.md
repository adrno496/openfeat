---
name: scope
description: Décrit le scope d'une tâche avant de l'attaquer. Liste fichiers à modifier, risques, estimation effort.
---

Tâche à scoper : $ARGUMENTS

Avant de coder quoi que ce soit, rapporte :

1. **Fichiers à modifier** (avec lignes approximatives) : liste précise
2. **Nouveaux fichiers à créer** : liste avec rôle de chacun
3. **Dépendances à ajouter** (le cas échéant) : packages npm/pip/etc
4. **Risques de régression** : zones du code potentiellement affectées
5. **Estimation effort** : faible (< 30 min) / moyen (30 min - 2h) / fort (> 2h)
6. **Questions ouvertes** : ambiguïtés à clarifier avant d'attaquer

Ne touche à aucun fichier. Attends ma validation explicite pour passer à l'exécution.
