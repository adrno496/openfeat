---
name: review-pr
description: Review du diff entre la branche courante et main, avec rapport structuré bugs / sécu / dupli.
---

Lis tous les fichiers modifiés sur la branche courante par rapport à `main` (ou `master` selon convention du projet).

Pour chaque fichier modifié, rapporte :
- bugs potentiels (null, race condition, off-by-one)
- failles de sécurité (XSS, SQL injection, secrets en clair, validation manquante)
- duplications avec d'autres fichiers
- patterns incohérents avec le reste du projet (vérifie `CLAUDE.md`)

Format de sortie :
- 1 section par fichier
- Niveau de gravité par item : critique / moyen / faible
- Suggestions de fix concrètes (sans modifier le code)

À la fin :
- recommandation globale : OK pour push / corrections nécessaires
- si > 30 fichiers modifiés : recommande de splitter la PR

Ne modifie aucun fichier.
