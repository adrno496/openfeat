---
name: from-issue
description: Démarre l'implémentation depuis une issue GitHub (numéro d'issue en argument).
---

Issue à traiter : #$ARGUMENTS

1. Lis le contenu complet de l'issue : `gh issue view $ARGUMENTS`
2. Identifie le type (bug fix, feature, chore, refactor) → choisis le préfixe de branche : `fix/`, `feat/`, `chore/`, `refactor/`
3. Crée la branche : `git checkout -b <prefixe>/<num>-<slug-court>`
4. Décris le scope avant de coder :
   - fichiers à modifier
   - nouveaux fichiers
   - dépendances
   - estimation effort
5. Attends ma validation explicite avant de toucher au code.

Si l'issue est ambiguë, liste les questions ouvertes pour que je clarifie.
