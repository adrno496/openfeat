---
name: commit
description: Génère un commit message au format Conventional Commits depuis le diff staged.
---

Lis le diff staged via `git diff --staged`.

Génère un commit message conventionnel :
- Format : `type(scope): description`
- Types : feat, fix, refactor, chore, docs, test, perf, build, ci, style
- Max 72 caractères
- Pas de point final
- Impératif présent ("add" pas "added")
- Scope optionnel mais recommandé (le module/dossier touché)

Affiche **uniquement** le message, sans explication, sans markdown, sans guillemets.

Si rien n'est staged, dis-le et arrête-toi.
