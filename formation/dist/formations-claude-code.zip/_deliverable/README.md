# 📦 Deliverable — Skills, MCPs et configurations prêts à l'emploi

Ce dossier contient **tous les fichiers que l'apprenant peut copier-coller directement** dans son projet pour démarrer.

Pas de configuration à faire. Pas de code à écrire. Tu copies, tu colles, ça marche.

---

## Pour qui

Apprenant qui vient d'acheter une formation (F1 à F6) et veut **commencer immédiatement** sans tout construire from scratch.

---

## Comment utiliser

### Méthode A — Démarrage rapide (recommandé)

```bash
# 1. Créer le dossier .claude/ dans TON projet
cd ~/projects/mon-projet
mkdir -p .claude

# 2. Copier les skills, agents, commandes que tu veux utiliser
cp -r /chemin/vers/_deliverable/skills/* .claude/skills/
cp -r /chemin/vers/_deliverable/agents/* .claude/agents/
cp -r /chemin/vers/_deliverable/commands/* .claude/commands/

# 3. Copier le settings.json template (à adapter)
cp /chemin/vers/_deliverable/settings/settings.json.template .claude/settings.json

# 4. Lance Claude Code
claude
```

### Méthode B — Cherry-pick

Tu n'as pas besoin de tout. Choisis dans le dossier ce qui correspond à ton stack et à ta formation.

```
_deliverable/
├── skills/                          # Skills auto-déclenchés (formation F3 + F1)
│   ├── csp-auditor/
│   ├── supabase-rls-checker/
│   ├── commit-conventional/
│   └── pre-deploy-check/
│
├── agents/                          # Sub-agents personnalisés (formation F1)
│   ├── explorer.md
│   ├── code-reviewer.md
│   └── security-auditor.md
│
├── commands/                        # Slash commands custom (formation F1, F5)
│   ├── scope.md
│   ├── commit.md
│   ├── review-pr.md
│   ├── from-issue.md
│   └── ship.md
│
├── settings/                        # Templates settings.json (F1, F2, F5)
│   ├── settings.minimal.json        # Démarrage simple
│   ├── settings.team.json           # Standards équipe (deny + hooks)
│   └── settings.local.json.template # Overrides perso (gitignored)
│
├── claude-md/                       # Templates CLAUDE.md par stack
│   ├── vanilla-supabase.md          # F2 stack
│   ├── react-typescript.md
│   ├── python-fastapi.md
│   ├── astro-content.md
│   └── monorepo.md
│
├── mcp-servers/                     # MCP servers fonctionnels (F3)
│   ├── lemonsqueezy-py/             # Python, stdio
│   ├── lemonsqueezy-ts/             # TypeScript, stdio
│   ├── supabase-helper-py/          # Python, stdio
│   └── github-issues-ts/            # TypeScript, stdio
│
├── starters/                        # Starters de projet (F2)
│   ├── solo-founder-vanilla/        # Squelette complet F2
│   ├── agency-toolkit/              # Squelette F5
│   └── quant-lab/                   # Squelette F4
│
└── GUIDE-INSTALLATION.md            # Guide pas à pas d'installation
```

---

## Ce que chaque dossier contient

### `skills/`
Chaque sous-dossier = 1 skill complet, avec `SKILL.md` (frontmatter optimisé) + `reference/` + `examples/` quand pertinent.

À copier dans `<ton-projet>/.claude/skills/<nom>/` (projet) ou `~/.claude/skills/<nom>/` (global).

### `agents/`
Sub-agents prêts. Chaque fichier `.md` est autonome.

À copier dans `<ton-projet>/.claude/agents/` ou `~/.claude/agents/`.

### `commands/`
Slash commands. Invocation par `/<nom>`.

À copier dans `<ton-projet>/.claude/commands/` ou `~/.claude/commands/`.

### `settings/`
Templates `settings.json`. Choisir selon contexte :
- `minimal` : juste le modèle + permissions de base
- `team` : standards équipe (deny destructeurs, hooks audit, hook auto-format)
- `local.template` : pour les overrides perso (à renommer en `settings.local.json` et gitignorer)

### `claude-md/`
Templates `CLAUDE.md` par stack typique. Copier dans la racine de ton projet, adapter, commit.

### `mcp-servers/`
Sous-dossiers complets de MCP servers fonctionnels. Chaque dossier a son `README.md` qui explique comment l'installer et le brancher.

### `starters/`
Squelettes de projet complets, fork-ables. Au lieu de partir d'un repo vide, tu pars d'un starter qui contient déjà la bonne structure, les bons fichiers, les bonnes conventions.

---

## Ce dossier ≠ formation

Ce dossier est un **outillage**. Il accélère l'application de la formation.

Si tu copies les fichiers sans suivre la formation, tu auras un environnement Claude Code qui marche mais tu ne sauras ni adapter, ni étendre, ni dépanner. La formation t'apprend le **fond**.

---

## Mises à jour

Ce dossier est versionné séparément. Quand un nouveau skill / MCP / template est ajouté ou amélioré, l'apprenant reçoit la mise à jour via le portail de formation.

---

## Voir aussi

- `GUIDE-INSTALLATION.md` à la racine du dépôt — guide ultra-complet (équivalent PDF) pour installer, configurer et bien utiliser Claude Code de A à Z.
