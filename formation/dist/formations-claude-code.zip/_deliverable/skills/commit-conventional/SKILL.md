---
name: commit-conventional
description: Génère un commit message au format Conventional Commits depuis le diff staged. Trigger quand l'utilisateur demande "génère un commit", "commit message", "écris-moi un commit", après `git add` ou `git diff --staged`.
---

# Commit Conventional

## Quand t'appliquer

- Demande explicite de commit message
- Après détection d'un `git add` ou `git diff --staged` dans la session

## Méthode

1. Lire `git diff --staged` (si pas déjà dans le contexte)
2. Identifier le type de changement (feat, fix, refactor, etc.)
3. Identifier le scope (le module/dossier touché)
4. Rédiger une description courte impérative

## Règles dures

- **Format** : `type(scope): description`
- **Types autorisés** : feat, fix, refactor, chore, docs, test, perf, build, ci, style
- **Max 72 caractères** sur la première ligne
- **Pas de point final**
- **Impératif présent** : "add" pas "added", "fix" pas "fixes"
- **Scope optionnel mais recommandé** (le dossier ou le module touché)
- Si le diff touche plusieurs scopes différents : envisager `chore` ou suggérer de splitter le commit

## Format de sortie

Affiche **uniquement** le commit message, sans explication, sans guillemets, sans markdown.

Exemple :
```
feat(auth): add password reset endpoint with email token
```

Si le diff est trop large pour être résumé en 72 caractères, propose un body sur lignes suivantes :

```
refactor(api): extract validation helpers

Extract validateUserInput and validateEmail from controllers
into shared utils module. No behavioral change.
```

## Cas où NE PAS appliquer

- Si rien n'est staged → demander à l'utilisateur de stager
- Si l'utilisateur demande explicitement un autre format (ex : "messages courts sans scope")
