---
name: csp-auditor
description: Audite une politique CSP (Content-Security-Policy) et détecte les directives dangereuses (unsafe-inline, unsafe-eval, wildcards). Trigger quand l'utilisateur mentionne CSP, Content-Security-Policy, header de sécurité, csp.config, ou édite un fichier *.csp ou contenant l'expression Content-Security-Policy.
---

# CSP Auditor

## Quand t'appliquer

- L'utilisateur édite un fichier contenant une politique CSP (`vercel.json`, `next.config.js`, `nginx.conf`, `_headers`, etc.)
- L'utilisateur demande explicitement un audit CSP
- Une politique CSP apparaît dans le diff d'une PR

## Méthode

1. Identifier la chaîne CSP complète
2. Parser les directives (séparées par `;`)
3. Pour chaque directive, vérifier les sources/valeurs
4. Signaler les anti-patterns
5. Proposer une politique alternative si critique

## Règles dures

### Directives à signaler **critique**
- `unsafe-inline` dans `script-src` ou `default-src` → vulnérabilité XSS
- `unsafe-eval` → exécution de code arbitraire (eval, Function())
- `*` wildcard dans `script-src`, `object-src`, `default-src` → bypass complet
- `data:` dans `script-src` → vecteur XSS
- Absence totale de `default-src` → permissif par défaut

### Directives à signaler **moyen**
- `unsafe-inline` dans `style-src` (acceptable mais à noter)
- `'self'` sans précision sur les sous-domaines
- Absence de `frame-ancestors` (vulnérabilité clickjacking)

### Directives **bonnes pratiques**
- `frame-ancestors 'none'` ou `'self'`
- `default-src 'self'`
- `object-src 'none'`
- `base-uri 'self'`
- `form-action 'self'`

## Format de sortie

```
### Audit CSP

**Niveau global** : critique / moyen / acceptable / bon

**Directives problématiques** :
- [Critique] script-src 'unsafe-inline' → permet XSS via injection inline.
  Suggestion : retirer 'unsafe-inline', utiliser nonces ou hashes.
- [Moyen] frame-ancestors absent → clickjacking possible.
  Suggestion : ajouter frame-ancestors 'self'.

**Politique alternative recommandée** :
default-src 'self'; script-src 'self' [+sources spécifiques]; style-src 'self' 'unsafe-inline'; ...
```

## Cas où NE PAS appliquer

- Fichier dans `node_modules/` ou `.tmp/`
- CSP en mode `Report-Only` explicitement marquée "draft" par un commentaire
- Test fixtures dans `tests/`
