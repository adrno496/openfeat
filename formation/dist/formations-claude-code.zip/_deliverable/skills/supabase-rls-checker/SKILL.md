---
name: supabase-rls-checker
description: Audite les politiques RLS (Row Level Security) d'une migration Supabase pour éviter les fuites de données et les escalades de privilège. Trigger quand l'utilisateur édite un fichier dans supabase/migrations/, mentionne "RLS", "policy", "ENABLE ROW LEVEL SECURITY", ou demande "audit RLS", "review migration Supabase".
---

# Supabase RLS Checker

## Quand t'appliquer

- Édition d'un fichier dans `supabase/migrations/`
- Diff contenant `CREATE POLICY` ou `ENABLE ROW LEVEL SECURITY`
- Demande explicite d'audit RLS

## Méthode

1. Identifier toutes les tables concernées par la migration
2. Pour chaque table publique :
   - vérifier que RLS est activé
   - vérifier qu'au moins une policy SELECT existe
   - vérifier qu'aucune policy n'utilise `USING (true)` sans condition
   - vérifier les flags critiques (`is_premium`, `role`, `is_admin`) ne sont pas updatable côté client
3. Rapporter avec gravité

## Règles dures (à appliquer absolument)

- Toute table publique sans `ENABLE ROW LEVEL SECURITY` → **critique**
- Toute table avec RLS mais 0 policy → **critique** (table inaccessible)
- Toute policy `USING (true)` sans `WITH CHECK` complémentaire → **critique** (bypass)
- Toute policy UPDATE qui permet de modifier `is_premium`, `role`, `is_admin` côté client → **critique**

## Règles souples (à signaler)

- Policy SELECT sans condition `auth.uid()` → moyen
- Absence d'index sur les colonnes utilisées dans `USING` (perf) → faible
- Manque de policy DELETE → moyen (selon contexte)

## Format de sortie

```
### Audit RLS — <fichier>

#### [Critique]
- ligne X-Y : <issue>
  Suggestion : <fix concret>

#### [Moyen]
- ligne X : <issue>
  Suggestion : <fix>

#### [Faible]
- ligne X : <issue>

**Conclusion** : OK pour merge / corrections nécessaires avant merge.
```

## Cas où NE PAS appliquer

- Fichier hors `supabase/migrations/`
- Migration explicitement marquée "wip" dans le nom
- Test fixtures
