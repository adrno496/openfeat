---
name: pre-deploy-check
description: Vérifie qu'un projet est prêt pour le déploiement production. Trigger avant `git push origin main`, ou quand l'utilisateur dit "déploiement", "ship en prod", "release", "préparer une release".
---

# Pre-Deploy Check

## Quand t'appliquer

- Avant un push sur `main` ou `master`
- Demande explicite de check pré-déploiement
- Mention de "release", "ship", "prod"

## Méthode

Lance les vérifications dans cet ordre. **Stop au premier échec** et demande à l'utilisateur de fixer avant de continuer.

1. **Tests** : `npm test` (ou commande équivalente du projet, voir `CLAUDE.md`)
2. **Lint** : `npm run lint` (si configuré)
3. **Build** : `npm run build` (si applicable)
4. **Variables d'env** :
   - vérifier `.env.production` n'est pas dans `git status`
   - vérifier `.env*` est dans `.gitignore`
5. **Secrets** :
   - grep dans le diff entre la branche courante et main pour patterns de secrets (`sk_live_`, `api_key`, `password=`, `service_role`)
6. **Migrations** (si Supabase) :
   - vérifier que les nouvelles migrations sont dans `supabase/migrations/`
   - vérifier qu'elles ont été appliquées en local et testées
7. **CHANGELOG** (optionnel) :
   - rappeler à l'utilisateur de mettre à jour si présent

## Format de sortie

```
### Pre-Deploy Check

✓ Tests passants
✓ Lint passant
✓ Build OK
✓ Pas de secrets en clair
✓ .env non committé
✗ CHANGELOG non mis à jour (rappel — non bloquant)

**Status** : OK pour déployer / Corrections nécessaires
```

## Règles dures

- Si tests échouent → **bloquant**
- Si secret en clair détecté → **bloquant**
- Si `.env` apparaît dans `git status` → **bloquant** (rappeler `.gitignore`)
- Si migration sans test local → **avertissement fort**

## Cas où NE PAS appliquer

- Push sur une branche feature (uniquement `main`/`master`/`production`)
- Si l'utilisateur a explicitement marqué `--skip-precheck` (à éviter)
