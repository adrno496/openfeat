import { Server } from '@modelcontextprotocol/sdk/server/index.js'
import { StdioServerTransport } from '@modelcontextprotocol/sdk/server/stdio.js'
import { z } from 'zod'

const TOKEN = process.env.GITHUB_TOKEN
const REPO = process.env.GITHUB_REPO

if (!TOKEN || !REPO) {
  console.error('ERROR: GITHUB_TOKEN or GITHUB_REPO missing')
  process.exit(1)
}

const BASE = 'https://api.github.com'
const HEADERS = {
  'Authorization': `Bearer ${TOKEN}`,
  'Accept': 'application/vnd.github+json',
  'X-GitHub-Api-Version': '2022-11-28'
}

const ListIssuesInput = z.object({
  state: z.enum(['open', 'closed', 'all']).default('open'),
  label: z.string().optional(),
  limit: z.number().int().min(1).max(100).default(20)
})

const GetIssueInput = z.object({ number: z.number().int().positive() })

const CreateIssueInput = z.object({
  title: z.string().min(1).max(256),
  body: z.string().min(1).max(65536),
  labels: z.array(z.string()).max(10).optional()
})

const server = new Server(
  { name: 'github-issues', version: '1.0.0' },
  { capabilities: { tools: {} } }
)

server.setRequestHandler('tools/list', async () => ({
  tools: [
    {
      name: 'list_issues',
      description: `Liste les issues du repo ${REPO}`,
      inputSchema: {
        type: 'object',
        properties: {
          state: { type: 'string', enum: ['open', 'closed', 'all'] },
          label: { type: 'string' },
          limit: { type: 'number', minimum: 1, maximum: 100 }
        }
      }
    },
    {
      name: 'get_issue',
      description: `Récupère le détail d'une issue par numéro`,
      inputSchema: {
        type: 'object',
        properties: { number: { type: 'number' } },
        required: ['number']
      }
    },
    {
      name: 'create_issue',
      description: `Crée une issue (action mutative, demande confirmation à l'utilisateur)`,
      inputSchema: {
        type: 'object',
        properties: {
          title: { type: 'string' },
          body: { type: 'string' },
          labels: { type: 'array', items: { type: 'string' } }
        },
        required: ['title', 'body']
      }
    }
  ]
}))

server.setRequestHandler('tools/call', async (request) => {
  const { name, arguments: args } = request.params
  try {
    if (name === 'list_issues') {
      const parsed = ListIssuesInput.parse(args)
      const url = new URL(`${BASE}/repos/${REPO}/issues`)
      url.searchParams.set('state', parsed.state)
      url.searchParams.set('per_page', String(parsed.limit))
      if (parsed.label) url.searchParams.set('labels', parsed.label)
      const res = await fetch(url.toString(), { headers: HEADERS })
      if (!res.ok) throw new Error(`api_error: ${res.status}`)
      const data = (await res.json()) as Array<{ number: number; title: string; state: string; user: { login: string } }>
      const summary = data.map((i) => ({
        number: i.number,
        title: i.title,
        state: i.state,
        author: i.user.login
      }))
      return { content: [{ type: 'text', text: JSON.stringify(summary, null, 2) }] }
    }
    if (name === 'get_issue') {
      const parsed = GetIssueInput.parse(args)
      const res = await fetch(`${BASE}/repos/${REPO}/issues/${parsed.number}`, { headers: HEADERS })
      if (!res.ok) throw new Error(`api_error: ${res.status}`)
      return { content: [{ type: 'text', text: await res.text() }] }
    }
    if (name === 'create_issue') {
      const parsed = CreateIssueInput.parse(args)
      const res = await fetch(`${BASE}/repos/${REPO}/issues`, {
        method: 'POST',
        headers: { ...HEADERS, 'Content-Type': 'application/json' },
        body: JSON.stringify(parsed)
      })
      if (!res.ok) throw new Error(`api_error: ${res.status}`)
      const data = (await res.json()) as { number: number; html_url: string }
      return { content: [{ type: 'text', text: JSON.stringify({ number: data.number, url: data.html_url }) }] }
    }
    throw new Error(`Unknown tool: ${name}`)
  } catch (err) {
    return {
      content: [{ type: 'text', text: JSON.stringify({ error: (err as Error).message }) }],
      isError: true
    }
  }
})

const transport = new StdioServerTransport()
await server.connect(transport)
