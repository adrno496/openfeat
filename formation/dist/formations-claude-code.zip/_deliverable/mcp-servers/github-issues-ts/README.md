# MCP Server — GitHub Issues (TypeScript)

MCP stdio pour interagir avec les issues / PR GitHub d'un repo depuis Claude Code.

## Installation

```bash
cd mcp-servers/github-issues-ts
npm install
npm run build
```

## Configuration

`.claude/settings.local.json` :
```json
{
  "mcpServers": {
    "github": {
      "command": "node",
      "args": ["/chemin/vers/github-issues-ts/dist/server.js"],
      "env": {
        "GITHUB_TOKEN": "ghp_REPLACE_ME",
        "GITHUB_REPO": "owner/repo"
      }
    }
  }
}
```

Token GitHub : Settings → Developer settings → Personal access tokens (fine-grained, scope `repo` minimum).

## Tools

- `list_issues(state, label, limit)` — liste les issues
- `get_issue(number)` — détail d'une issue
- `create_issue(title, body, labels)` — crée une issue (avec validation stricte)

## Sécurité

- Token avec scope minimum (juste le repo cible)
- Validation Zod sur tous inputs
- `create_issue` demande confirmation côté Claude (via prompt user)
