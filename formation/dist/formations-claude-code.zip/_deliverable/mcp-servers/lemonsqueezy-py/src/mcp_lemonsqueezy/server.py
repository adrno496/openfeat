"""MCP server stdio pour Lemonsqueezy."""

import asyncio
import json
import os
import sys
from typing import Literal
import httpx
from pydantic import BaseModel, Field
from mcp.server.fastmcp import FastMCP

mcp = FastMCP("lemonsqueezy")

API_KEY = os.environ.get("LEMONSQUEEZY_API_KEY")
if not API_KEY:
    print("ERROR: LEMONSQUEEZY_API_KEY missing", file=sys.stderr)
    sys.exit(1)

STORE_ID = os.environ.get("LEMONSQUEEZY_STORE_ID")
BASE_URL = "https://api.lemonsqueezy.com/v1"
HEADERS = {
    "Authorization": f"Bearer {API_KEY}",
    "Accept": "application/vnd.api+json",
}


class ListSubscriptionsInput(BaseModel):
    status: Literal["active", "cancelled", "expired", "all"] = "active"
    limit: int = Field(default=10, ge=1, le=50)


class GetCustomerInput(BaseModel):
    customer_id: str = Field(min_length=1, max_length=64)


@mcp.tool()
async def list_subscriptions(status: str = "active", limit: int = 10) -> str:
    """Liste les abonnements Lemonsqueezy filtrés par statut.

    Args:
        status: 'active', 'cancelled', 'expired', ou 'all'
        limit: max 50
    """
    try:
        params = ListSubscriptionsInput(status=status, limit=limit)
    except Exception as e:
        return json.dumps({"error": "invalid_input", "details": str(e)})

    query = {"page[size]": params.limit}
    if params.status != "all":
        query["filter[status]"] = params.status
    if STORE_ID:
        query["filter[store_id]"] = STORE_ID

    async with httpx.AsyncClient(timeout=10.0) as client:
        try:
            res = await client.get(f"{BASE_URL}/subscriptions", headers=HEADERS, params=query)
            res.raise_for_status()
        except httpx.HTTPStatusError as e:
            return json.dumps({"error": "api_error", "status": e.response.status_code})
        except httpx.RequestError as e:
            return json.dumps({"error": "network_error", "details": str(e)})

    data = res.json().get("data", [])
    results = [
        {
            "id": s["id"],
            "email": s["attributes"].get("user_email"),
            "status": s["attributes"].get("status"),
            "product": s["attributes"].get("product_name"),
            "renews_at": s["attributes"].get("renews_at"),
        }
        for s in data
    ]
    return json.dumps(results, indent=2)


@mcp.tool()
async def get_customer(customer_id: str) -> str:
    """Récupère les infos d'un client Lemonsqueezy par ID."""
    try:
        params = GetCustomerInput(customer_id=customer_id)
    except Exception as e:
        return json.dumps({"error": "invalid_input", "details": str(e)})

    async with httpx.AsyncClient(timeout=10.0) as client:
        try:
            res = await client.get(f"{BASE_URL}/customers/{params.customer_id}", headers=HEADERS)
            res.raise_for_status()
        except httpx.HTTPStatusError as e:
            return json.dumps({"error": "api_error", "status": e.response.status_code})

    c = res.json()["data"]["attributes"]
    summary = {
        "email": c.get("email"),
        "name": c.get("name"),
        "status": c.get("status"),
        "country": c.get("country"),
        "total_revenue_currency": c.get("total_revenue_currency"),
        "mrr": c.get("mrr"),
    }
    return json.dumps(summary, indent=2)


@mcp.tool()
async def monthly_revenue() -> str:
    """Calcule le MRR à partir des abonnements actifs (en cents)."""
    query = {"filter[status]": "active", "page[size]": 100}
    if STORE_ID:
        query["filter[store_id]"] = STORE_ID

    async with httpx.AsyncClient(timeout=10.0) as client:
        try:
            res = await client.get(f"{BASE_URL}/subscriptions", headers=HEADERS, params=query)
            res.raise_for_status()
        except httpx.HTTPStatusError as e:
            return json.dumps({"error": "api_error", "status": e.response.status_code})

    total = 0
    for s in res.json().get("data", []):
        item = s["attributes"].get("first_subscription_item")
        if item and "price" in item:
            total += item["price"]
    return json.dumps({"mrr_cents": total, "subscription_count": len(res.json().get("data", []))})


def main():
    mcp.run(transport="stdio")


if __name__ == "__main__":
    main()
