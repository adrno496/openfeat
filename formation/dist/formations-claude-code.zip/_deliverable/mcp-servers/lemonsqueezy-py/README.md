# MCP Server — Lemonsqueezy (Python)

MCP server stdio en Python pour interagir avec l'API Lemonsqueezy depuis Claude Code.

## Installation

```bash
cd mcp-servers/lemonsqueezy-py
uv venv
uv pip install -e .
```

## Configuration côté Claude Code

`.claude/settings.local.json` (NE PAS commit) :

```json
{
  "mcpServers": {
    "lemonsqueezy": {
      "command": "uvx",
      "args": ["--from", "/chemin/absolu/vers/mcp-servers/lemonsqueezy-py", "mcp-lemonsqueezy"],
      "env": {
        "LEMONSQUEEZY_API_KEY": "ls_REPLACE_ME"
      }
    }
  }
}
```

Récupérer l'API key : Lemonsqueezy Dashboard → Settings → API.

## Tools exposés

- `list_subscriptions(status, limit)` — liste les abonnements filtrés
- `get_customer(customer_id)` — infos d'un customer
- `monthly_revenue()` — calcule le MRR depuis les abonnements actifs

## Test

```bash
uvx --from . mcp-lemonsqueezy
# (rien ne se passe — attend stdin, c'est normal)
```

Avec MCP Inspector :
```bash
npx @modelcontextprotocol/inspector uvx --from . mcp-lemonsqueezy
```

## Utilisation depuis Claude Code

Une fois branché, Claude Code peut invoquer automatiquement :
- "Combien d'abonnements actifs on a ?" → `list_subscriptions(status="active")`
- "Quel est notre MRR ?" → `monthly_revenue()`
- "Donne-moi les infos du customer cust_123" → `get_customer("cust_123")`

## Sécurité

- API key stockée en variable d'env, jamais hardcodée
- Limit max sur `list_subscriptions` (50)
- Validation Pydantic stricte des inputs
- Erreurs structurées (pas de stack trace exposé au client)
