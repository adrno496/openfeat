# MCP Server — Lemonsqueezy (TypeScript)

Version TypeScript du MCP server Lemonsqueezy. Mêmes fonctionnalités, autre runtime.

## Installation

```bash
cd mcp-servers/lemonsqueezy-ts
npm install
npm run build
```

## Configuration côté Claude Code

`.claude/settings.local.json` :

```json
{
  "mcpServers": {
    "lemonsqueezy": {
      "command": "node",
      "args": ["/chemin/absolu/vers/mcp-servers/lemonsqueezy-ts/dist/server.js"],
      "env": {
        "LEMONSQUEEZY_API_KEY": "ls_REPLACE_ME"
      }
    }
  }
}
```

## Tools

Identiques à la version Python : `list_subscriptions`, `get_customer`, `monthly_revenue`.

## Test

```bash
node dist/server.js
# Avec inspector :
npx @modelcontextprotocol/inspector node dist/server.js
```
