import { Server } from '@modelcontextprotocol/sdk/server/index.js'
import { StdioServerTransport } from '@modelcontextprotocol/sdk/server/stdio.js'
import { z } from 'zod'

const API_KEY = process.env.LEMONSQUEEZY_API_KEY
const STORE_ID = process.env.LEMONSQUEEZY_STORE_ID

if (!API_KEY) {
  console.error('ERROR: LEMONSQUEEZY_API_KEY missing')
  process.exit(1)
}

const BASE = 'https://api.lemonsqueezy.com/v1'
const HEADERS = {
  'Authorization': `Bearer ${API_KEY}`,
  'Accept': 'application/vnd.api+json'
}

const ListSubsInput = z.object({
  status: z.enum(['active', 'cancelled', 'expired', 'all']).default('active'),
  limit: z.number().int().min(1).max(50).default(10)
})

const GetCustomerInput = z.object({
  customer_id: z.string().min(1).max(64)
})

const server = new Server(
  { name: 'lemonsqueezy', version: '1.0.0' },
  { capabilities: { tools: {} } }
)

server.setRequestHandler('tools/list', async () => ({
  tools: [
    {
      name: 'list_subscriptions',
      description: 'Liste les abonnements Lemonsqueezy filtrés par statut',
      inputSchema: {
        type: 'object',
        properties: {
          status: { type: 'string', enum: ['active', 'cancelled', 'expired', 'all'] },
          limit: { type: 'number', minimum: 1, maximum: 50 }
        }
      }
    },
    {
      name: 'get_customer',
      description: "Récupère les infos d'un client Lemonsqueezy par ID",
      inputSchema: {
        type: 'object',
        properties: { customer_id: { type: 'string' } },
        required: ['customer_id']
      }
    },
    {
      name: 'monthly_revenue',
      description: 'Calcule le MRR à partir des abonnements actifs',
      inputSchema: { type: 'object' }
    }
  ]
}))

async function listSubscriptions(args: unknown) {
  const parsed = ListSubsInput.parse(args)
  const url = new URL(`${BASE}/subscriptions`)
  url.searchParams.set('page[size]', String(parsed.limit))
  if (parsed.status !== 'all') url.searchParams.set('filter[status]', parsed.status)
  if (STORE_ID) url.searchParams.set('filter[store_id]', STORE_ID)

  const res = await fetch(url.toString(), { headers: HEADERS })
  if (!res.ok) throw new Error(`api_error: ${res.status}`)
  const json = (await res.json()) as { data: Array<{ id: string; attributes: Record<string, string> }> }
  return json.data.map((s) => ({
    id: s.id,
    email: s.attributes.user_email,
    status: s.attributes.status,
    product: s.attributes.product_name,
    renews_at: s.attributes.renews_at
  }))
}

async function getCustomer(args: unknown) {
  const parsed = GetCustomerInput.parse(args)
  const res = await fetch(`${BASE}/customers/${parsed.customer_id}`, { headers: HEADERS })
  if (!res.ok) throw new Error(`api_error: ${res.status}`)
  const json = (await res.json()) as { data: { attributes: Record<string, string | number> } }
  const c = json.data.attributes
  return {
    email: c.email,
    name: c.name,
    status: c.status,
    country: c.country,
    total_revenue_currency: c.total_revenue_currency,
    mrr: c.mrr
  }
}

async function monthlyRevenue() {
  const url = new URL(`${BASE}/subscriptions`)
  url.searchParams.set('filter[status]', 'active')
  url.searchParams.set('page[size]', '100')
  if (STORE_ID) url.searchParams.set('filter[store_id]', STORE_ID)
  const res = await fetch(url.toString(), { headers: HEADERS })
  if (!res.ok) throw new Error(`api_error: ${res.status}`)
  const json = (await res.json()) as { data: Array<{ attributes: { first_subscription_item?: { price?: number } } }> }
  const total = json.data.reduce((sum, s) => sum + (s.attributes.first_subscription_item?.price ?? 0), 0)
  return { mrr_cents: total, subscription_count: json.data.length }
}

server.setRequestHandler('tools/call', async (request) => {
  const { name, arguments: args } = request.params
  try {
    let result: unknown
    if (name === 'list_subscriptions') result = await listSubscriptions(args)
    else if (name === 'get_customer') result = await getCustomer(args)
    else if (name === 'monthly_revenue') result = await monthlyRevenue()
    else throw new Error(`Unknown tool: ${name}`)
    return { content: [{ type: 'text', text: JSON.stringify(result, null, 2) }] }
  } catch (err) {
    return {
      content: [{ type: 'text', text: JSON.stringify({ error: (err as Error).message }) }],
      isError: true
    }
  }
})

const transport = new StdioServerTransport()
await server.connect(transport)
