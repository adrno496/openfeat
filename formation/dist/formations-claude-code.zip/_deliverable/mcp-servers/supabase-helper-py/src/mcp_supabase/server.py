"""MCP server stdio Supabase (read-only)."""

import json
import os
import sys
from typing import Optional
from supabase import create_client, Client
from pydantic import BaseModel, Field, field_validator
from mcp.server.fastmcp import FastMCP

URL = os.environ.get("SUPABASE_URL")
KEY = os.environ.get("SUPABASE_SERVICE_KEY")

if not URL or not KEY:
    print("ERROR: SUPABASE_URL or SUPABASE_SERVICE_KEY missing", file=sys.stderr)
    sys.exit(1)

supabase: Client = create_client(URL, KEY)
mcp = FastMCP("supabase")


class QueryInput(BaseModel):
    table: str = Field(min_length=1, max_length=64)
    columns: str = Field(min_length=1, max_length=512)
    limit: int = Field(default=10, ge=1, le=100)

    @field_validator("columns")
    @classmethod
    def no_wildcard(cls, v: str) -> str:
        if "*" in v:
            raise ValueError("wildcards not allowed, specify columns explicitly")
        return v


@mcp.tool()
def list_tables() -> str:
    """Liste les tables publiques du projet Supabase."""
    try:
        # Note: dépend d'une RPC get_tables exposée côté DB. Sinon utiliser pg_tables.
        result = supabase.rpc("get_public_tables").execute()
        return json.dumps(result.data)
    except Exception as e:
        return json.dumps({"error": str(e), "hint": "Need RPC `get_public_tables` or use SQL fallback."})


@mcp.tool()
def count_rows(table: str) -> str:
    """Compte les lignes d'une table publique."""
    try:
        result = supabase.table(table).select("id", count="exact").limit(1).execute()
        return json.dumps({"table": table, "count": result.count})
    except Exception as e:
        return json.dumps({"error": str(e)})


@mcp.tool()
def query_table(table: str, columns: str, limit: int = 10) -> str:
    """Lit des lignes d'une table avec colonnes EXPLICITES (refuse '*')."""
    try:
        params = QueryInput(table=table, columns=columns, limit=limit)
    except Exception as e:
        return json.dumps({"error": "invalid_input", "details": str(e)})
    try:
        result = supabase.table(params.table).select(params.columns).limit(params.limit).execute()
        return json.dumps(result.data, default=str)
    except Exception as e:
        return json.dumps({"error": str(e)})


@mcp.tool()
def audit_rls() -> str:
    """Liste les tables sans RLS et les policies trop permissives."""
    try:
        result = supabase.rpc("audit_rls_policies").execute()
        return json.dumps(result.data)
    except Exception as e:
        return json.dumps({
            "error": str(e),
            "hint": "Crée une RPC SQL `audit_rls_policies` qui retourne tables sans RLS et policies USING(true)."
        })


def main():
    mcp.run(transport="stdio")


if __name__ == "__main__":
    main()
