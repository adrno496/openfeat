# MCP Server — Supabase Helper (Python)

MCP stdio pour interagir avec une instance Supabase depuis Claude Code (lectures sécurisées + helpers RLS).

## Installation

```bash
cd mcp-servers/supabase-helper-py
uv venv && source .venv/bin/activate
uv pip install -e .
```

## Configuration

`.claude/settings.local.json` :
```json
{
  "mcpServers": {
    "supabase": {
      "command": "uvx",
      "args": ["--from", "/chemin/vers/supabase-helper-py", "mcp-supabase"],
      "env": {
        "SUPABASE_URL": "https://xxx.supabase.co",
        "SUPABASE_SERVICE_KEY": "eyJ..."
      }
    }
  }
}
```

⚠️ **service_key** : ce MCP a tous les droits. Ne l'expose JAMAIS via HTTP sans auth forte.

## Tools

- `list_tables()` — liste les tables publiques
- `count_rows(table)` — compte les lignes (avec safety check)
- `query_table(table, columns, limit)` — query avec colonnes explicites obligatoires (refuse `*`)
- `audit_rls()` — liste les tables sans RLS et les policies trop permissives

## Sécurité critique

- Refuse tout `select('*')` (force colonnes explicites)
- Limit max 100 sur `query_table`
- Aucun tool de mutation exposé (read-only)
- Pour les mutations : à faire manuellement via dashboard Supabase ou via une RPC dédiée
