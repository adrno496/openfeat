import { supabase } from '../src/services/supabase.js'
import { setState } from '../src/store.js'
import '../src/routes/index.js'

async function bootstrap() {
  const { data: { session } } = await supabase.auth.getSession()
  setState({ session })

  supabase.auth.onAuthStateChange((_event, newSession) => {
    setState({ session: newSession })
  })
}

bootstrap()
