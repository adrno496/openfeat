-- Migration initiale : profiles + subscriptions + RLS + RPC sécurisée
-- Adaptée du template Solo Founder Stack

create extension if not exists "uuid-ossp";

-- ===== profiles =====

create table public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  email text not null unique,
  display_name text,
  avatar_url text,
  is_premium boolean not null default false,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

alter table public.profiles enable row level security;

create policy "users_can_read_own_profile" on public.profiles
  for select using (auth.uid() = id);

create policy "users_can_update_own_profile_safe_fields" on public.profiles
  for update using (auth.uid() = id)
  with check (
    auth.uid() = id
    and is_premium = (select is_premium from public.profiles where id = auth.uid())
  );

-- Trigger : création auto profile à signup
create or replace function public.handle_new_user()
returns trigger
language plpgsql
security definer
as $$
begin
  insert into public.profiles (id, email)
  values (new.id, new.email);
  return new;
end;
$$;

create trigger on_auth_user_created
  after insert on auth.users
  for each row execute function public.handle_new_user();

-- ===== subscriptions =====

create table public.subscriptions (
  id uuid primary key default uuid_generate_v4(),
  user_id uuid not null references public.profiles(id) on delete cascade,
  provider text not null check (provider in ('lemonsqueezy', 'revenuecat')),
  external_id text not null,
  status text not null check (status in ('active', 'cancelled', 'expired', 'past_due')),
  product_name text,
  current_period_end timestamptz,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  unique (provider, external_id)
);

alter table public.subscriptions enable row level security;

create policy "users_can_read_own_subscriptions" on public.subscriptions
  for select using (auth.uid() = user_id);

-- Pas de policy INSERT/UPDATE/DELETE côté user.
-- Mutations via Edge Functions avec service_role.

-- ===== RPC : set_premium_status =====

create or replace function public.set_premium_status(
  target_user_id uuid,
  new_status boolean
)
returns void
language plpgsql
security definer
as $$
begin
  if current_setting('request.jwt.claims', true)::json->>'role' != 'service_role' then
    raise exception 'unauthorized: only service_role can call set_premium_status';
  end if;

  update public.profiles
  set is_premium = new_status, updated_at = now()
  where id = target_user_id;
end;
$$;

revoke all on function public.set_premium_status from public;
grant execute on function public.set_premium_status to service_role;
