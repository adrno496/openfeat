# Starter — Solo Founder Vanilla

Squelette de projet **immédiatement utilisable** pour démarrer un SaaS Vanilla JS + Capacitor + Supabase + Vercel + Lemonsqueezy + RevenueCat.

## Quick start

```bash
# Cloner / copier ce dossier vers ton emplacement
cp -r starters/solo-founder-vanilla ~/projects/mon-saas
cd ~/projects/mon-saas

# Installer les deps Capacitor (si tu vises mobile)
npm install

# Lancer en local
npx serve public/

# Ouvrir Claude Code
claude
```

## Ce qui est inclus

```
solo-founder-vanilla/
├── public/
│   ├── index.html              # Page racine avec CSP meta + script type module
│   ├── styles.css              # Reset + base classes
│   └── app.js                  # Entry point ES Module
├── src/
│   ├── routes/
│   │   ├── router.js           # SPA router custom
│   │   └── index.js            # Routes registration
│   ├── services/
│   │   ├── supabase.js         # Client Supabase
│   │   └── auth.js             # signup, login, logout, getProfile
│   ├── store.js                # State minimal partagé
│   └── utils/
│       ├── escape.js           # escapeHtml pour XSS prevention
│       └── fetch.js            # apiFetch avec gestion d'erreur
├── supabase/
│   └── migrations/
│       └── 20260101_initial.sql  # profiles + subscriptions + RLS + RPC
├── .claude/
│   ├── settings.json           # standards équipe avec deny + hooks audit
│   └── skills/                 # skills pré-installés (csp, rls, commit, deploy)
├── CLAUDE.md                   # contrat avec ton IA
├── vercel.json                 # headers sécu + rewrites SPA
├── package.json                # deps Capacitor
├── .gitignore
└── .env.example
```

## Prochaines étapes

1. Suivre Solo Founder Stack (formation F2) module par module
2. Adapter `CLAUDE.md` à ton produit spécifique
3. Créer ton projet Supabase, copier URL + anon_key dans `.env` et `window.SUPABASE_URL/ANON_KEY`
4. Premier déploiement Vercel : connecte le repo, déploiement auto

## Sécurité — checklist intégrée

Le starter inclut déjà :
- CSP via meta tag (dev) et vercel.json (prod)
- `escapeHtml()` utility prête
- Migration RLS-safe (profiles + subscriptions)
- RPC `set_premium_status` server-side only
- `.claude/settings.json` avec `deny` sur destructeurs
- Hook audit log activé

À ajouter par toi :
- Variables d'env Vercel (anon key)
- Webhook Lemonsqueezy → Edge Function (cf. F2 module 06)
- Soumission Play Store (cf. F2 module 07)
