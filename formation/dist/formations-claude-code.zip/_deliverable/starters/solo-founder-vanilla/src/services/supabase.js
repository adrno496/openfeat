import { createClient } from 'https://esm.sh/@supabase/supabase-js@2'

const SUPABASE_URL = window.SUPABASE_URL
const SUPABASE_ANON_KEY = window.SUPABASE_ANON_KEY

if (!SUPABASE_URL || !SUPABASE_ANON_KEY) {
  console.error('Configure window.SUPABASE_URL et window.SUPABASE_ANON_KEY dans index.html')
}

export const supabase = createClient(SUPABASE_URL, SUPABASE_ANON_KEY)
