import { supabase } from './supabase.js'

export async function signUp(email, password) {
  const { data, error } = await supabase.auth.signUp({ email, password })
  if (error) return { error }
  return { user: data.user }
}

export async function signIn(email, password) {
  const { data, error } = await supabase.auth.signInWithPassword({ email, password })
  if (error) return { error }
  return { session: data.session }
}

export async function signOut() {
  const { error } = await supabase.auth.signOut()
  if (error) return { error }
  return { ok: true }
}

export async function getCurrentProfile() {
  const { data: { user } } = await supabase.auth.getUser()
  if (!user) return { profile: null }
  const { data, error } = await supabase
    .from('profiles')
    .select('id, email, display_name, avatar_url, is_premium')
    .eq('id', user.id)
    .single()
  if (error) return { error }
  return { profile: data }
}
