import { registerRoute } from './router.js'
import { getState, subscribe } from '../store.js'
import { signIn, signUp, signOut, getCurrentProfile } from '../services/auth.js'
import { escapeHtml } from '../utils/escape.js'

registerRoute('/', renderHome)
registerRoute('/login', renderLogin)
registerRoute('/signup', renderSignup)
registerRoute('/dashboard', renderDashboard)
registerRoute('*', (app) => {
  app.innerHTML = '<h1>404</h1><p><a href="/" data-link>Retour à l\'accueil</a></p>'
})

function renderHome(app) {
  const { session } = getState()
  app.innerHTML = `
    <h1>Mon SaaS</h1>
    <p>Bienvenue. Stack solo founder en cours de configuration.</p>
    ${session
      ? `<p><a href="/dashboard" data-link>Accéder au dashboard</a></p>`
      : `<p><a href="/login" data-link>Se connecter</a> ou <a href="/signup" data-link>créer un compte</a></p>`
    }
  `
}

function renderLogin(app) {
  app.innerHTML = `
    <h1>Connexion</h1>
    <form id="login-form">
      <p><input type="email" name="email" placeholder="Email" required></p>
      <p><input type="password" name="password" placeholder="Mot de passe" required></p>
      <p><button type="submit">Se connecter</button></p>
    </form>
    <p><a href="/signup" data-link>Pas encore de compte ?</a></p>
  `
  document.getElementById('login-form').addEventListener('submit', async (e) => {
    e.preventDefault()
    const fd = new FormData(e.target)
    const result = await signIn(fd.get('email'), fd.get('password'))
    if (result.error) {
      alert('Erreur : ' + result.error.message)
    } else {
      window.location.href = '/dashboard'
    }
  })
}

function renderSignup(app) {
  app.innerHTML = `
    <h1>Créer un compte</h1>
    <form id="signup-form">
      <p><input type="email" name="email" placeholder="Email" required></p>
      <p><input type="password" name="password" placeholder="Mot de passe (min 6 char)" minlength="6" required></p>
      <p><button type="submit">Créer mon compte</button></p>
    </form>
  `
  document.getElementById('signup-form').addEventListener('submit', async (e) => {
    e.preventDefault()
    const fd = new FormData(e.target)
    const result = await signUp(fd.get('email'), fd.get('password'))
    if (result.error) {
      alert('Erreur : ' + result.error.message)
    } else {
      alert('Compte créé. Vérifie tes emails (confirmation requise selon config Supabase).')
      window.location.href = '/login'
    }
  })
}

async function renderDashboard(app) {
  const { profile } = await getCurrentProfile()
  if (!profile) {
    window.location.href = '/login'
    return
  }
  app.innerHTML = `
    <h1>Dashboard</h1>
    <div class="card">
      <p><strong>Email</strong> : ${escapeHtml(profile.email)}</p>
      <p><strong>Display name</strong> : ${escapeHtml(profile.display_name ?? '(non défini)')}</p>
      <p><strong>Premium</strong> : ${profile.is_premium ? 'Oui' : 'Non'}</p>
    </div>
    <p><button id="logout">Se déconnecter</button></p>
  `
  document.getElementById('logout').addEventListener('click', async () => {
    await signOut()
    window.location.href = '/'
  })
}

subscribe(() => {
  // Re-render quand la session change
  const route = location.pathname
  const handler = {
    '/': renderHome,
    '/login': renderLogin,
    '/signup': renderSignup,
    '/dashboard': renderDashboard
  }[route]
  if (handler) handler(document.getElementById('app'))
})
