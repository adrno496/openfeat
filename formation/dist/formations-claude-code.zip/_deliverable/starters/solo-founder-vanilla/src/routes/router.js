const routes = new Map()

export function registerRoute(path, handler) {
  routes.set(path, handler)
}

export function navigate(path) {
  history.pushState({}, '', path)
  render()
}

function render() {
  const path = location.pathname
  const handler = routes.get(path) ?? routes.get('*')
  const app = document.getElementById('app')
  if (!app) return
  app.innerHTML = ''
  if (handler) handler(app)
}

window.addEventListener('popstate', render)
window.addEventListener('DOMContentLoaded', render)

document.addEventListener('click', (e) => {
  const link = e.target.closest('a[data-link]')
  if (!link) return
  e.preventDefault()
  navigate(link.getAttribute('href'))
})
