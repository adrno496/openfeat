# LEGAL-NOTES.md

Points d'attention légaux pour vendre des formations en ligne en France. **Ce document n'est pas un avis juridique** — fais valider tes textes par un avocat avant de lancer.

---

## Statut Qualiopi

Qualiopi n'est **pas requis** si tes formations ne sont **pas finançables** par CPF, OPCO, France Travail, etc. Si tu vends en B2C direct sans financement public, tu n'as aucune obligation Qualiopi.

À éviter dans ta com si tu n'es pas Qualiopi :
- Mentionner "finançable CPF"
- Utiliser le terme "action de formation" au sens du Code du travail
- Promettre une attestation officielle de formation continue

Tu peux délivrer un certificat de complétion **interne** (non reconnu par l'État) sans souci.

---

## CGV — points obligatoires

Tes Conditions Générales de Vente doivent contenir au minimum :
- Identité du vendeur (raison sociale, SIRET, adresse, contact)
- Description du produit (formation en ligne, accès digital)
- Prix TTC + mention TVA (ou franchise en base si applicable)
- Modalités de paiement (Lemonsqueezy, Stripe, etc.)
- Modalités d'accès au contenu (lien, durée d'accès, support)
- Droit de rétractation (cf. section dédiée)
- Garanties (légale de conformité, vices cachés)
- Réclamations et médiation de la consommation (médiateur obligatoire en B2C)
- Droit applicable et juridiction compétente

---

## Droit de rétractation 14 jours

En B2C, l'acheteur a **14 jours pour se rétracter sans motif** sur tout achat à distance.

Exception applicable aux formations en ligne : si l'apprenant **commence à consommer le contenu** avant la fin des 14 jours, il peut perdre son droit de rétractation **à condition** d'avoir explicitement renoncé à ce droit au moment de l'achat (case à cocher non pré-cochée + texte clair).

Implémentation pratique :
- Soit tu offres rétractation pleine 14 jours (impose un délai avant accès, ou tu rembourses si demande dans les 14j même après accès — choix commercial)
- Soit tu mets en place le mécanisme de renonciation explicite (recommandé pour formations à accès immédiat)

Texte type au checkout (à faire valider par avocat) :
> "Je souhaite accéder immédiatement au contenu de la formation. Je reconnais que cet accès immédiat entraîne la perte de mon droit de rétractation de 14 jours, conformément à l'article L221-28 du Code de la consommation."

---

## TVA et facturation

### Si auto-entrepreneur (régime de la franchise en base)
- Pas de TVA à collecter tant que tu es sous le seuil (37 500 € CA HT pour prestations de services en 2026, à vérifier annuellement)
- Mention obligatoire sur facture : "TVA non applicable, art. 293 B du CGI"

### Si société (SAS, SARL, EURL, etc.)
- TVA à collecter à 20 % en France
- Pour clients UE (B2C) : guichet OSS (One Stop Shop) — TVA du pays de l'acheteur
- Pour clients UE (B2B avec n° TVA valide) : autoliquidation (mention "Reverse charge")
- Pour clients hors UE : pas de TVA

**Lemonsqueezy gère le guichet OSS pour toi** — c'est l'argument #1 de cette plateforme pour les créateurs FR.

### Mentions obligatoires sur facture
- Numéro de facture séquentiel sans rupture
- Date d'émission
- Identité émetteur (raison sociale, SIRET, adresse, n° TVA si applicable)
- Identité acheteur
- Désignation précise du produit
- Prix unitaire HT, taux TVA, montant TVA, total TTC
- Conditions de paiement et taux de pénalité de retard

---

## RGPD

Données personnelles collectées (email, nom, données paiement) → tu es **responsable de traitement**.

Obligations principales :
- Politique de confidentialité claire et accessible
- Base légale identifiée pour chaque traitement (exécution du contrat pour la formation, consentement pour la newsletter, intérêt légitime pour les emails post-achat)
- Droit d'accès, rectification, effacement, portabilité — process clair pour répondre sous 1 mois max
- Sous-traitants déclarés (Stripe/Lemonsqueezy, hébergeur vidéo, email marketing)
- Cookies : bannière conforme (pas de pré-cochage, refus aussi facile que l'acceptation)
- Notification CNIL en cas de violation de données dans les 72h

---

## Consommateur vs professionnel

Tes CGV doivent **distinguer** clauses B2C et B2B :
- B2C : droit de rétractation, médiation, garantie légale, etc.
- B2B : ces protections ne s'appliquent pas (ou différemment), tu peux exclure certaines responsabilités

Si tu vends aux deux publics, **deux versions de CGV** ou une CGV avec sections clairement séparées.

---

## Démarchage et e-commerce

- Pas de démarchage téléphonique sans consentement préalable (loi Châtel)
- Email marketing : opt-in obligatoire pour B2C, opt-in soft accepté pour B2B (avec opt-out facile)
- Mention "Médiateur de la consommation" obligatoire sur le site (CMAP, MEDICYS, etc.)

---

## Avertissement final

Ce document est un **guide d'orientation**, pas un avis juridique. Avant lancement :
1. Fais valider tes CGV par un avocat (compter 500–2000 € selon complexité)
2. Adhère à un médiateur de la consommation (gratuit ou faible coût)
3. Configure correctement ton compte Lemonsqueezy/Stripe pour gérer la TVA
4. Documente ta conformité RGPD (registre des traitements même simplifié)

L'erreur la plus coûteuse : ne pas avoir de droit de rétractation correctement géré → contestation paiement → litigation → mauvaise image.
