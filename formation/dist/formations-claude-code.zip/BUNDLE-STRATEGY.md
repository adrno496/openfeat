# BUNDLE-STRATEGY.md

Comment combiner les 6 formations en bundles cohérents, sans prix.

---

## Philosophie

Un bundle ne doit jamais être un "pack discount" mais un **parcours qui résout un problème concret**. La cible doit pouvoir nommer la transformation en une phrase.

---

## Bundle "Starter Dev" — F6 + F1
**Pour qui** : dev qui découvre Claude Code et veut une base solide.
**Transformation** : passer de "j'ai installé Claude Code la semaine dernière" à "Claude Code est dans mon flow quotidien et je sais configurer un sub-agent custom".
**Logique** : F6 installe les habitudes (workflow), F1 donne la maîtrise complète des features.

---

## Bundle "Solo Founder" — F6 + F1 + F2
**Pour qui** : indie hacker qui veut shipper un SaaS rentable.
**Transformation** : passer d'une idée de SaaS à un produit en production avec premiers users payants.
**Logique** : F6 (vitesse) → F1 (maîtrise outil) → F2 (process de ship complet avec exemples Vanilla JS + Capacitor + Supabase).

---

## Bundle "Agence IA" — F1 + F3 + F5
**Pour qui** : freelance ou petite agence qui veut industrialiser ses livrables.
**Transformation** : passer d'un freelance qui code à la main à une agence outillée capable de livrer en 1/3 du temps.
**Logique** : F1 (fond) → F3 (skills + MCP réutilisables = leviers techniques) → F5 (workflow client + scaling sans hiring).

---

## Bundle "Quant Lab" — F1 + F3 + F4
**Pour qui** : quant junior, trader indépendant, fonds boutique.
**Transformation** : passer de "je fais ma macro à la main" à "j'ai un lab automatisé qui produit des rapports institutionnels".
**Logique** : F1 (base) → F3 (MCP custom pour TradingView/Glassnode/Dune) → F4 (application macro/quant complète).

---

## Bundle "Mastery Complète" — F1 + F2 + F3 + F5
**Pour qui** : tech lead ou founder technique qui veut couvrir tout le spectre Claude Code (sauf niche finance).
**Transformation** : devenir le référent Claude Code de son équipe ou de sa boîte.
**Logique** : la totale hors finance — fond, ship produit, outillage avancé, workflow agence.

---

## Bundle "Tout-en-un" — F1 + F2 + F3 + F4 + F5 + F6
**Pour qui** : équipe tech qui veut équiper l'ensemble de son staff.
**Transformation** : un onboarding complet "Claude Code dans la boîte".
**Logique** : licence multi-utilisateurs, déploiement transverse.

---

## Recommandations de cross-sell (sans agressivité)

- À la fin de F6 → proposer F1 (suite logique).
- À la fin de F1 → proposer F2 (si profil founder) ou F3 (si profil dev avancé) ou F5 (si profil freelance).
- À la fin de F2 → proposer F5 (pour ceux qui veulent monter en agence) ou F3 (pour customiser l'outillage).
- À la fin de F3 → proposer F4 (pour appliquer les skills custom à un domaine niche) ou F5 (pour appliquer en agence).
- F4 est volontairement isolé : sa cible (finance) est suffisamment niche pour ne pas être proposée à tout le monde.

Les CTA de cross-sell sont toujours "Voir aussi…" jamais "Tu DOIS prendre…". L'apprenant est adulte.
