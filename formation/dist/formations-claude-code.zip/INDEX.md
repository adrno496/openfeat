# 🎓 Formations Claude Code — Index

Six formations distinctes en français, conçues pour devs francophones, freelances, solo founders et équipes tech qui veulent passer de "j'utilise Claude Code de temps en temps" à "Claude Code est la pièce centrale de mon stack".

Toutes les formations partagent les mêmes conventions (voir [`MASTER-CLAUDE.md`](./MASTER-CLAUDE.md)) mais chacune a sa cible, son angle, sa voix.

---

## F6 — `vibe-coding-workflow/` 🟢
Produit d'entrée. Format court. Doubler ta productivité dev en une semaine.
Cible : devs débutants/intermédiaires curieux d'IA.
Niveau : débutant à intermédiaire.

## F1 — `claude-code-mastery-fr/` 🟡
La référence francophone complète sur Claude Code. Du `claude` install au sub-agent custom.
Cible : devs FR junior à senior, freelances, équipes tech.
Niveau : intermédiaire à avancé.

## F2 — `solo-founder-stack/` 🟡
Ship un SaaS production-ready en 30 jours. Stack léger, coût d'infra dérisoire.
Cible : indie hackers, devs solo, créateurs de SaaS.
Niveau : intermédiaire.

## F3 — `skills-mcp-builder-pro/` 🔴
Couche avancée. Skills réutilisables et MCP servers custom. Distribuer des outils qui démultiplient une équipe.
Cible : devs avancés, agences IA, équipes tech ambitieuses.
Niveau : avancé.

## F5 — `ai-agency-toolkit/` 🟡
Délivrer plus, mieux, plus vite — sans embaucher. Workflow client, refactor à grande échelle, audit code.
Cible : freelances dev/marketing, petites agences.
Niveau : intermédiaire.

## F4 — `claude-code-quant-macro/` 🔴
Niche finance. Automatiser ta recherche macro et tes backtests avec Claude Code.
Cible : traders indépendants, quants juniors, analystes macro, fonds boutique.
Niveau : avancé.

---

## Comment naviguer

- Démarre par `MASTER-CLAUDE.md` pour comprendre les conventions communes.
- Consulte `BUNDLE-STRATEGY.md` pour les regroupements logiques entre formations.
- Lis `FUNNEL-MAP.md` pour comprendre le parcours apprenant idéal (F6 → F1 → F2 → F4 → F3/F5).
- Avant de lancer, passe par `LAUNCH-CHECKLIST.md` et `LEGAL-NOTES.md`.

Chaque dossier formation contient son propre `README.md` avec instructions d'utilisation.
