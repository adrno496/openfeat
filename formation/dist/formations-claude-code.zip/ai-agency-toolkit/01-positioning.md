# Positioning — AI Agency Toolkit

## USP

La seule formation FR qui te montre comment **multiplier ta capacité de delivery** sans embaucher, en utilisant Claude Code comme infrastructure d'agence.

## Cible

- Freelance dev/marketing avec déjà des clients
- Petite agence (1-5 personnes) qui veut scaler la qualité
- Consultant indépendant qui veut systématiser

## Pas la cible

- Indie hackers qui construisent leur produit (vise F2)
- Devs qui n'ont jamais eu de client (apprends d'abord ce métier)
- Agences de 20+ personnes (problèmes différents : management, ops)

## Promesse

À la fin :
- Tu fais 3x plus de propositions par semaine
- Tu débloques 30 % de ton temps sur l'admin
- Tu livres des audits clients packagés en quelques heures
- Tu factures à la valeur, pas au temps
- Tu as un process documenté qui peut être suivi par un futur contractor

## Anti-promesse

- On ne te trouve pas tes clients
- On ne te promet pas de revenu mensuel précis
- On ne couvre pas le sales/marketing en profondeur
- Tu dois déjà connaître ton métier (dev, marketing, etc.)

## Format

Très opérationnel. Templates immédiatement utilisables. Workflows MCP fonctionnels.
