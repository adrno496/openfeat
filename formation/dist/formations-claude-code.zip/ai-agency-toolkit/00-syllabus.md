# Syllabus — AI Agency Toolkit

8 modules. ~8h.

## M00 — Introduction
🟢 — 15 min — Pour qui, philosophie "scale qualité pas headcount".

## M01 — Pricing et propositions IA-augmentées
🟡 — 50 min — Templates de proposition, scoping de mission, pricing à la valeur.

## M02 — Onboarding client systématisé
🟡 — 45 min — Process kickoff, accès, brief structuré, attente managée.

## M03 — Workflow client : Slack + Notion via MCP
🟡 — 60 min — MCP Notion, MCP Slack, async-first, statuts visibles.

## M04 — Refactor à grande échelle avec sub-agents
🔴 — 75 min — Refactor de codebases legacy, sub-agents parallélisés, sécurité.

## M05 — Audit code automatisé pour clients
🔴 — 60 min — Sub-agent code-reviewer + security-auditor, livrable PDF/HTML.

## M06 — Facturation, admin, KPI agence
🟡 — 45 min — Lemonsqueezy invoice + Notion, MCP Notion pour KPI, automation.

## M07 — Scaling sans hiring : multiplicateurs
🟡 — 60 min — Templates, skills réutilisables, process documenté, premier contractor justifié.

## M08 — Pricing avancé + recurring revenue
🟡 — 45 min — Forfait audit récurrent, retainer mensuel, upsell.

## M09 — Conclusion + plan croissance
🟢 — 15 min — Récap, plan 90 jours, vers F2/F3/F4 selon profil.

## Total

~8h structuré + 6-10h pratique sur tes propres clients réels.
