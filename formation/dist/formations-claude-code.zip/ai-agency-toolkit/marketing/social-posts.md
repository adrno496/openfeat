# Social Posts — AI Agency Toolkit

10 posts. Ton: opérationnel, business-first.

## 1 — X
```
Si tu factures au TJM, tu deviens commodity.

3 questions à poser AVANT de citer un prix :
1. Quel résultat business attends-tu ?
2. Valeur sur 12 mois ?
3. Combien tu serais prêt à investir si tu étais sûr ?

Tu pricez à 10-30% de la valeur perçue.
```

## 2 — LinkedIn
```
La majorité des freelances/agences plafonnent.

Pas par manque de demande. Par manque de système.

Hire = +1 personne, +complexité, +sales pour la nourrir, +risque.
Multiplier = templates, skills, MCP, automation.

L'un coûte 50 k€/an minimum. L'autre, ton temps de setup.

AI Agency Toolkit montre quoi multiplier en premier.
[LIEN]
```

## 3 — X
```
Modèle business à marge 80%+ :

Audit code packagé.
Forfait 1500-3500 € selon taille codebase.
Délai 3-5 jours ouvrés.
Livrable : PDF 10-15 pages + présentation 30 min.

Toi : 2-4h grâce aux sub-agents.
```

## 4 — LinkedIn
```
Ton onboarding client est-il systématisé ?

Bon onboarding = 3 étapes :
1. Pré-kickoff : brief structuré envoyé 24h avant
2. Kickoff call : 45 min max, valider le brief
3. Post-kickoff : récap écrit, accès, calendrier validé

Mauvais onboarding = client perdu dans le flou pendant 2 semaines.

Module 02 de Agency Toolkit. [LIEN]
```

## 5 — X
```
MCPs essentiels pour une activité freelance/agence :

- Notion (PM client + KPI internes)
- Slack (com client async)
- GitHub (issues/PRs)
- Lemonsqueezy (factures)

Setup en 30 min. Gain : 1h/jour à vie.
```

## 6 — LinkedIn
```
Avant de hire ton premier dev :

CHECK :
[ ] Tu refuses des missions par manque de temps (pas par choix)
[ ] +1 personne = +30% CA minimum (mesuré)
[ ] Process documenté qu'un nouveau peut suivre seul
[ ] 6 mois de runway pour absorber une mauvaise embauche

Si 4/4 : hire. Sinon : multiplier d'abord.

Module 07 d'Agency Toolkit. [LIEN]
```

## 7 — X
```
Recurring revenue pour freelance/agence :

- Audit trimestriel : $1500/trim
- Retainer mensuel 30h : $3000-5000/mois
- Maintenance contractuelle : $500-2000/mois

Le pitch le plus simple : à la fin d'une mission réussie. Conversion 30-50%.
```

## 8 — LinkedIn
```
Refactor de codebase legacy client : 3 erreurs courantes.

❌ "Je refactore tout d'un coup" → catastrophe
❌ "Je facture au TJM" → tu sous-évalues
❌ "Pas de snapshot Git" → pas de rollback possible

Bonne approche :
✓ Sub-agents parallélisés (explorer, planner, implementer)
✓ N PRs < 200 lignes chacun
✓ Forfait à la valeur business
✓ Snapshot avant chaque batch

Module 04 d'Agency Toolkit. [LIEN]
```

## 9 — X
```
KPI mensuels d'une activité freelance/agence saine :

- CA HT du mois
- Taux conversion propositions
- TJM moyen (CA / jours travaillés)
- Heures admin / facturable (vise < 30%)
- NPS client

Sans KPI, tu pilotes à l'aveugle.
```

## 10 — LinkedIn (CTA)
```
Tu veux scaler ton activité freelance/agence sans embaucher.

AI Agency Toolkit : 8 modules, templates fork-able, workflows MCP, communauté agency owners.

[LIEN]
```
