# Testimonials — AI Agency Toolkit

## Email type J+60 post-complétion

**Sujet** : Tu as vu une différence ?

3 questions :
1. Avant : qu'est-ce qui te plombait le plus dans ta capacité de delivery ?
2. Maintenant : chiffre concret du changement (TJM moyen, marge, recurring revenue, missions/mois) ?
3. À qui tu recommanderais en une phrase ?

Confirme aussi si je peux utiliser publiquement avec ton nom + lien.

## Format type
```
"AI Agency Toolkit a structuré mon activité. Mon TJM moyen est passé de [X] à [Y]
en 3 mois, avec [Z] retainer mensuel signé sur un client existant.
Le module 'pricing à la valeur' a été le tipping point.
Je recommande à tout freelance avec déjà des clients."

— [PRENOM] [NOM], freelance [DOMAINE]
[LIEN_PROFIL]
```

## Critères
- Personne réelle
- Chiffres mesurables
- Consentement écrit
- Profil identifiable

## Si pas encore de témoignages
Placeholders sur landing.
