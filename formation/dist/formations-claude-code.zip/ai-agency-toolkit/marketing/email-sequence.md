# Email Sequence — AI Agency Toolkit

5 emails.

## E1 — J0 — Welcome
**Sujet** : Accès Agency Toolkit
Salut [PRENOM]. Accès : [LIEN]. Discord : [LIEN_DISCORD]. Démarre par module 01 (pricing) qui change le plus vite la donne.

## E2 — J+5 — Pricing à la valeur
**Sujet** : Le pricing au temps te plombe
Si tu factures au TJM, tu deviens commodity. Module 01 te donne 3 questions à poser AVANT de citer un prix, et le template proposition 1 page.
[CTA Module 01]

## E3 — J+12 — Workflow MCP client
**Sujet** : 1h de gain par jour
Tu touches Slack + Notion + GitHub plusieurs fois par jour. MCP : Claude Code lit/écrit tout depuis 1 session. Module 03.
[CTA Module 03]

## E4 — J+25 — Audit code packagé
**Sujet** : Marge à 80%+ sur audit code
Modèle business avec marge énorme : audit code packagé (forfait 1500-3500 €), 2-4h pour toi grâce à sub-agents parallélisés.
Module 05 + template livrable.
[CTA Module 05]

## E5 — J+45 — Recurring revenue
**Sujet** : Convert tes clients existants en recurring
À la fin d'une mission réussie, le taux de conversion sur upsell (audit trimestriel, retainer mensuel) est 30-50%. Module 08.
[CTA Module 08]
