# Landing — AI Agency Toolkit

Aucun prix.

## Hero
**Headline** : Multiplie ta capacité de delivery sans embaucher.
**Sous-headline** : 8 modules pour transformer ton activité freelance/agence en système. Pricing, workflow, audit packagé, recurring revenue.
**CTA** : `Accéder à la formation →`

## Problème
Tu plafonnes parce que ton temps est limité. Hire = +1 personne, +complexité, +sales pour la nourrir. Avant d'envisager : multiplie via templates, skills, automation, MCP.

## Promesse
8 modules concrets :
- Pricing à la valeur (proposition 1 page)
- Onboarding systématisé
- Workflow client MCP (Slack + Notion + GitHub)
- Refactor à grande échelle (sub-agents parallélisés)
- Audit code packagé (forfait premium)
- Facturation + KPI automatisés
- Multiplicateurs avant hire
- Recurring revenue (audit récurrent, retainer, upsell)

## Pour qui
- Freelance dev/marketing avec déjà des clients
- Petite agence (1-5 personnes)
- Consultant indépendant qui veut systématiser

## Programme
01 Pricing IA-augmenté
02 Onboarding client systématisé
03 Workflow Slack + Notion + GitHub via MCP
04 Refactor à grande échelle
05 Audit code automatisé
06 Facturation + KPI agence
07 Multiplicateurs sans hire
08 Recurring revenue + upsell
09 Conclusion + plan 90 jours

## Ce que tu obtiens
- 8 modules (~8h)
- 5 exercices pratiques + solutions
- Templates : proposition 1 page, brief client, audit report PDF, slash commands `/proposal` `/invoice` `/audit-report`
- Configurations MCP : Notion, Slack, GitHub
- Cheatsheet pricing + KPI
- Communauté Discord agency owners
- Mises à jour à vie

## Preuve sociale
[TÉMOIGNAGE 1 — freelance qui a 2x sa marge sans hire]
[TÉMOIGNAGE 2 — agence qui a packagé son offre audit]
[TÉMOIGNAGE 3 — focus recurring revenue acquis]

## FAQ
(Cf. resources/faq.md)

## CTA final
**Titre** : Scale qualité, pas headcount.
**CTA** : `Accéder à la formation →`
