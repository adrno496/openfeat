# Script vidéo — Intro hook (≤ 90 sec)

### 0:00 — 0:20 — Hook
"Tu es freelance ou en agence. Tu plafonnes parce que ton temps est limité. Tu refuses des missions, tu sacrifies du sommeil, ou tu pensses au hire."

### 0:20 — 0:50 — Solution
"AI Agency Toolkit te montre comment multiplier ta capacité de delivery sans embaucher. 8 modules : pricing à la valeur, onboarding systématisé, workflow client async via MCP, refactor à grande échelle, audit packagé, admin automatisée, recurring revenue."

### 0:50 — 1:10 — Différenciation
"Templates immédiatement utilisables. Workflows MCP fonctionnels. Communauté d'agency owners qui partagent leurs KPI réels."

### 1:10 — 1:25 — Cible
"Pour freelances/agences avec déjà des clients. Si tu débutes : apprends d'abord à vendre + livrer."

### 1:25 — 1:30 — CTA
"[LIEN]"

## Notes
- Plan poitrine
- B-roll : capture Notion KPI agence, dashboard Lemonsqueezy invoices
- Pas de musique
