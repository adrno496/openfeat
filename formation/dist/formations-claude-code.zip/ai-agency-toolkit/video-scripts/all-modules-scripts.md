# Scripts vidéo — AI Agency Toolkit (consolidé)

## 00 — Intro hook (≤ 90 sec)
- "Tu es freelance ou en agence. Tu plafonnes en capacité parce que ton temps est limité."
- "AI Agency Toolkit te montre comment scaler la qualité — pas le headcount — avec Claude Code."
- "8 modules : pricing, onboarding, workflow client MCP, refactor à grande échelle, audit packagé, admin auto, multiplicateurs, recurring revenue."
- "Pour freelances/agences avec déjà des clients."
- CTA.

## 01 — Pricing à la valeur (8-10 min)
- 3 questions avant de citer un prix
- Template proposition 1 page
- Slash command `/proposal`
- Anti-patterns

## 02 — Onboarding systématisé (6-8 min)
- 3 étapes (pré-kickoff, call, post)
- Template brief client
- Attentes managées dès J0

## 03 — Workflow MCP client (8-10 min)
- Setup Notion + Slack + GitHub MCPs
- Workflow type matinée
- Async-first + status visible

## 04 — Refactor grande échelle (10-12 min)
- Sub-agents parallélisés
- Stratégie N PRs < 200 lignes
- Sécurité critique sur code client

## 05 — Audit code packagé (8-10 min)
- Modèle business (forfait 1500-3500 €)
- Process automatisé
- Template livrable PDF
- Présentation 30 min

## 06 — Facturation + KPI (6-8 min)
- Lemonsqueezy + Notion
- Slash command `/invoice`
- KPI mensuels à mesurer

## 07 — Multiplicateurs (8-10 min)
- Avant de hire, multiplier (templates, skills, process, slash commands)
- Quand hire devient légitime
- Premier contractor à temps partiel

## 08 — Recurring revenue (6-8 min)
- Audit récurrent
- Retainer mensuel
- Upsell systématique

## 09 — Conclusion (3-4 min)
- Récap, plan 90 jours, vers F2/F3/F4

## Notes
- Démos terminal + Notion side-by-side
- Captures de vraies pages Notion d'agence (anonymisées)
- Pas de musique pendant démos
