# 🛠 AI Agency Toolkit

**Délivrer plus, mieux, plus vite — sans embaucher.**

Pour freelances dev/marketing et petites agences qui veulent industrialiser leurs livrables grâce à Claude Code.

## Pour qui

- Freelance dev qui veut multiplier ses livrables sans hire
- Petite agence (1-5 personnes) qui veut scaler la qualité, pas le headcount
- Consultant qui veut transformer ses connaissances en système

## Ce que tu obtiens

- 8 modules pratiques (~8h)
- Templates de propositions client, contrats légers, scoping IA-augmenté
- Workflow client (Slack/Notion via MCP)
- Process de refactor à grande échelle
- Audit code automatisé
- Templates factu / admin automatisée
- Communauté Discord agency owners

## Structure

Voir `00-syllabus.md` et arborescence standard.

## Prérequis

- F6 + F1 ou maîtrise pratique de Claude Code
- Au moins 6 mois d'expérience freelance ou agence
- Connaissance minimale de la facturation / contrats client
