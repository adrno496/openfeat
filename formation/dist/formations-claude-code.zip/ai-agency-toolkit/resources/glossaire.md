# Glossaire — AI Agency Toolkit

**Acompte** — Paiement initial avant démarrage (typiquement 30-50 % du forfait).

**Brief client** — Document structuré qui définit contexte, objectifs, livrables, hors-scope. Rempli avant kickoff.

**Forfait** — Prix fixe pour un livrable défini, indépendant du temps passé. À préférer au TJM.

**Hors-scope** — Ce qui n'est PAS inclus dans la mission. À écrire explicitement dans la proposition.

**Kickoff** — Réunion de démarrage de mission (45 min max).

**KPI** — Key Performance Indicator. À suivre mensuellement (CA, missions, taux conversion, NPS, etc.).

**MCP (Model Context Protocol)** — Protocole pour brancher Claude Code à des outils externes (Notion, Slack, etc.).

**MoR (Merchant of Record)** — Service qui joue le rôle de vendeur officiel (ex: Lemonsqueezy). Gère TVA et conformité fiscale.

**Multiplicateur** — Mécanisme qui augmente ta capacité sans augmenter ton temps (template, skill, automation).

**NPS (Net Promoter Score)** — Indicateur de satisfaction client. "Sur 10, tu nous recommanderais ?".

**Onboarding (client)** — Process de démarrage de mission (kickoff + accès + setup).

**Process documenté** — Guide écrit qui permet à un futur contractor de suivre tes méthodes sans toi.

**Proposition** — Document commercial envoyé au client. Cible : 1 page max.

**Retainer** — Contrat mensuel récurrent pour disponibilité (30-50h/mois typiquement).

**Scaling sans hiring** — Augmenter capacité par templates/skills/automation plutôt que par recrutement.

**Slash command** — Commande personnalisée Claude Code invoquée par `/<nom>`.

**Sub-agent** — Sous-processus Claude Code à contexte isolé.

**TJM** — Taux Journalier Moyen. À éviter d'afficher en proposition (commoditisation).

**Upsell** — Vente additionnelle à un client existant (audit récurrent, retainer, etc.).
