# Ressources externes — AI Agency Toolkit

## Documentation

- Lemonsqueezy : `lemonsqueezy.com`
- Notion API : `developers.notion.com`
- Slack API : `api.slack.com`
- GitHub gh CLI : `cli.github.com`
- Pandoc (génération PDF) : `pandoc.org`

## Lectures

- "The Mom Test" (Rob Fitzpatrick) — interview clients sans biais
- "Pricing Creativity" (Blair Enns) — pricing à la valeur pour creative pros
- "Built to Sell" (John Warrillow) — process et systématisation
- "Company of One" (Paul Jarvis) — scaling sans hiring

## Outils

- Notion (PM + KPI) — gratuit pour solo
- Lemonsqueezy (factures + paiements MoR)
- Loom (démos client en visio courtes)
- Calendly (booking calls)
- gh CLI (GitHub depuis terminal)

## Communautés

- Indie Hackers (en anglais)
- French Tech Slack (FR)
- Discord agency owners (privé, formation)

## Pour aller plus loin

- F2 — ship ton propre SaaS en parallèle
- F3 — construire MCPs custom à monétiser
- F4 — niche finance (LTV élevée)
- F1 — référence Claude Code
