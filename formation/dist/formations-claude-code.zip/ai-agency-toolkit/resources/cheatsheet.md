# Cheatsheet — AI Agency Toolkit

## Pricing à la valeur

3 questions au client AVANT de citer un prix :
1. Quel résultat business attends-tu ?
2. Valeur sur 12 mois ?
3. Combien tu serais prêt à investir si tu étais sûr ?

Pricer à 10-30 % de la valeur perçue. Pas de TJM affiché.

## Template proposition (1 page)

```
# Proposition — [PROJET]
## Contexte
## Objectif business
## Approche
## Livrables
## Investment
## Calendrier
## Conditions
```

## Slash commands utiles

```
/proposal        Génère une proposition selon template
/scope           Décrit scope d'une tâche
/kickoff-recap   Récap post-call client
/invoice         Génère facture client
/audit-report    Génère le PDF audit code
```

## MCPs équipés

- Notion (PM, docs, KPI)
- Slack (com client async)
- GitHub (issues, PRs)
- Lemonsqueezy (factures)

## Sub-agents recommandés

- `explorer` (read-only recherche codebase)
- `code-reviewer` (review PR)
- `security-auditor` (OWASP top 10)

## Pricing audit code packagé

```
Petite codebase (< 10k lignes)    : 1500 €
Moyenne (10-50k)                   : 2500 €
Grande (50k+)                      : 3500-5000 €
Délai standard                     : 3-5 jours ouvrés
```

## KPI mensuels Notion

- CA HT du mois
- Nb missions livrées
- Taux conversion propositions
- TJM moyen (CA / jours)
- Heures admin / facturable (vise < 30 %)
- NPS client

## Anti-patterns

- TJM affiché → tu deviens commodity
- Propositions de 10 pages → personne ne lit
- Pas de hors-scope explicite → sur-engagement
- Pas d'upsell → CA sous-optimisé
- Hire trop tôt → marge dégradée
- Pas de KPI → pilotage à l'aveugle

## Multiplicateurs avant hire

1. Templates (50 % gain temps)
2. Skills réutilisables
3. Process documenté
4. Slash commands custom
5. MCPs custom pour stack récurrente

## Quand hire devient légitime

- Tu refuses des missions par manque de temps
- +1 personne = +30 % CA minimum
- Process documenté qu'un nouveau peut suivre seul
- 6 mois de runway

## Recurring revenue

- Audit trimestriel
- Audit mensuel
- Retainer mensuel (30-50h pour 3-8k €)
- Maintenance contractuelle
