# FAQ — AI Agency Toolkit

### J'ai 0 client, je peux suivre ?
Non. Cette formation suppose que tu sais déjà vendre et délivrer en freelance / agence. Pour démarrer freelance : ce n'est pas ici.

### Je dois maîtriser tout Claude Code avant ?
F6 minimum. F1 idéal. Tu peux faire en parallèle de F1 si tu es à l'aise.

### Combien de temps pour finir ?
~8h de contenu + 6-10h de pratique sur tes vrais clients = ~2-4 semaines.

### Le pricing à la valeur, ça marche vraiment ?
Sur des clients qui achètent un résultat (pas un dev) : oui, sans question. Sur des clients à très petit budget qui veulent juste "un site" : moins. Choisis tes clients.

### Lemonsqueezy ou Stripe pour facturer ?
Lemonsqueezy si tu veux la simplicité (MoR, gère TVA UE). Stripe si tu as déjà un comptable spécialisé. Pour démarrer en FR : Lemonsqueezy.

### Notion ou Airtable pour la PM client ?
Au choix. Notion mieux pour wiki + pages riches, Airtable mieux pour DB + automation. Les deux ont un MCP.

### Quand passer de freelance à agence ?
Quand tu refuses des missions par manque de temps, que +1 personne = +30 % CA, que ton process est documenté, que tu as 6 mois de runway.

### Audit code packagé : combien je facture ?
1500-3500 € selon taille codebase. Marge très élevée. Le client paie l'expertise, pas le temps.

### Recurring revenue : comment vendre un retainer mensuel ?
Le moment idéal : à la fin d'une mission réussie. Le client est convaincu. Tu proposes "audit trimestriel à X €" ou "retainer 30h/mois à Y €". Le client confiant accepte 30-50 % du temps.

### Garantie de remboursement ?
Cf. CGV.

### Communauté ?
Discord agency owners. Réservé apprenants. Show monthly de KPI réels.
