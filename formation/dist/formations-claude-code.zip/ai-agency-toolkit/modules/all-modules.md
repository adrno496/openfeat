# Modules — AI Agency Toolkit (consolidé)

Au déploiement final, splitter en 10 fichiers `00-introduction.md` à `09-conclusion.md`.

---

## Module 00 — Introduction (🟢, 15 min)

### Pourquoi cette formation
La majorité des freelances/agences plafonnent à 1 niveau de delivery dicté par leur temps. Hire = augmente capacité ET coûts ET complexité. Claude Code = augmente capacité **sans** augmenter linéairement les coûts.

### Ce qu'on construit
8 modules pour transformer ton activité en système : pricing, onboarding, workflow, refactor, audit, admin, scaling, recurring revenue.

### Engagement
Suivre avec **tes vrais clients**. Tester chaque module sur 1 client réel.

---

## Module 01 — Pricing et propositions IA-augmentées (🟡, 35 min lecture + 15 min pratique)

### Pricing à la valeur, pas au temps

3 questions à poser au client AVANT de citer un prix :
1. Quel résultat business attends-tu ? (en €, en temps, en risque évité)
2. Quelle est la valeur de ce résultat sur 12 mois ?
3. Combien tu serais prêt à investir si tu étais sûr du résultat ?

Tu pricez à 10-30% de la valeur perçue. Pas au TJM × jours.

### Template de proposition courte (1 page)

```
# Proposition — [PROJET CLIENT]

## Contexte
[2-3 phrases : ce que tu as compris de leur situation]

## Objectif business
[1 phrase mesurable]

## Approche
[3-5 puces]

## Livrables
[Liste concrète]

## Investment
[FORFAIT — pas TJM. Mention "tout compris" sauf si scope évolue]

## Calendrier
[Phases avec dates]

## Conditions
[3 puces : acompte, validation, hors scope]
```

À la place d'écrire ces propositions à la main, slash command `/proposal` qui te demande les inputs et génère le brouillon.

### Slash command `/proposal`

```markdown
---
name: proposal
description: Génère une proposition client courte (1 page) au format standard
---

Inputs nécessaires :
1. Nom du projet / client
2. Contexte en 1 phrase
3. Objectif business mesurable
4. Approche en 3-5 puces
5. Livrables concrets
6. Forfait + calendrier

Génère la proposition au format Markdown selon le template :
[copier le template ci-dessus]

Ton : direct, professionnel, sans superlatifs.
```

### Anti-patterns

- TJM affiché : tu devient une commodity
- Propositions à 10 pages : personne ne lit, on signe les courtes
- Sous-estimer le scope par "envie d'avoir le client" : tu paies plus tard
- Sur-promettre par "envie d'avoir le client" : tu perds le client à la première deadline manquée

---

## Module 02 — Onboarding client systématisé (🟡, 30 min lecture + 15 min pratique)

### Process kickoff en 3 étapes

1. **Pré-kickoff (24-48h avant call)** : email avec brief structuré à remplir
2. **Kickoff call (45 min max)** : valider le brief, lever ambiguïtés, fixer rythme
3. **Post-kickoff (J0)** : récap écrit, accès partagés, calendrier validé

### Template brief client

```
## Contexte
[2-3 phrases]

## Stakeholders
- Décideur final :
- Point de contact opérationnel :
- Tech lead côté client :

## Accès nécessaires
- [ ] Repo GitHub
- [ ] Slack workspace
- [ ] Notion / Linear / autre PM
- [ ] DB / staging / prod
- [ ] Comptes tiers (Vercel, Supabase, etc.)

## Définition de fini
[Critères mesurables de succès]

## Hors-scope explicite
[Ce qu'on ne fera PAS, validé par le client]

## Cadence de communication
- Sync : [hebdo / bihebdo / autre]
- Async : [Slack canal X / email]
- Status : [Notion page Y mise à jour à chaque livraison]
```

### Attentes managées dès le J0

3 promesses claires :
1. Réponse Slack sous X heures (X = 8 ou 24, à toi de décider)
2. Status async mis à jour quotidien (1 ligne dans Notion)
3. Sync hebdo de 30 min, agenda envoyé 24h avant

### Démo

Récupérer un kickoff fait à l'arrache → réécrire au format structuré → mesurer le gain en clarté la semaine suivante.

---

## Module 03 — Workflow client : Slack + Notion via MCP (🟡, 45 min lecture + 15 min pratique)

### Pourquoi MCP

Tu touches plusieurs outils par jour : Slack pour com, Notion pour docs, GitHub pour code, Linear pour tickets. Sans MCP : context-switching constant. Avec MCP : Claude Code lit et écrit directement.

### Setup minimal

`.claude/settings.local.json` :
```json
{
  "mcpServers": {
    "notion": {
      "command": "npx",
      "args": ["-y", "@notionhq/notion-mcp-server"],
      "env": { "NOTION_API_KEY": "secret_..." }
    },
    "slack": {
      "command": "npx",
      "args": ["-y", "@slack/mcp-server"],
      "env": { "SLACK_BOT_TOKEN": "xoxb-..." }
    },
    "github": {
      "command": "node",
      "args": ["/path/to/_deliverable/mcp-servers/github-issues-ts/dist/server.js"],
      "env": { "GITHUB_TOKEN": "ghp_...", "GITHUB_REPO": "client/repo" }
    }
  }
}
```

### Workflow type "matinée client"

```
9h00 - claude (cd ~/clients/client-X)
       "Lis les messages Slack non-lus du canal #project-X depuis hier 18h. Résume."
9h05 - 3 demandes utilisateur identifiées
9h10 - "Crée 3 issues GitHub correspondantes (avec labels)"
9h15 - "Update la page Notion 'Status hebdo' avec les actions du jour"
9h20 - Tu attaques le code
```

20 min vs 1h en mode manuel.

### Async-first : status visible en permanence

Page Notion partagée avec le client, mise à jour automatiquement par un cron (skill ou script) chaque soir à 18h :
- Ce qui a été fait aujourd'hui (depuis git log)
- Ce qui est prévu demain (depuis Notion to-do)
- Blockers le cas échéant

Le client n'a plus besoin de demander "où en est X". Il regarde.

### Anti-patterns

- Coller manuellement les status dans Slack (Claude Code peut le faire)
- Notion update tous les vendredis seulement (le client perd visibilité)
- Trop de tools branchés (5+ MCPs = pollution contexte)

---

## Module 04 — Refactor à grande échelle avec sub-agents (🔴, 50 min lecture + 25 min pratique)

### Le défi du refactor sur codebase legacy

Refactor de 50+ fichiers d'un coup = catastrophe garantie. Il faut :
- Décomposer
- Paralléliser sans casser la cohérence
- Tester à chaque étape
- Pouvoir rollback chaque sous-PR indépendamment

### Stratégie sub-agents parallélisés

```
1. Sub-agent "explorer" : cartographie le code à refactorer (read-only)
2. Sub-agent "planner" : propose un plan de refactor en N PRs indépendants
3. Tu valides le plan
4. Pour chaque PR planifié :
   - Sub-agent "implementer" : applique le refactor sur cette tranche
   - Sub-agent "tester" : génère les tests
   - Tu reviewes, tu commits
```

Chaque PR < 200 lignes, indépendant, testable.

### Sub-agents recommandés

- `explorer` (cf. `_deliverable/agents/explorer.md`)
- `code-reviewer` (cf. `_deliverable/agents/code-reviewer.md`)
- `security-auditor` (cf. `_deliverable/agents/security-auditor.md`)

### Sécurité critique sur code client

- Toujours commit un snapshot avant
- Toujours `dry-run + diff + tests`
- Jamais de `git push --force` (`deny` dans settings)
- Rollback documenté avant chaque batch

### Démo

Refactor d'un fichier de 800 lignes en 4 PRs de 200 lignes chacune. Chaque PR : 1 sub-agent dédié, 1 test, 1 commit.

---

## Module 05 — Audit code automatisé pour clients (🔴, 40 min lecture + 20 min pratique)

### Modèle business

Tu offres un "audit code rapide" packagé :
- Forfait : ex 1500-3000 € selon taille codebase
- Délai : 3-5 jours ouvrés
- Livrable : rapport PDF de 10-20 pages

Marge : très élevée (Claude Code fait le gros du travail, tu valides + ajoutes les insights stratégiques).

### Process automatisé

```
1. Client te donne accès repo (read-only)
2. Tu lances 3 sub-agents en parallèle:
   - code-reviewer (bugs, dupli, incohérences)
   - security-auditor (OWASP top 10)
   - explorer (cartographie + dette technique apparente)
3. Tu reçois 3 rapports
4. Tu synthétises + ajoutes 5-10 insights stratégiques (priorisation, business risk)
5. Tu génères le PDF avec template
6. Tu présentes en call de 30 min
```

Coût pour toi : ~2-4h. Valeur perçue par le client : énorme.

### Template du livrable PDF

```
# Audit Technique — [CLIENT]

## Executive Summary (1 page)
[3-5 conclusions + recommandations prioritaires]

## Méthodologie
[Outils utilisés, périmètre, limitations]

## Findings critiques (priorité 1)
[Bugs, failles, risques business]

## Findings importantes (priorité 2)
[Dette technique, architecture]

## Findings mineures (priorité 3)
[Cosmétique, conventions]

## Roadmap recommandée
[3-5 actions sur 30/60/90 jours]

## Annexes
[Détail technique par finding]
```

### Anti-patterns

- Promettre l'audit en 1 jour : qualité dégradée
- Livrable de 100 pages : personne ne lit, le client se perd
- Pas d'insights stratégiques : tu vends une commodity au prix de l'expertise
- Refuser de présenter : tu perds 50 % de la valeur perçue

---

## Module 06 — Facturation, admin, KPI agence (🟡, 30 min lecture + 15 min pratique)

### Pile administrative minimale

- **Lemonsqueezy ou Stripe** : encaissement des forfaits + invoices
- **Notion** (ou Airtable) : tracker clients, factures, revenu mensuel
- **GitHub Issues** : tracker travaux par client
- **Email pro** : 1 adresse dédiée, séparée de ton perso

### Slash command `/invoice`

```markdown
---
name: invoice
description: Génère une facture client à partir des inputs
---

Inputs:
1. Client (nom + raison sociale)
2. Description prestation
3. Montant HT
4. Date d'émission
5. Date d'échéance

Génère facture au format Markdown:
- Numéro séquentiel (incrémenter depuis dernier numéro dans Notion)
- Mention TVA appropriée (TVA 20% ou "TVA non applicable, art. 293 B du CGI" si AE)
- Conditions de règlement standard
- IBAN si paiement virement

Mets à jour Notion (page "Factures") avec la nouvelle ligne.
```

### KPI mensuels à mesurer

À noter dans Notion chaque mois :
- CA HT du mois
- Nb missions livrées
- Nb propositions envoyées / acceptées (taux de conversion)
- TJM moyen (CA / jours travaillés réels)
- Heures admin / heures facturables (vise < 30%)
- NPS client (1 question : recommanderais-tu sur 10 ?)

### Démo

Configurer Notion DB "Clients" + "Missions" + "Factures" → MCP Notion pour query/update via Claude Code → query type "CA cumulé mois en cours" en 1 phrase.

---

## Module 07 — Scaling sans hiring : multiplicateurs (🟡, 45 min lecture + 15 min pratique)

### Avant de hire, multiplier

Hire = +1 personne, +X% de capacité, mais +Y% de complexité (management, formation, onboarding, sales pour la nourrir).

Multiplicateurs alternatifs :
1. **Templates** : 80 % du delivery est répétitif. Templater = gain 50 % de temps.
2. **Skills réutilisables** : un skill métier construit une fois, utilisé sur 10 clients.
3. **Process documenté** : permet à un futur contractor d'appliquer SANS toi.
4. **Slash commands custom** : commit, scope, ship, proposal, invoice tous standardisés.

### Quand hire devient légitime

- Tu refuses des missions par manque de temps (et pas par choix)
- Tu mesures que +1 personne = +30 % CA minimum (sinon pas rentable)
- Tu as des process documentés qu'un nouvel arrivant peut suivre en autonomie en < 2 semaines
- Tu as 6 mois de runway pour absorber une mauvaise embauche

Avant ça : multiplier.

### Premier contractor : à temps partiel

Plutôt que CDI à temps plein dès le départ :
- Contractor 2-3 jours/semaine sur tâches répétitives (rédaction, onboarding client, support tier 1)
- Toi : focus sur missions à forte marge + sales
- Si ça marche 3 mois : envisager passage à temps plein

### Démo

Mapper tes 10 dernières missions. Identifier 3 patterns récurrents. Construire 3 templates / skills pour ces patterns. Mesurer le gain de temps sur la 11e mission.

---

## Module 08 — Pricing avancé + recurring revenue (🟡, 30 min lecture + 15 min pratique)

### Forfait audit récurrent

Modèle : tu vends un audit code à $2k. Le client est content. Tu lui proposes :
- "Audit trimestriel à $1500 / trimestre"
- "Audit mensuel + recommandations à $800 / mois"

Le second client n'a pas besoin d'être re-vendu chaque fois. Recurring revenue.

### Retainer mensuel

Pour les clients qui veulent un dev/consultant à demi-temps :
- $3-8k / mois pour 30-50h
- Tu as la liberté de ton temps, le client a la prévisibilité
- Préfère 2-3 retainers à 10 missions one-shot

### Upsell systématique

À la fin de chaque mission :
- Audit trimestriel ?
- Maintenance mensuelle ?
- Skill pack interne pour son équipe ?
- Formation 2h pour son équipe ?

L'upsell le plus simple à un client content : son taux de conversion est ~30-50%. Vs 2-5% pour un cold lead.

### Démo

Sur tes 5 derniers clients : as-tu fait un upsell ? Si non, écris l'email d'upsell type pour chacun. Envoie 1 par semaine pendant 5 semaines.

---

## Module 09 — Conclusion + plan croissance (🟢, 15 min)

### Récap

Tu as :
- Process pricing à la valeur
- Onboarding systématisé
- Workflow client async-first via MCP
- Refactor à grande échelle avec sub-agents
- Offre packagée d'audit code
- Admin/facturation automatisée
- Multiplicateurs vs hire
- Recurring revenue + upsell

### Plan 90 jours

S1-S2 : pricing + propositions templates
S3-S4 : onboarding + workflow MCP
S5-S6 : 1 audit client packagé livré
S7-S8 : facturation + KPI Notion en place
S9-S10 : 2-3 templates créés depuis tes patterns récurrents
S11-S12 : 1 upsell vendu à un client existant

À la fin des 90 jours, mesure : capacité, marge, heures admin. Compare à T-90.

### Vers où ensuite

- F2 si tu veux ton propre SaaS en parallèle
- F3 si tu veux construire des MCPs custom à monétiser
- F4 si tu vises la finance comme niche
- F1 pour rester à jour sur Claude Code
