# Exercices — AI Agency Toolkit

5 exercices ordonnés. À splitter au moment de la prod.

---

## Ex 01 — Réécrire 3 propositions clients (🟡, 1h)

Reprendre 3 propositions récentes ou créer 3 nouvelles avec le template "1 page" du module 01. Comparer longueur, clarté, taux de conversion sur 30 jours.

**Critères** : 3 propositions ≤ 1 page, mesurable, sans TJM affiché.

---

## Ex 02 — Onboarding template + 1 client réel (🟡, 1h30)

Créer le template brief client (module 02). Appliquer sur 1 nouveau client (ou simuler avec un ancien client comme rétrospective). Mesurer : combien de questions tu as eu post-kickoff vs avant.

**Critères** : template < 1 page, brief rempli pour 1 client, < 3 questions post-kickoff.

---

## Ex 03 — Setup MCPs Slack/Notion/GitHub (🔴, 2h)

Configurer les 3 MCPs sur 1 projet client réel. Tester un workflow complet : lire Slack → créer issues GitHub → update Notion. Documenter le gain de temps.

**Critères** : 3 MCPs configurés et fonctionnels, 1 workflow complet de 30 min documenté.

---

## Ex 04 — Audit code packagé (🔴, 3h)

Sur 1 codebase client réel ou demo : lancer les 3 sub-agents (explorer, code-reviewer, security-auditor). Synthétiser. Générer un PDF de 10-15 pages. Présenter en visio à un ami dev qui joue le rôle du client.

**Critères** : PDF cohérent, présentation 30 min effective, feedback du "client" simulé.

---

## Ex 05 — Multiplicateur ou hire ? (🟡, 1h)

Audit honnête de tes 10 dernières missions :
- Identifier 3 patterns répétitifs (>= 30 % du delivery)
- Choisir 1 pattern à templater / skill-iser
- Construire le template / skill
- Mesurer le gain sur la prochaine mission similaire

**Critères** : 1 template ou skill créé, mesure A/B documentée.
