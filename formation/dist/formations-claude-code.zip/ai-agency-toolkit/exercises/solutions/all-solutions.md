# Solutions — AI Agency Toolkit

## Ex 01 — Propositions

Voir template module 01 (consolidé `modules/all-modules.md`). Slash command `/proposal` : copier dans `.claude/commands/proposal.md` selon le format détaillé.

Comparaison attendue : propositions de 4-6 pages réécrites en 1 page = même taux de conversion ou meilleur, avec gain de 60-70 % de temps de rédaction.

## Ex 02 — Onboarding

Brief template appliqué = < 3 questions post-kickoff au lieu de 8-10. Le client se sent pris en charge et tu démarres la mission avec moins d'ambiguïté.

Bonus : créer aussi un slash command `/kickoff-recap` qui génère le récap post-call à partir de tes notes.

## Ex 03 — MCPs Slack/Notion/GitHub

Setup type :
```json
{
  "mcpServers": {
    "notion": { "command": "npx", "args": ["-y", "@notionhq/notion-mcp-server"], "env": { "NOTION_API_KEY": "..." } },
    "slack": { "command": "npx", "args": ["-y", "@slack/mcp-server"], "env": { "SLACK_BOT_TOKEN": "xoxb-..." } },
    "github": { "command": "node", "args": ["/path/github-issues-ts/dist/server.js"], "env": { "GITHUB_TOKEN": "ghp_...", "GITHUB_REPO": "client/repo" } }
  }
}
```

Workflow : voir module 03 "matinée client".

Gain mesuré : 20 min vs 1h pour la triage matinale. ~3-4h économisées par semaine.

## Ex 04 — Audit packagé

Workflow complet :
1. Sub-agent `explorer` sur la codebase complète (rapport architecture)
2. Sub-agent `code-reviewer` sur dernières PRs (rapport qualité)
3. Sub-agent `security-auditor` sur tout (rapport sécurité)
4. Toi : synthèse 5-10 insights stratégiques
5. PDF généré via Pandoc depuis Markdown :
   ```bash
   pandoc audit.md -o audit.pdf --pdf-engine=xelatex --toc --number-sections
   ```
6. Présentation 30 min : focus sur top 5 findings + roadmap

Pricing référence : 1500-3000 € selon taille codebase.

## Ex 05 — Multiplicateur

Exemple type :
- Pattern identifié : "audit RLS Supabase" demandé sur 4 derniers clients
- Skill créé : `supabase-rls-checker` (cf. `_deliverable/skills/supabase-rls-checker/SKILL.md`)
- Gain : 3h sur l'audit suivant (identifié les mêmes anti-patterns automatiquement)

A/B documenté : sans skill = 4h, avec skill = 1h. ROI de l'investissement skill (1h création) = positif dès la 2e utilisation.
