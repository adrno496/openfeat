# Weekly Prompts — AI Agency Toolkit

12 prompts.

## S1 — Ton TJM moyen
"CA mensuel / jours travaillés réels = ton TJM moyen. C'est combien ? Tu factures plus ou moins que ça en proposition ?"

## S2 — Ratio admin / facturable
"Combien d'heures admin (factu, devis, support) vs facturables (mission) ? Si > 30%, où tu peux automatiser ?"

## S3 — Dernière proposition
"Partage ta dernière proposition (anonymisée). On juge clarté + scope + pricing."

## S4 — Onboarding kickoff
"Ton process de kickoff : combien d'étapes ? combien de minutes ? combien de questions post-call ?"

## S5 — MCPs branchés
"Quels MCPs tu utilises dans tes workflows clients ? Lequel a le plus de valeur ?"

## S6 — Audit code packagé
"Tu as déjà vendu un audit code en forfait ? Si oui, quel pricing, quelle marge réelle ? Si non, pourquoi pas ?"

## S7 — Recurring revenue
"Quelle part de ton CA est récurrente vs one-shot ? Plan pour augmenter le récurrent ?"

## S8 — Refactor à grande échelle
"Tu as refactoré une codebase legacy client ? Process suivi, sub-agents utilisés, durée vs estimation ?"

## S9 — Hire ou multiplier
"Tu hésites à hire ? Liste tes critères. Le groupe te challenge."

## S10 — Premier upsell
"Le dernier client à qui tu as vendu un upsell : quoi, comment, taux de conversion ?"

## S11 — KPI mensuels
"Show monthly : CA, missions, NPS, gains process. 2-3 lignes."

## S12 — Plan 90 jours
"Tes 3 priorités pour le trimestre suivant."

## Notes facilitation
- Lundi matin
- Le créateur poste en exemple
- Show monthly synchrone (visio) en plus
