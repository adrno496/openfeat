# Structure Discord — AI Agency Toolkit

Communauté agency owners. Show monthly de KPI réels.

## 👋 Bienvenue
- `#règles`
- `#présente-toi` (format imposé : activité, ancienneté, MRR ou CA mensuel approximatif)
- `#annonces`

## 📚 Formation
- `#questions-pricing` (modules 01, 08)
- `#questions-onboarding` (module 02)
- `#questions-mcp-workflow` (module 03)
- `#questions-refactor` (module 04)
- `#questions-audit-package` (module 05)
- `#questions-admin-kpi` (module 06)
- `#questions-scaling` (module 07)

## 💼 Business
- `#vos-propositions` — partage anonymisé pour review
- `#vos-kpis` — partage mensuel anonymisé (KPI réels)
- `#pricing-debat` — combien tu factures pour quel résultat
- `#audit-stories` — retours sur audit code packagés livrés
- `#hire-not-hire` — débat avant chaque hire envisagé

## 🔧 Pratique
- `#mcp-help` — Notion, Slack, GitHub, Lemonsqueezy
- `#templates-partages` — propositions, briefs, audits
- `#process-docs` — vos process documentés

## 💬 Off-topic
- `#café` — détendu
- `#stack-watch` — outils complémentaires

## 🎯 Show monthly
1 fois par mois en visio : chacun 5 min sur ses KPI du mois (CA, missions, NPS, gains).

## Règles
- Bienveillance + concision
- Pas de DM spam
- Pas de partage du contenu de la formation
- KPI partagés = confidentiels (NDA implicite)
