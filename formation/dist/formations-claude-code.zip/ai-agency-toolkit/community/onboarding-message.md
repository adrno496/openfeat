# Onboarding — AI Agency Toolkit

## DM automatique

```
Salut [PRENOM] et bienvenue chez les agency owners.

Cette communauté = freelances/agences avec déjà des clients. Si tu n'as pas encore de client, vise plutôt un autre groupe.

3 étapes :
1. Lis #règles (esprit du groupe)
2. Présente-toi (format imposé : activité, ancienneté, KPI approx)
3. Engage-toi dans #show-monthly à la prochaine session

Pour tes questions :
- #questions-pricing pour modules 01, 08
- #questions-onboarding pour 02
- etc.

Pour partager :
- #vos-propositions (anonymisé) pour review
- #vos-kpis (mensuel) pour benchmarking entre pros

Pas de DM directs. Tout passe par les canaux publics.

Scale qualité, pas headcount.
[SIGNATURE]
```

## Template présente-toi

```
Prénom: [PRENOM]
Activité: [freelance dev, agence marketing, consulting, etc.]
Ancienneté: [N années]
Stack principale: [JS / Python / autre]
CA mensuel approx: [si à l'aise]
Mon biggest blocker actuel: [un blocage concret]

Hâte d'échanger.
```
