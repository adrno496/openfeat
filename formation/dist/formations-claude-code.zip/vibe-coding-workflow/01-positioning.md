# Positioning — Vibe Coding Workflow

## USP

La seule formation francophone qui te montre **ce que tu fais 80 % de ton temps avec Claude Code** — pas les features avancées que tu n'utiliseras jamais.

## Cible précise

- Dev junior à intermédiaire (3 mois à 4 ans d'XP)
- Code en JS, Python, Go, Rust ou équivalent
- A déjà installé Claude Code mais l'utilise au feeling
- Travaille en solo ou en petite équipe
- Veut un retour sur investissement immédiat sur sa productivité

## Pas la cible

- Devs qui n'ont jamais codé (formation trop technique)
- Devs séniors qui ont déjà un workflow IA mature (vise F1 ou F3)
- Spécialistes finance/quant (vise F4)

## Promesse

À la fin de cette formation, tu :
- ouvres Claude Code sans hésiter sur quel mode utiliser
- as un `CLAUDE.md` qui marche sur tes 2-3 projets principaux
- gères tes sessions sans dériver
- débugges 2x plus vite avec un protocole clair
- fais des commits propres en mode IA-assistée
- as une cheatsheet à côté de ton clavier

## Transformation mesurable

Avant : 1 à 3 sessions Claude Code par jour, productivité variable, frustration sur les bugs récurrents.
Après : 5 à 8 sessions par jour, gain de 1 à 2h par jour, 0 dérive de contexte.

## Anti-promesse

- On ne te promet pas de "remplacer un dev senior" avec Claude Code
- On ne te promet pas de coder sans réfléchir
- On ne couvre pas la création de skills ou MCP custom (c'est F3)
- On ne couvre pas l'architecture d'un SaaS (c'est F2)
