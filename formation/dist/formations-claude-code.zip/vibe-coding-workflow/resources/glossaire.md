# Glossaire — Vibe Coding Workflow

Termes techniques utilisés dans la formation, expliqués simplement.

---

**Agent (subagent)** — Un sous-processus de Claude Code qui travaille avec son propre contexte. Utile pour des tâches longues ou risquées sans polluer ta session principale. Couvert en profondeur dans F1.

**`CLAUDE.md`** — Fichier markdown à la racine d'un projet, lu automatiquement par Claude Code. Sert à dire les conventions, contraintes et commandes du projet.

**`/clear`** — Commande qui efface complètement le contexte de la session en cours. Destructif.

**`/compact`** — Commande qui demande à Claude Code de résumer la conversation en cours et de remplacer les longs échanges par ce résumé. Non destructif sur l'essentiel.

**Contexte (context window)** — La somme de ce que Claude Code "voit" dans une session : tes prompts, les fichiers qu'il a lus, ses propres réponses, les `CLAUDE.md` chargés. Limité en taille.

**Diff** — Liste des lignes ajoutées/supprimées par une modification. Lire un diff avant d'accepter une suggestion est obligatoire.

**Dry-run** — Demander à Claude Code de DÉCRIRE ce qu'il ferait sans le faire. Permet de valider une intention avant exécution.

**Hooks** — Mécanisme qui exécute des commandes avant/après certaines actions Claude Code (pre-commit, post-tool-use, etc.). Couvert dans F1.

**MCP (Model Context Protocol)** — Protocole standard pour brancher Claude Code à des outils externes (DB, APIs, etc.). Couvert dans F3.

**Patch** — Petite modification ciblée. À préférer à une réécriture complète quand tu itères.

**Prompt** — L'instruction que tu donnes à Claude Code. Un bon prompt est structuré, pas long.

**Refactor** — Modification de code qui ne change pas le comportement externe mais améliore la lisibilité ou la structure.

**Session** — Une conversation continue avec Claude Code. Une session a un contexte qui s'accumule.

**Skill** — Module réutilisable de Claude Code, défini par un `SKILL.md`. Permet d'enseigner à Claude Code à exécuter une tâche spécifique. Couvert dans F3.

**Slash command** — Commande commençant par `/` dans Claude Code (`/clear`, `/compact`, etc.). On peut en créer des custom (cf. F1).

**Squelette de prompt** — Structure standard à 4 sections (Contexte, Objectif, Contraintes, Format). Donne des résultats prévisibles.

**Stack trace** — La pile d'appels au moment d'une erreur. Critique pour debug. À donner **complète** à Claude Code, jamais tronquée.

**Sub-agent** — Voir Agent.
