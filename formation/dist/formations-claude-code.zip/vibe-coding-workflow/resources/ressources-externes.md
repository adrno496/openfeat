# Ressources externes — Vibe Coding Workflow

Liens utiles pour aller plus loin. Les URL changent — vérifie l'actualité au moment de cliquer.

---

## Documentation officielle

- Documentation Anthropic / Claude Code : `docs.anthropic.com`
- Repo officiel Claude Code : `github.com/anthropics/claude-code`
- Changelog Claude Code : voir le repo officiel, fichier CHANGELOG

## Communauté

- Discord officiel Anthropic Developers
- r/ClaudeAI sur Reddit (qualité variable, lire avec esprit critique)
- Hacker News : recherche "Claude Code" pour discussions techniques

## Lectures recommandées

### Sur le prompting structuré
- "Anthropic Cookbook" sur GitHub (exemples officiels de prompts)
- Articles d'Anthropic sur le "extended thinking" et les "agentic workflows"

### Sur Git
- "Pro Git" (livre gratuit en ligne) — chapitres sur le rebase et les hooks
- `man git-rebase` — sec mais complet

### Sur le refactoring
- "Refactoring" de Martin Fowler (le classique, applicable même hors POO)

## Outils complémentaires

- **`bat`** — `cat` avec coloration syntaxique, utile pour lire vite un fichier en CLI
- **`fd`** — `find` plus rapide et plus simple
- **`ripgrep`** (`rg`) — `grep` ultra-rapide, indispensable
- **`gh`** — CLI officielle GitHub, idéale pour PR et issues
- **`lazygit`** — TUI Git, complément agréable à Claude Code pour visualiser

## Pour aller plus loin que cette formation

- F1 — `claude-code-mastery-fr/` (référence complète)
- F2 — `solo-founder-stack/` (ship un SaaS)
- F3 — `skills-mcp-builder-pro/` (skills + MCP custom)

## Outils que tu peux brancher via MCP

(Couvert en profondeur dans F3, juste pour ouvrir l'horizon)

- GitHub (PRs, issues, files)
- Notion (notes, tâches)
- Linear (tickets)
- Postgres (queries directes)
- Filesystem (navigation locale)
- Slack (lecture canaux, envoi messages)

## Veille

- Compte X officiel d'Anthropic
- Newsletter "Latent Space" (en anglais, dense)
- Compte X de Cat Wu, Boris Cherny et autres core team Claude Code

## Tu connais d'autres ressources solides en français ?

Partage-les dans le canal #ressources du Discord. La liste évolue.
