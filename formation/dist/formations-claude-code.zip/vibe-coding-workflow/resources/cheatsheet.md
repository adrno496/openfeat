# Cheatsheet — Vibe Coding Workflow

Référence rapide imprimable. Garde-la à côté de ton clavier.

---

## Raccourcis

```
Cmd+Esc / Ctrl+Esc        Invoquer Claude Code dans VSCode
Tab                       Accepter une suggestion
Esc                       Rejeter
Cmd+P / Ctrl+P            Switch entre fichiers ouverts
Ctrl+`                    Ouvrir terminal intégré
F12                       Aller à la définition
```

## Commandes Claude Code

```
/clear                    Reset complet du contexte
/compact                  Compresser conversation longue
/exit                     Fermer la session
```

## Squelette de prompt (4 sections)

```
Contexte: [fichier/zone + état actuel]
Objectif: [verbe + résultat attendu]
Contraintes:
- [ce qu'il ne faut pas casser]
- [ce qu'il ne faut pas ajouter]
Format: [diff / plan / code complet / question]
```

## Protocole debug (5 points)

1. Stack trace **complète**
2. Repro **steps** précis
3. **Attendu**
4. **Observé**
5. **Hypothèse(s)**

## Pattern refactor sécurisé

```
Snapshot Git
  -> demander 3 propositions (impact + risque)
  -> choisir la moins risquée
  -> diff sans édition
  -> lire diff entièrement
  -> accepter
  -> tests
  -> commit ou rollback
```

## Git autorisé en autonomie

```
OK:    git status, git diff, git log, git add <file>, git commit
NON:   git push --force, git reset --hard, git branch -D
NON:   git checkout ., git restore ., git rebase
```

## `CLAUDE.md` minimum (≤ 50 lignes)

```markdown
## Stack
[5 lignes]

## Conventions code
[5 lignes]

## Trucs à ne pas faire
[3-5 puces]

## Commandes utiles
[3-8 commandes]
```

## Quand utiliser quoi

```
Nouvelle tâche, pas liée    -> fermer + rouvrir (session fresh)
Même tâche depuis 1h+       -> /compact
Conversation en vrille      -> /clear
Décision importante         -> écrire dans CLAUDE.md
Refactor 5+ fichiers        -> sub-agent
Doute sur quoi faire        -> demander 3 options avec impact+risque
Bug récurrent               -> protocole 5 points
```

## Anti-patterns

- "Refactore tout ce dossier" → trop large
- "Améliore cette fonction" → pas mesurable
- Long thread sur 8 tâches différentes → fermer-rouvrir
- Accepter un diff sans le lire → catastrophe garantie
- Stack trace tronquée → debug impossible
- `git push --force` en autonomie → réécriture distante
