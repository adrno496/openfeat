# FAQ — Vibe Coding Workflow

---

### Je n'ai jamais utilisé Claude Code, c'est trop tôt pour cette formation ?

Non. Le module 01 t'installe pas à pas. Si tu sais ouvrir un terminal et utiliser VSCode, tu peux suivre.

---

### J'ai déjà 6 mois d'usage Claude Code, est-ce trop simple pour moi ?

Probablement. Vise plutôt F1 (référence complète) ou F3 (skills + MCP).

---

### Quelle différence entre cette formation et la doc officielle ?

La doc officielle est exhaustive et en anglais. Cette formation est sélective (les 9 trucs qui comptent), en français, ancrée sur des cas réels avec exemples de code testés.

---

### Combien de temps me faut-il pour finir la formation ?

Compter 4h30 de contenu + 4h de pratique = ~8h, idéalement étalées sur une semaine à raison de 1h à 1h30 par jour.

---

### Faut-il un compte Claude Code Max ?

Recommandé pour ne pas se restreindre, mais pas obligatoire. Le compte API/Pro fonctionne aussi pour suivre la formation.

---

### Est-ce que ça marche si je code en Go / Python / Rust / autre ?

Oui. Les exemples sont en JS la plupart du temps mais les principes sont indépendants du langage.

---

### Tu ne couvres pas les MCP / sub-agents en profondeur, pourquoi ?

Parce que c'est F3 (skills + MCP) ou F1 (Mastery complète). Cette formation reste sur le quotidien volontairement.

---

### J'ai accès à vie au contenu ?

Oui. Une fois inscrit, tu accèdes à toutes les mises à jour de la formation. Le contenu évolue avec Claude Code.

---

### Y a-t-il un certificat ?

Un certificat de complétion interne, oui. Ce n'est pas un diplôme reconnu par l'État (pas de Qualiopi). Ça fait propre sur LinkedIn, c'est tout.

---

### Comment je pose mes questions ?

Trois canaux :
1. La communauté Discord (recommandé pour réponses rapides + entraide)
2. L'email support (pour les questions admin/légal)
3. Pas de DM directs au créateur (sinon ça ne tient pas)

---

### Politique de remboursement ?

Cf. CGV. Droit de rétractation 14 jours selon mécanisme légal. Vois `LEGAL-NOTES.md` pour les détails.

---

### Ça remplace mes 5 ans d'expérience dev ?

Non. Ça démultiplie tes 5 ans. Si tu n'as pas les bases du métier, Claude Code ne te transformera pas en dev senior magique.
