# Module 03 — Gérer le contexte sans saturer

**Niveau** : 🟡 intermédiaire — **Durée** : 20 min lecture + 10 min pratique

## Prérequis

Modules 01 et 02 complétés.

## Théorie courte

Claude Code a un "contexte" — la somme de ce qu'il "sait" pendant une session : ton prompt, les fichiers qu'il a lus, ses propres réponses précédentes, les `CLAUDE.md` chargés.

Ce contexte a une limite. Quand on s'en approche, deux choses arrivent :
- la qualité dégrade (Claude commence à oublier ce qui s'est passé en début de session)
- le prix par requête monte (plus de tokens à traiter à chaque tour)

Trois leviers pour gérer ça :

### `/clear` — reset complet
Vide tout. Tu repars à zéro. Utile quand tu changes radicalement de tâche.

### `/compact` — résume et garde l'essentiel
Compresse la conversation : Claude Code écrit lui-même un résumé des décisions importantes et garde ce résumé en lieu et place du fil long. Utile pour des sessions longues sur une même tâche.

### Sessions courtes par défaut
La meilleure stratégie n'est ni `/clear` ni `/compact` mais **fermer la session quand la tâche est finie** et en relancer une fresh pour la prochaine tâche.

## Démo

### Bon usage
Tu corriges un bug d'auth (15 min de session). Tu finis. Tu commits. Tu fermes Claude Code. Tu rouvres pour la prochaine tâche : ajouter un endpoint de réinit password. Session fresh, pas de pollution.

### Mauvais usage
Tu gardes la même session ouverte toute la journée pour 8 tâches différentes. Au bout de 4h, Claude Code te propose un fix qui suppose le contexte de la tâche 2 alors que tu travailles sur la tâche 6. Catastrophe silencieuse.

### Le piège du "long thread"
Plus le thread est long, plus Claude Code a tendance à :
- répéter des erreurs déjà corrigées dans le thread
- "oublier" tes contraintes du début (ex : "n'utilise pas axios")
- proposer des refactors trop agressifs

## Quand utiliser quoi

| Situation | Action |
|---|---|
| Nouvelle tâche, pas liée | Fermer + rouvrir |
| Même tâche depuis 1h, contexte chargé | `/compact` |
| Conversation partie en vrille | `/clear` |
| Tu veux garder une décision importante | Tu l'écris dans `CLAUDE.md` |

(Note : on couvre `CLAUDE.md` au module 04.)

## Exercice

1. Ouvre une session Claude Code et travaille sur une vraie tâche pendant 20 min.
2. Note : combien de fichiers ont été lus ? combien de propositions ont été faites ?
3. Lance `/compact`.
4. Continue 10 min. Compare la fluidité avec et sans compact.

## Check de validation

Tu sais :
- pourquoi le contexte saturé dégrade les réponses
- la différence entre `/clear` et `/compact`
- quand préférer fermer-rouvrir plutôt que `/compact`

## Piège classique

Penser que `/clear` est un bouton "rafraîchir". Non — c'est un reset destructif. Si tu as 30 min de raisonnement utile, tu les perds.
