# Module 04 — Multi-projets sans se perdre

**Niveau** : 🟡 intermédiaire — **Durée** : 15 min lecture + 10 min pratique

## Prérequis

Modules 01 à 03 complétés.

## Théorie courte

Tu travailles probablement sur 2 à 5 projets en parallèle. Sans méthode, Claude Code va :
- mélanger tes conventions entre projets
- proposer du code qui fonctionne dans projet A mais pas projet B
- te faire perdre du temps à re-expliquer le contexte

La solution : **un `CLAUDE.md` minimum par projet**.

## Le `CLAUDE.md` minimum viable

Dans la racine de chaque projet, un fichier `CLAUDE.md` qui contient :

```markdown
# CLAUDE.md

## Stack
- Frontend : Vanilla JS (pas de framework)
- Backend : Supabase
- Déploiement : Vercel

## Conventions code
- 2 espaces, quotes simples, pas de point-virgule
- Pas de select('*') sur Supabase, toujours colonnes explicites
- is_premium ne se mute jamais côté client

## Trucs à ne pas faire
- Ne pas ajouter de framework (React, Vue, etc.)
- Ne pas remplacer fetch par axios
- Ne pas toucher à /legacy/* sauf demande explicite

## Commandes utiles
- `npm run dev` : serveur local
- `npm run build` : build prod
- `npm test` : tests unitaires
```

Pas plus de 50 lignes. Plus c'est court, plus c'est lu attentivement à chaque session.

## Sessions persistantes vs sessions courtes

### Sessions courtes (recommandé par défaut)
Tu lances `claude` dans le projet, tu fais une tâche, tu fermes. Tu rouvres pour la suivante. Le `CLAUDE.md` charge le contexte projet automatiquement. Pas de dérive entre projets.

### Sessions persistantes
Utile uniquement si tu travailles toute la journée sur le MÊME projet. Sinon le contexte se pollue.

## Switch entre projets

```bash
# Termine la session en cours (Ctrl+D ou /exit)
cd ~/projects/projet-B
claude
```

Le nouveau `CLAUDE.md` du projet B est chargé. Conventions B appliquées.

## Démo

Tu as deux projets :
- `app-mobile/` (Capacitor + Supabase, JS strict)
- `site-media/` (Astro + Markdown)

Tu codes 1h sur l'app mobile. Tu fermes. Tu vas dans le site media et lances une session fresh. Si les `CLAUDE.md` sont bien écrits, Claude Code adapte instantanément ses conventions (2 espaces côté mobile, peut-être Astro-spécifique côté site).

## Exercice

1. Choisis tes 3 projets actifs principaux.
2. Pour chacun, crée un `CLAUDE.md` minimum (max 50 lignes).
3. Liste pour chaque : stack, conventions, "ne pas faire", commandes utiles.
4. Teste : ouvre une session dans chaque, demande "Décris-moi ce projet en 3 lignes".
5. Si la réponse n'est pas précise, ton `CLAUDE.md` est trop pauvre.

## Check de validation

Tu as :
- 3 `CLAUDE.md` propres dans tes 3 projets actifs
- Un workflow de switch entre projets sans dérive
- Compris que sessions courtes > sessions persistantes pour multi-projets

## Piège classique

Mettre 500 lignes dans `CLAUDE.md`. Personne (humain ou IA) ne lit attentivement 500 lignes. Coupe.
