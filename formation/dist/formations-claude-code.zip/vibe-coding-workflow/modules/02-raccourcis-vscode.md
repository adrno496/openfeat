# Module 02 — Raccourcis VSCode et terminal qui changent tout

**Niveau** : 🟢 débutant — **Durée** : 15 min lecture + 5 min pratique

## Prérequis

Module 01 complété. Claude Code installé en CLI et VSCode.

## Théorie courte

90 % de ton temps avec Claude Code se passe dans 8 actions répétitives. Si tu sais les déclencher en moins d'une seconde, tu gagnes plusieurs minutes par session.

## Les 8 raccourcis qui comptent

### 1. Invoquer Claude Code (VSCode)
`Cmd+Esc` / `Ctrl+Esc` — ouvre/ferme la sidebar Claude Code.

### 2. Envoyer la sélection comme contexte
Sélectionne du code dans l'éditeur, puis invoque Claude Code. Le code sélectionné est automatiquement attaché au prompt. Tu n'as pas à le coller.

### 3. Accepter une suggestion de code
Quand Claude Code propose un patch, `Tab` accepte, `Esc` rejette. Lis avant d'accepter.

### 4. Annuler la dernière action
`Cmd+Z` / `Ctrl+Z` après accept marche aussi sur les modifs Claude Code dans la plupart des cas. Mais ne te repose pas dessus pour des refactors larges — utilise Git.

### 5. Ouvrir le terminal intégré
`` Ctrl+` `` ouvre un terminal dans VSCode. Tu peux y lancer une session `claude` parallèle à l'extension.

### 6. Switch entre fichiers ouverts
`Cmd+P` / `Ctrl+P` — quand Claude Code ouvre 5 fichiers d'un coup, ce raccourci sauve la vie.

### 7. Aller à la définition
`F12` ou `Cmd+Click` sur une fonction. Avant de demander à Claude Code "où est défini X", regarde toi-même : 2 secondes vs 30 secondes.

### 8. Comparer deux versions
Sélectionne deux fichiers dans l'explorer → clic droit → "Compare Selected". Utile pour valider un refactor avant de commit.

## Démo

Workflow type "5 minutes" :
1. Tu es dans une fonction qui bug
2. `Cmd+L` (sélection ligne) puis `Cmd+Maj+L` pour étendre la sélection à la fonction entière
3. `Cmd+Esc` pour invoquer Claude Code avec la sélection
4. Tu tapes : "Cette fonction renvoie undefined parfois. Trouve pourquoi et propose un fix."
5. Tu lis la proposition, tu acceptes ou pas avec `Tab`/`Esc`

Total : 30 secondes pour un diagnostic qui prend 5 minutes en lecture manuelle.

## Exercice

Sur un projet ouvert :
1. Sélectionne une fonction de ton choix
2. Invoque Claude Code via raccourci
3. Demande : "Renomme toutes les variables locales pour qu'elles soient plus explicites, sans changer la logique."
4. Accepte la suggestion avec `Tab`
5. Vérifie le diff Git avant de commit

## Check de validation

Tu n'as plus à toucher la souris pour invoquer Claude Code. Si tu tournes encore au menu contextuel, refais l'exercice.

## Piège classique

Cliquer "Accept" sans lire. Claude Code se trompe parfois sur des subtilités (nullable, async/await, types). Toujours lire le diff.
