# Module 07 — Refactor sécurisé à grande échelle

**Niveau** : 🟡 intermédiaire — **Durée** : 20 min lecture + 15 min pratique

## Prérequis

Modules 01 à 06 complétés.

## Théorie courte

Refactorer 500 lignes d'un coup avec Claude Code, c'est tentant. C'est aussi le meilleur moyen de casser silencieusement quelque chose et de ne s'en apercevoir que 2 jours plus tard en prod.

La règle : **dry-run + diff + tests, dans cet ordre**.

## Le pattern "dry-run + diff + tests"

### Étape 1 — Dry-run
Tu demandes à Claude Code de te DÉCRIRE ce qu'il ferait, sans toucher au code :

```
Je veux refactorer src/utils/dates.js pour:
- regrouper toutes les fonctions de formatting en haut
- regrouper celles de parsing en bas
- extraire les constantes (timezone, locale) dans un objet exporté

Décris-moi les changements en 5 points avant de toucher au code.
```

Tu lis le plan. Tu valides ou tu ajustes.

### Étape 2 — Diff
Tu autorises l'édition. Claude Code propose un diff. Tu lis le diff entièrement avant accept.

### Étape 3 — Tests
Si le projet a des tests :
```
Lance les tests unitaires sur ce fichier et reporte les échecs.
```

Si pas de tests : tu lances le projet, tu testes le chemin critique manuellement.

## Quand préférer un sub-agent

(Note : les sub-agents sont couverts en profondeur dans F1. Ici juste la base.)

Si ton refactor implique de toucher 5+ fichiers liés, tu peux dire :
```
Lance un sub-agent qui s'occupe uniquement de ce refactor.
Il doit:
- lire les 5 fichiers concernés
- proposer un plan
- exécuter en plusieurs commits atomiques
- s'arrêter et te rendre la main si quelque chose n'est pas clair
```

L'avantage : ton contexte principal reste propre. Le sub-agent travaille dans son propre contexte.

## Anti-patterns à fuir

### "Refactore tout ce dossier"
Trop large. Claude Code va prendre 20 décisions et tu vas en valider 0. Tu te retrouves avec un refactor que tu n'as pas compris.

### "Améliore ce fichier"
"Améliorer" n'est pas un objectif mesurable. Soit "extraire les fonctions pures", soit "réduire les imports", soit "passer de class à function components". Soit précis.

### Ne pas commit avant le refactor
Toujours commit (même un `wip:`) avant un gros refactor. Sinon, si ça part en vrille, tu n'as pas de rollback.

## Démo

Refactor d'un fichier `src/services/auth.js` (200 lignes) :

```bash
git add src/services/auth.js
git commit -m "wip: snapshot avant refactor auth"

claude
> "Lis src/services/auth.js. Décris-moi en 5 points ce qui pourrait être refactoré pour réduire la complexité, sans changer le comportement public. Ne touche pas au code pour l'instant."

# Tu lis. Tu choisis 2-3 points sur 5.

> "Applique uniquement les points 2 et 4. Affiche le diff avant édition."

# Tu lis le diff. Tu acceptes.

> "Lance les tests."

# Si OK : commit. Si KO : rollback (git restore).
```

## Exercice

1. Choisis un fichier de ton projet de 100 à 300 lignes.
2. Commit un snapshot.
3. Suis le pattern dry-run + diff + tests.
4. Rollback à la fin (oui, vraiment) — tu testes le rollback aussi.

## Check de validation

Tu connais le pattern dry-run + diff + tests. Tu n'as plus jamais l'envie de demander "refactore tout ce dossier".

## Piège classique

Accepter un diff de 200 lignes sans le lire. Claude Code va parfois supprimer des fonctions qu'il pense inutiles mais qui sont utilisées ailleurs (qu'il n'a pas lu).
