# Module 06 — Git workflows IA-augmentés

**Niveau** : 🟡 intermédiaire — **Durée** : 20 min lecture + 10 min pratique

## Prérequis

Modules 01 à 05 complétés. Tu sais utiliser Git en CLI (commit, push, pull, branch, rebase basique).

## Théorie courte

Claude Code peut t'aider sur Git de trois façons :
1. **Rédiger des messages de commit propres** depuis un diff
2. **Reviewer une PR** avant de l'envoyer
3. **Aider sur des opérations risquées** (rebase interactif, cherry-pick)

Une règle d'or : **JAMAIS laisser Claude Code faire des opérations destructives en autonomie**. Pas de `--force-push`, pas de `reset --hard`, pas de `branch -D`. Tu valides toujours.

## Bonne pratique : commits propres

Workflow type :
```bash
git diff --staged | claude "Génère un message de commit conventionnel pour ce diff. Format: type(scope): description. Pas plus de 72 caractères."
```

Ou en VSCode : sélectionne tes changements, invoque Claude Code, demande "Génère un commit message". Tu copies le résultat.

Structure conventionnelle :
- `feat(auth): add password reset flow`
- `fix(api): handle null email in user validation`
- `refactor(db): extract query helpers`
- `chore(deps): bump react to 18.3`

## Reviewer une PR

Avant d'envoyer une PR, demande :
```
Lis tous les fichiers modifiés sur cette branche par rapport à main.
Identifie:
- bugs potentiels
- failles de sécurité (SQL injection, XSS, leak de secrets)
- duplications de code
- patterns incohérents avec le reste du projet
```

Claude Code va te trouver ce que tu n'as pas vu en relisant 3 fois ton propre diff.

## Rebase et opérations risquées

Tu peux demander à Claude Code de **t'expliquer** ce qu'il propose avant d'agir. Exemple :
```
Je veux squasher mes 4 derniers commits en 1 seul, en gardant le message du commit le plus récent.
Donne-moi la commande exacte. Je l'exécuterai moi-même.
```

Tu **n'autorises pas** Claude Code à exécuter `git rebase -i` en mode autonome. Tu prends la commande, tu la lances toi-même, tu vérifies à chaque étape.

## Sécurité : checklist Git Claude Code

Ce que tu peux laisser en autonomie :
- `git status`, `git diff`, `git log` (lecture)
- `git add` sur des fichiers spécifiques
- `git commit` avec message vérifié

Ce que tu NE laisses PAS en autonomie :
- `git push --force` (réécrit l'historique distant)
- `git reset --hard` (perd des changements locaux)
- `git branch -D` (supprime une branche)
- `git checkout .` ou `git restore .` (perd des changements non commités)
- `git rebase` (peut casser l'historique)

Si Claude Code propose une de ces commandes, tu la lis, tu comprends, tu lances toi-même.

## Démo

```bash
# Tu finis une feature
git add src/auth/reset-password.js src/auth/reset-password.test.js

# Tu génères le commit message
git diff --staged | claude "Génère un commit message conventionnel."
# Sortie: "feat(auth): add password reset endpoint with email token"

git commit -m "feat(auth): add password reset endpoint with email token"

# Avant push
claude "Lis tous les fichiers sur cette branche vs main. Cherche bugs et failles."
# Tu lis le rapport, tu corriges si besoin, tu push.
git push
```

## Exercice

1. Sur une branche en cours, fais 3 commits avec des messages générés par Claude Code
2. Demande-lui de reviewer toute la branche avant push
3. Note ce qu'il a trouvé que tu n'avais pas vu

## Check de validation

Tu connais la liste des opérations Git que tu ne laisses jamais en autonomie. Tu sais générer un commit message propre depuis un diff.

## Piège classique

Laisser Claude Code lancer `git push` sans avoir relu son review. Toujours relire AVANT de push.
