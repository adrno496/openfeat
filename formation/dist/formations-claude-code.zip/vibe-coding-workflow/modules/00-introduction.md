# Module 00 — Introduction

**Niveau** : 🟢 débutant — **Durée** : 10 min lecture

## Pourquoi cette formation existe

La majorité des devs qui découvrent Claude Code passent par les mêmes étapes :
1. Installation, première commande, effet "wow"
2. Utilisation au feeling pendant 2 semaines
3. Frustration : ça hallucine parfois, le contexte dérive, les commits sont brouillons
4. Abandon partiel ou usage à 20 % du potentiel

Cette formation court-circuite ce parcours. Elle te donne le workflow qu'un dev expérimenté avec Claude Code aurait construit après 3 mois d'usage intensif.

## Ce que tu vas apprendre

Pas de magie, pas de prompt secret. Juste neuf habitudes simples qui se renforcent l'une l'autre :
- comment installer proprement
- les raccourcis qui changent la vie
- gérer le contexte
- jongler entre projets
- débugger
- utiliser Git sans risque
- refactorer en sécurité
- prompter efficacement

## Comment suivre

Une à deux modules par jour, dans l'ordre. Chaque module a :
- une partie théorique courte
- une démo réelle avec du code
- un exercice à faire dans tes propres projets
- un check de validation

Si tu sautes les exercices, tu rates 70 % de la valeur.

## Engagement minimum

30 min de pratique réelle par jour pendant la durée de la formation. Si tu n'as pas ce créneau, attends d'avoir le temps. Lire sans pratiquer ne marche pas pour ce sujet.

## Communauté

Tu as accès au Discord. Quand tu es bloqué plus de 15 min, demande de l'aide. Personne n'est jugé, tout le monde est passé par là.

## Tech requise

- macOS, Linux, ou Windows + WSL2
- VSCode installé
- Un terminal qui te plaît (zsh, bash, fish — peu importe)
- Compte Anthropic (Claude Code Max recommandé)

Si tu n'as pas Claude Code installé, le module 01 te guide.

## C'est parti

Ouvre `modules/01-installation-flow.md`.
