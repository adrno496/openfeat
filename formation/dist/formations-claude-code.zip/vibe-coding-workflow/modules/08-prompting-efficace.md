# Module 08 — Prompting qui marche dès la 2e tentative

**Niveau** : 🟡 intermédiaire — **Durée** : 20 min lecture + 10 min pratique

## Prérequis

Modules 01 à 07 complétés.

## Théorie courte

Un bon prompt à Claude Code, ce n'est pas un prompt long. C'est un prompt **structuré** :

```
[Contexte minimal]
[Objectif]
[Contraintes]
[Format de sortie attendu]
```

4 sections, chacune en 1 à 3 phrases. Total : 4 à 12 lignes.

## Le squelette qui marche 9 fois sur 10

```
Contexte: tel fichier fait X. On veut Y.
Objectif: ajouter / modifier / extraire Z.
Contraintes:
- ne pas toucher à A
- garder l'API publique stable
- pas de nouvelle dépendance
Format de sortie: diff sur le seul fichier concerné.
```

## Exemples concrets

### Mauvais (vague)
```
Améliore cette fonction.
```

### Mauvais (trop long)
```
Alors voilà, j'ai cette fonction qui fait des trucs et j'aimerais que ce soit
plus propre, peut-être que tu pourrais regarder ce qui pourrait être amélioré
et me dire ce que tu en penses, en gros j'aimerais que ça soit plus
maintenable et lisible et que ce soit testable et que [...]
```

### Bon
```
Contexte: src/api/users.js a une fonction createUser() de 80 lignes qui fait validation + insert + email.
Objectif: extraire la validation dans validateUserInput() et l'envoi d'email dans sendWelcomeEmail().
Contraintes:
- l'API publique createUser(input) reste identique
- pas de nouvelle dépendance
- les 3 fonctions vivent dans le même fichier
Format: diff unique sur src/api/users.js.
```

## Itérer en mode "patch"

Quand la première réponse est presque bonne mais pas exactement, **n'ordonne pas une réécriture totale**. Demande un patch :

```
Le diff précédent est OK sauf le point 3: tu as supprimé l'import de bcrypt
qu'on utilise dans une autre partie du fichier. Modifie uniquement cet import,
ne retouche pas le reste.
```

Tu économises tokens. Tu réduis le risque de régression.

## Quand "trop d'instructions" devient contre-productif

Si ton prompt fait 30 lignes, Claude Code va parfois "oublier" la moitié. Test simple : reste-le 5 jours plus tard, est-ce que tu peux retenir tout ce que tu as demandé ? Si non, ton prompt est trop long.

## Le prompt "iterate" qui sauve

Quand tu n'es pas sûr de ce que tu veux :
```
Voici la fonction X. Ne modifie rien.
Liste 3 améliorations possibles, chacune avec:
- description en 1 phrase
- impact (faible/moyen/fort)
- risque de régression (faible/moyen/fort)

Je choisirai laquelle appliquer.
```

Tu transformes un "fais quelque chose" en "propose, je décide".

## Démo

Tâche : ajouter une validation d'email dans une fonction d'inscription.

```
Contexte: src/auth/signup.js, fonction signup(email, password, name).
Aujourd'hui: pas de validation de format email.
Objectif: refuser inscription si email mal formé. Retourner {error: 'invalid_email'}.
Contraintes:
- regex simple, pas de lib externe
- erreur retournée AVANT toute écriture en DB
- garder le reste de la logique intacte
Format: diff sur src/auth/signup.js + 2 cas de test (email valide, email invalide).
```

Réponse en moins d'une minute, généralement bonne au premier essai.

## Exercice

Prends 3 prompts que tu as utilisés cette semaine. Réécris-les avec le squelette à 4 sections. Compare les résultats.

## Check de validation

Tu connais le squelette à 4 sections. Tu sais quand demander un "patch" plutôt qu'une réécriture. Tu sais demander "propose 3 options" quand tu n'es pas sûr.

## Piège classique

Mettre la contrainte la plus importante à la fin d'un long prompt. Claude Code la lit mais peut la pondérer moins. Mets-la en haut ou répète-la.
