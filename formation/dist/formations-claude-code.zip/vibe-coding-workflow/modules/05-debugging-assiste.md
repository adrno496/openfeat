# Module 05 — Debugging assisté qui marche vraiment

**Niveau** : 🟡 intermédiaire — **Durée** : 20 min lecture + 15 min pratique

## Prérequis

Modules 01 à 04 complétés.

## Théorie courte

90 % des sessions Claude Code "qui ne marchent pas" sur un bug viennent du même problème : **l'utilisateur ne donne pas les bonnes informations au bon moment**.

Le bon protocole :

1. **Stack trace complète** (pas un extrait)
2. **Repro steps** : ce que tu as fait, dans l'ordre
3. **Comportement attendu** : ce qui aurait dû se passer
4. **Comportement observé** : ce qui s'est passé
5. **Hypothèses** (les tiennes, même fausses)

Ces 5 points doivent figurer dans ton premier message. Pas de "ça marche pas, débugue".

## Démo

### Mauvais prompt
```
Mon endpoint /api/users plante. Trouve pourquoi.
```

Claude Code va lire 12 fichiers, deviner, échouer plusieurs fois.

### Bon prompt
```
L'endpoint POST /api/users (src/routes/users.js) renvoie 500.

Stack:
TypeError: Cannot read property 'email' of undefined
  at validateUser (src/routes/users.js:23)
  at handler (src/routes/users.js:14)

Repro:
1. POST /api/users avec body {"name": "Axel"}
2. (note: pas de champ "email" dans le body)

Attendu: 400 avec message "email required"
Observé: 500

Hypothèse: la validation se fait après l'accès à user.email, donc on lit avant de valider.

Trouve la racine et propose un fix minimal qui ne casse pas les autres validations.
```

Cette fois Claude Code va droit au but. Il ouvre le fichier indiqué, lit les ~50 lignes utiles, propose une correction ciblée.

## La règle des 3 essais

Si Claude Code échoue 3 fois de suite à fixer un bug :
1. **Stop**. Ne tente pas un 4e essai en escaladant tes prompts.
2. Lis ce que tu lui as donné. Tu as probablement omis une info clé.
3. Reformule en repartant de zéro avec les 5 points ci-dessus.
4. Si encore échec : c'est probablement un bug que tu dois résoudre toi-même, l'IA n'a pas accès à un signal nécessaire (logs runtime, état réseau, race condition).

## Quand laisser Claude Code chercher tout seul

Quand tu as **un message d'erreur clair** mais tu ne sais pas où il vient. Là tu peux lui dire :

```
Cherche d'où vient cette erreur dans le projet :
"ValidationError: 'role' must be one of ['admin', 'user']"

Ne propose rien avant d'avoir trouvé le fichier source.
```

Claude Code va grep, ouvrir, identifier. C'est ce qu'il fait le mieux.

## Quand le guider

Quand tu sais déjà où chercher mais tu n'as pas envie de lire 200 lignes. Là tu lui dis le fichier précis.

## Exercice

Sur ton projet :
1. Identifie un bug que tu as en tête (ou cherche-en un dans tes issues)
2. Rédige un prompt complet selon les 5 points
3. Lance Claude Code, observe la rapidité de réponse
4. Compare avec ce qui se serait passé avec un prompt vague

## Check de validation

Tu peux nommer les 5 points d'un bon prompt de debug. Tu sais quand laisser Claude Code chercher seul vs quand le guider.

## Piège classique

Donner une stack tronquée. Les 3 dernières lignes de la stack sont souvent moins importantes que les 5 premières (qui pointent ton code à toi).
