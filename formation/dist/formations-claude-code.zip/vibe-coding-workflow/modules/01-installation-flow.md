# Module 01 — Installation et premier flow

**Niveau** : 🟢 débutant — **Durée** : 15 min lecture + 10 min pratique

## Prérequis

- macOS, Linux ou Windows+WSL2
- Node 18+ ou un autre runtime que Claude Code supporte
- Un compte Anthropic (Claude Code Max recommandé pour ne pas se limiter)

## Théorie courte

Claude Code se présente sous trois formes :
- **CLI** : commande `claude` dans ton terminal
- **Extension VSCode** : interface intégrée
- **Web** : claude.ai/code (utile en mobilité)

Les trois partagent ton compte mais pas tes sessions. La majorité du temps, tu vas vivre dans la CLI ou l'extension VSCode.

## Démo

### Installation CLI

```bash
npm install -g @anthropic-ai/claude-code
claude --version
```

Premier lancement :
```bash
claude
```

Tu suis le prompt d'authentification (login OAuth dans ton navigateur). Ton token est stocké dans `~/.claude/`.

### Installation VSCode

Marketplace VSCode → "Claude Code" → Installer.
Raccourci par défaut pour invoquer : `Cmd+Esc` (macOS) / `Ctrl+Esc` (Linux/Windows).

### Premier flow

Dans un projet existant :
```bash
cd ~/projects/mon-projet
claude
```

Premier prompt utile :
```
Lis README.md et donne-moi un résumé de l'architecture du projet en 5 points.
```

Claude Code va lire ton README, explorer si nécessaire, et te répondre. Pas besoin de lui dire où chercher — il sait.

## Exercice

Dans ton projet actif :
1. Lance `claude` à la racine
2. Demande : "Liste les 5 fichiers les plus importants du projet et explique-moi le rôle de chacun en 1 ligne."
3. Note ce qu'il a trouvé.
4. Demande ensuite : "Quelles parties du projet semblent inachevées ou risquées ?"

Cet exercice teste deux choses : sa capacité à explorer (Q1) et sa capacité à juger (Q2).

## Check de validation

Tu sais :
- lancer `claude` dans n'importe quel projet
- invoquer Claude Code dans VSCode avec le raccourci
- savoir où sont stockées tes credentials

Tu peux passer au module 02.

## Piège classique

Lancer Claude Code dans un dossier énorme (genre `~/`) avec 50k fichiers. Il va passer du temps à essayer de comprendre l'environnement. Toujours `cd` dans le projet précis.
