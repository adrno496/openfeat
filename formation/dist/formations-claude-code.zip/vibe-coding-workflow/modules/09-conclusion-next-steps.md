# Module 09 — Conclusion et next steps

**Niveau** : 🟢 débutant — **Durée** : 10 min lecture

## Récap des 9 modules

Tu as appris :
- à installer et lancer Claude Code dans un projet
- les 8 raccourcis qui changent ton flow
- à gérer le contexte (sessions courtes > /clear > /compact)
- à jongler entre projets avec un `CLAUDE.md` minimum par repo
- un protocole de debug à 5 points qui marche
- des Git workflows IA-augmentés sans risque
- le pattern dry-run + diff + tests pour refactor
- le squelette de prompt à 4 sections

C'est la base solide. Si tu appliques les 9, tu es déjà au-dessus de 80 % des devs qui utilisent Claude Code.

## Plan de pratique sur 4 semaines

### Semaine 1 — Installation des habitudes
- Utiliser les 8 raccourcis (module 02) chaque jour
- Créer 3 `CLAUDE.md` minimum (module 04)

### Semaine 2 — Debug et Git
- Appliquer le protocole de debug 5 points (module 05) sur tous tes bugs
- Générer tous tes commit messages avec Claude Code (module 06)

### Semaine 3 — Refactor
- Refactorer 3 fichiers en suivant dry-run + diff + tests (module 07)
- Utiliser sub-agents au moins une fois

### Semaine 4 — Prompting
- Réécrire 10 de tes prompts au squelette 4 sections (module 08)
- Mesurer : combien de fois tu obtiens un bon résultat dès le 2e essai ?

## Auto-évaluation

À la fin des 4 semaines, tu devrais pouvoir cocher :
- [ ] Je n'utilise plus la souris pour invoquer Claude Code
- [ ] Mes 3 projets actifs ont chacun un `CLAUDE.md`
- [ ] Mes commit messages sont conventionnels
- [ ] Je débugge plus vite qu'il y a un mois
- [ ] Je sais quand fermer une session et en ouvrir une fresh
- [ ] Je n'ai pas peur de refactorer un gros fichier

Si tu coches 5/6, tu as fini cette formation. Si moins, refais les modules concernés.

## Vers F1 si tu veux aller plus loin

F6 (cette formation) couvre **le quotidien**. F1 (`claude-code-mastery-fr/`) couvre **toute la surface** : sub-agents custom, skills, hooks, slash commands, MCP servers, optimisation coûts, sécurité avancée.

Si à la fin de cette formation tu te dis "OK, j'ai compris les bases, maintenant je veux maîtriser totalement Claude Code", F1 est la suite logique.

## Vers F2 si tu construis un produit

Si tu construis un SaaS ou une app, F2 (`solo-founder-stack/`) te montre comment shipper en 30 jours avec une stack légère (Vanilla JS, Capacitor, Supabase).

## Communauté

Le Discord reste accessible. Les apprenants qui restent actifs après la formation sont ceux qui progressent le plus. Reviens au moins une fois par semaine.

## Merci

Tu as investi du temps et de l'argent dans cette formation. Le vrai retour vient des semaines qui viennent. Rapporte tes gains : combien de minutes par jour, combien de bugs en moins, combien de PR mieux écrites.

Tag-moi sur X ou LinkedIn quand tu shippes quelque chose grâce à ce que tu as appris ici.

À la prochaine.
