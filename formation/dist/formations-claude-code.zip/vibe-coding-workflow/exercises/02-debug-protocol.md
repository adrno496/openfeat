# Exercice 02 — Applique le protocole de debug 5 points

Niveau : 🟡
Durée : 45 min

## Énoncé

Trouve dans ton projet (ou dans tes issues) **3 bugs réels** que tu n'as pas encore résolus. Pour chacun, rédige un prompt Claude Code complet en suivant le squelette du module 05 :

1. Stack trace complète
2. Repro steps
3. Comportement attendu
4. Comportement observé
5. Hypothèse(s)

Lance la session, observe le résultat. Si Claude Code ne trouve pas dès le 1er ou 2e tour, ne reformule pas en escaladant — applique la règle des 3 essais.

## Critères de réussite

- 3 prompts rédigés respectant les 5 points
- Pour chaque bug : Claude Code identifie la racine en ≤ 2 tours
- Tu peux résumer la cause de chaque bug en 1 phrase à la fin

## Si Claude Code échoue 3 fois

Documente pourquoi : info manquante, bug environnemental, race condition, etc. C'est de l'info précieuse sur les limites de l'outil.

## Pièges à éviter

- Donner une stack tronquée
- Oublier les repro steps (Claude Code ne peut pas deviner)
- Tomber dans la tentation de "tester n'importe quoi" au 4e essai

## Auto-check

- [ ] 3 bugs réels identifiés
- [ ] 3 prompts rédigés selon le squelette 5 points
- [ ] Au moins 2 bugs résolus en ≤ 2 tours
- [ ] Pour le 3e (si bloqué), tu sais pourquoi Claude Code ne pouvait pas y arriver
