# Exercice 03 — Refactor sécurisé d'un fichier réel

Niveau : 🟡
Durée : 45 min

## Énoncé

Choisis un fichier de ton projet de 100 à 300 lignes. Applique le pattern dry-run + diff + tests :

1. Commit un snapshot avant (`git commit -m "wip: snapshot avant refactor"`)
2. Demande à Claude Code 3 améliorations possibles avec impact + risque (sans toucher au code)
3. Choisis la moins risquée
4. Demande le diff sans édition
5. Lis le diff entièrement
6. Accepte
7. Lance les tests (ou test manuel si pas de tests)
8. Commit ou rollback

À la fin de l'exercice, **rollback** vers le snapshot. L'objectif est l'apprentissage du process, pas de modifier le code en prod.

## Critères de réussite

- Snapshot commité avant
- 3 propositions reçues avec impact + risque
- Le diff est lu entièrement (pas accepté à l'aveugle)
- Tests passants (ou validation manuelle)
- Rollback effectué proprement (`git reset --hard <hash-snapshot>`)

## Pièges à éviter

- Sauter le snapshot ("ça va bien se passer")
- Choisir l'amélioration la plus impactante au lieu de la moins risquée
- Accepter le diff sans le lire
- Oublier le rollback à la fin

## Auto-check

- [ ] Snapshot commité avec hash noté
- [ ] 3 propositions reçues
- [ ] Diff lu en entier
- [ ] Tests passants
- [ ] Rollback effectué et vérifié (`git diff` vide après rollback)
