# Solution — Exercice 02 (Protocole de debug 5 points)

## Exemple complet de prompt résolu en 1 tour

### Bug : un endpoint renvoie 500 au lieu de 400

**Prompt rédigé (5 points) :**

```
L'endpoint POST /api/users (src/routes/users.js) renvoie 500.

Stack:
TypeError: Cannot read property 'email' of undefined
  at validateUser (src/routes/users.js:23:18)
  at handler (src/routes/users.js:14:3)

Repro:
1. POST /api/users avec body {"name": "Axel"}
2. Pas de champ email dans le body

Attendu: 400 avec {error: 'email_required'}
Observé: 500 avec stack trace en clair (failure of validation safety)

Hypothèse: la validation accède à user.email avant de vérifier que user et email
existent. L'ordre des checks doit être inversé.

Trouve la racine et propose un fix minimal qui ne casse pas les autres validations.
```

**Résolution Claude Code (résumé attendu) :**
- Lit `src/routes/users.js`, ligne 23
- Confirme l'hypothèse : `user.email` est lu avant `if (!user || !user.email)`
- Propose un patch :

```js
function validateUser(user) {
  if (!user || typeof user !== 'object') {
    return { ok: false, error: 'invalid_payload' }
  }
  if (!user.email || typeof user.email !== 'string') {
    return { ok: false, error: 'email_required' }
  }
  // ... reste de la validation
  return { ok: true }
}
```

- Ajoute mention de tests à écrire (cas vide, email manquant, email mal formé)

## Pourquoi ça a marché en 1 tour

- Stack trace **complète** (file + ligne + fonction)
- Repro **précise** (exemple de payload exact)
- Attendu/observé **mesurables** (codes HTTP)
- Hypothèse **plausible** : Claude Code l'utilise comme point de départ et la valide ou l'infirme

## Exemple où il faut 2 tours

### Tour 1 — première hypothèse fausse

```
Tour 1: Claude Code propose de changer le check d'auth car il pensait que le 500
venait d'un user non authentifié.
```

### Tour 2 — relance ciblée

```
Le check d'auth n'est pas le problème : l'endpoint est public (cf. middleware
sur src/server.js:42). Le 500 vient bien de validateUser. Reprends à partir
de la stack trace, pas de mes hypothèses.
```

Tour 2 résout. Note bien : on n'a pas escaladé en re-balançant tout le contexte. On a corrigé une fausse piste.

## Si tu arrives au tour 3 sans résolution

Documente :
- Ce que Claude Code a essayé
- Pourquoi ça n'a pas marché
- L'info qui te manquait (souvent : logs runtime, état DB, valeur d'une variable d'env)

C'est un bug que tu dois résoudre avec un debugger, pas avec une IA.
