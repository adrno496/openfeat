# Solution — Exercice 03 (Refactor sécurisé)

## Workflow complet commenté

### Étape 1 — Snapshot

```bash
git status                       # vérifier qu'on n'a pas de changements traînants
git add -A
git commit -m "wip: snapshot avant refactor utils/dates.js"
git rev-parse HEAD               # noter le hash, ex: a1b2c3d
```

### Étape 2 — Demande de propositions (sans édition)

Prompt :

```
Lis src/utils/dates.js (220 lignes).
Sans modifier le code, liste 3 améliorations possibles.
Pour chacune:
- description en 1 phrase
- impact (faible/moyen/fort)
- risque de régression (faible/moyen/fort)
```

Réponse type :

```
1. Extraire les constantes (timezone, locale) dans un objet TIMEZONE_CONFIG
   - Impact: faible (lisibilité)
   - Risque: faible (pas de logique modifiée)

2. Regrouper les fonctions par usage (formatting / parsing / arithmetic)
   - Impact: moyen (lisibilité, navigation)
   - Risque: faible (réorganisation pure)

3. Remplacer les manipulations manuelles par date-fns
   - Impact: fort (code plus court, mieux testé en amont)
   - Risque: fort (changement de dépendance, comportement timezone subtil)
```

### Étape 3 — Choix : option 1 (la moins risquée)

```
Applique uniquement l'option 1.
Affiche le diff sans éditer.
```

### Étape 4 — Lecture du diff

Tu lis chaque ligne. Tu vérifies :
- aucune fonction supprimée
- aucune signature modifiée
- aucun import retiré qui sert ailleurs

### Étape 5 — Acceptation

Tu acceptes (ou tu raffines).

### Étape 6 — Tests

```bash
npm test -- src/utils/dates.test.js
```

Tous verts. Tu commits :

```bash
git add src/utils/dates.js
git commit -m "refactor(utils): extract timezone config to constant"
```

### Étape 7 — Rollback (pour l'exercice)

```bash
git reset --hard a1b2c3d
git diff                         # doit être vide
```

## Ce que tu as appris

- Le snapshot est un **filet de sécurité** indispensable
- Demander 3 propositions avec impact + risque permet un choix éclairé
- Choisir le plus faible risque la première fois est la bonne stratégie
- Le rollback fonctionne — tu n'es jamais coincé

## Variations possibles (à tester plus tard)

- Au lieu d'option 1, tester option 2 (regroupement) avec dry-run
- Tester l'option 3 (date-fns) sur une branche dédiée pour comparer

L'objectif n'est pas de faire LE bon refactor du premier coup. C'est de **savoir refactorer sans casser**.
