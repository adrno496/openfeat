# Solution — Exercice 01 (3 `CLAUDE.md` minimum)

## Exemple commenté pour un projet vanilla JS + Supabase

```markdown
# CLAUDE.md

## Stack
- Frontend : Vanilla JS (pas de framework)
- Backend : Supabase (Postgres + Auth + Storage)
- Déploiement : Vercel
- Paiements : Lemonsqueezy

## Conventions code
- Indentation 2 espaces, quotes simples, pas de point-virgule
- ES Modules natifs, pas de bundler côté frontend
- Pas de framework ajouté sans validation explicite

## Trucs à ne pas faire
- Pas de select('*') sur Supabase, toujours colonnes explicites
- is_premium ne se mute jamais côté client (toujours via RPC)
- Ne pas remplacer fetch par axios
- Ne pas modifier /legacy/* sauf demande explicite

## Commandes utiles
- `npm run dev` : serveur local sur :3000
- `npm run build` : build prod
- `npm run db:types` : régénère types TS depuis Supabase
- `npx supabase migration new <nom>` : nouvelle migration
```

### Pourquoi ce format

- Sections claires, parsing rapide pour Claude Code
- "Trucs à ne pas faire" est la section qui économise le plus de back-and-forth
- Commandes utiles : Claude Code peut les suggérer plutôt que de réinventer
- Pas de duplication de ce que `package.json` ou le code montrent déjà

## Exemple pour un projet Astro / blog

```markdown
# CLAUDE.md

## Stack
- Astro 4
- Markdown pour les articles (collection `blog`)
- Tailwind 3
- Déploiement : Vercel

## Conventions code
- Indentation 2 espaces, quotes simples
- Composants Astro `.astro`, pas de React/Vue
- Slugs en kebab-case

## Trucs à ne pas faire
- Ne pas ajouter d'island JavaScript sans raison (perf SEO)
- Ne pas toucher à content/ schema sans confirmer (régénération full)
- Pas de framework client (React, Vue) ajouté

## Commandes utiles
- `npm run dev` : serveur local sur :4321
- `npm run build && npm run preview` : test prod local
- `npm run check` : type check Astro
```

## Anti-pattern (à NE PAS faire)

```markdown
# CLAUDE.md

This is a project. We use modern web technologies. The frontend is built with
JavaScript and the backend uses a database. We follow best practices.

When you make changes, please make sure to:
- write good code
- follow the conventions
- be helpful

[...300 lignes de banalités...]
```

Pourquoi c'est mauvais : zéro information actionnable. Claude Code ne sait toujours pas quoi éviter.
