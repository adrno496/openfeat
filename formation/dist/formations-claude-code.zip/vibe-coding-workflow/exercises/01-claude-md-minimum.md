# Exercice 01 — Crée 3 `CLAUDE.md` minimum

Niveau : 🟢
Durée : 30 min

## Énoncé

Choisis 3 projets actifs sur lesquels tu travailles régulièrement. Pour chacun, crée un `CLAUDE.md` à la racine.

Chaque `CLAUDE.md` doit contenir, et rien de plus :
- 1 section "Stack" (3 à 6 lignes max)
- 1 section "Conventions code" (5 lignes max)
- 1 section "Trucs à ne pas faire" (3 à 5 puces)
- 1 section "Commandes utiles" (3 à 8 commandes)

Total : ≤ 50 lignes.

## Critères de réussite

- Les 3 fichiers existent et sont commités
- Chacun fait moins de 50 lignes
- Tu peux résumer chaque projet en 1 phrase grâce à ton `CLAUDE.md`
- Tu lances `claude` dans chaque projet et la première réponse à "Décris-moi ce projet en 3 lignes" reflète bien le projet

## Pièges à éviter

- Copier-coller le même `CLAUDE.md` entre projets (chacun doit être spécifique)
- Mettre des listes longues "tout ce que mon projet fait" (inutile, Claude Code lit le code)
- Oublier la section "Trucs à ne pas faire" (c'est la plus utile en pratique)

## Auto-check

- [ ] 3 fichiers `CLAUDE.md` créés
- [ ] Aucun ne dépasse 50 lignes
- [ ] Chaque section "Trucs à ne pas faire" contient au moins une règle spécifique au projet
- [ ] Test "Décris-moi ce projet en 3 lignes" donne un résultat précis dans les 3 projets
