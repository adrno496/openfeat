# 🚀 Vibe Coding Workflow

**Doubler ta productivité dev en 1 semaine avec Claude Code.**

Format court (≈ 2h de contenu vidéo + ~3h de pratique). Conçue pour les devs qui veulent intégrer Claude Code à leur flow quotidien sans y passer un week-end de formation.

---

## Pour qui

Devs débutants à intermédiaires, freelances et curieux d'IA qui codent déjà mais qui :
- ouvrent Claude Code de temps en temps sans vraie méthode
- ne savent pas vraiment quand l'utiliser et quand l'éteindre
- n'ont jamais configuré un `CLAUDE.md` projet
- aimeraient gagner 1 à 2 heures par jour

---

## Ce que tu obtiens

- 9 modules courts (≤ 30 min chacun) avec démos sur des cas réels
- Une cheatsheet imprimable
- Des templates de `CLAUDE.md` et de settings
- Un workflow Git assisté qui ne casse rien
- Une méthode de prompting qui marche dès la 2e tentative
- L'accès à la communauté Discord pour bloquer 0 fois

---

## Structure du dossier

```
vibe-coding-workflow/
├── 00-syllabus.md           # Plan détaillé
├── 01-positioning.md        # Pour qui, pourquoi, transformation
├── modules/                 # 9 modules + intro + conclusion
├── exercises/               # 3 exercices avec solutions
├── resources/               # Cheatsheet, glossaire, FAQ, liens
├── templates/               # CLAUDE.md, settings.json prêts à l'emploi
├── video-scripts/           # Scripts de tournage (≤ 90 sec à 5 min)
├── marketing/               # Landing, emails, posts (sans prix)
└── community/               # Structure Discord, prompts hebdo
```

---

## Comment utiliser cette formation

1. Démarre par `modules/00-introduction.md`
2. Suis les modules dans l'ordre — chaque module dépend du précédent
3. Fais l'exercice associé avant de passer au suivant
4. Réfère-toi à `resources/cheatsheet.md` pendant tes sessions de code
5. Pose tes questions dans la communauté quand tu es bloqué

---

## Prérequis

- Avoir un terminal qui fonctionne (macOS, Linux ou WSL)
- Avoir VSCode installé
- Connaître les bases d'un langage (JS, Python, Go ou autre — peu importe)
- Avoir un compte Anthropic ou Claude Code Max

Si tu n'as pas Claude Code installé, le module 01 te guide pas à pas.
