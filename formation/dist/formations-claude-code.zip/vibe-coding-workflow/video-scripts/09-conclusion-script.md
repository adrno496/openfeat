# Script vidéo — Module 09 : Conclusion et next steps

**Durée cible** : 3-4 min

## Plan

### Intro (15 sec)
"Récap des 9 modules. Plan de pratique 4 semaines. Et où aller ensuite."

### Récap rapide (60 sec)
Liste des 9 habitudes apprises. Pas de re-démo.

### Plan 4 semaines (60 sec)
- S1 : raccourcis + CLAUDE.md
- S2 : debug + Git
- S3 : refactor
- S4 : prompting

### Auto-évaluation (30 sec)
6 questions à cocher. Si 5/6 → fini. Si moins → refais les modules concernés.

### Vers F1 / F2 (30 sec)
- F1 : la totale (sub-agents, skills, hooks, MCP)
- F2 : ship un SaaS en 30 jours

### Communauté + remerciement (30 sec)
Reviens dans le Discord. Tag-moi quand tu shippes.

### Outro (15 sec)
"À la prochaine."

## Notes tournage

- Plan poitrine, regard caméra
- Pas de musique de fin "épique"
- Lecture posée, pas pressée
