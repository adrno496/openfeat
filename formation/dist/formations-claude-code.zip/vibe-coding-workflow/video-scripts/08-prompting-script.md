# Script vidéo — Module 08 : Prompting efficace

**Durée cible** : 5 min

## Plan

### Intro (15 sec)
"Un bon prompt n'est pas long. Il est structuré. 4 sections, point."

### Squelette à l'écran (30 sec)
Contexte / Objectif / Contraintes / Format

### Démo bon vs mauvais (2 min)
Trois variantes :
1. Vague : "améliore"
2. Trop long (lecture rapide d'un pavé)
3. Squelette 4 sections

Lancer les 3, montrer la qualité de réponse.

### Mode patch vs réécriture (60 sec)
"Le diff précédent est OK sauf le point 3. Modifie uniquement ça."
Vs "Refais tout."

### Mode "iterate" : propose 3 options (45 sec)
Quand tu n'es pas sûr.

### Piège : contrainte importante en fin de prompt (30 sec)
"Mets-la en haut ou répète."

### Outro (15 sec)
"Module 09 : récap et plan de pratique 4 semaines."
