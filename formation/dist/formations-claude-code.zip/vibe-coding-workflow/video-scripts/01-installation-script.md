# Script vidéo — Module 01 : Installation et premier flow

**Durée cible** : 4-6 min

## Plan

### Intro (15 sec)
"On installe Claude Code. CLI et VSCode. Et on lance notre première vraie session sur un projet existant."

### Démo CLI (90 sec)
- Terminal : `npm install -g @anthropic-ai/claude-code`
- Vérifier : `claude --version`
- Première commande dans un projet réel : `cd ~/projects/mon-projet && claude`
- Authentification OAuth (montrer l'écran)
- Premier prompt : "Lis README.md et résume l'archi en 5 points"

### Démo VSCode (60 sec)
- Marketplace, install
- Raccourci `Cmd+Esc`
- Sidebar Claude Code apparaît
- Test du même prompt

### Pratique guidée (60 sec)
- Ferme tout
- Réouvre un projet à toi
- Lance `claude`
- Demande : "Liste les 5 fichiers les plus importants"

### Piège classique (30 sec)
- Lancer dans `~` ou un dossier énorme : à éviter
- Toujours `cd` dans le projet précis

### Outro (15 sec)
"Tu as Claude Code dans ton flow. Module 02 : les 8 raccourcis qui changent tout."

## Notes tournage
- Capture terminal + écran VSCode
- Pas de coupures rapides — montrer la fluidité
- Audio terminal "tap tap" léger en fond, optionnel
