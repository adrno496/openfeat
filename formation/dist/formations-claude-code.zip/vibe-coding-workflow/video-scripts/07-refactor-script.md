# Script vidéo — Module 07 : Refactor sécurisé

**Durée cible** : 6-7 min

## Plan

### Intro (15 sec)
"Refactorer 500 lignes d'un coup, c'est tentant et c'est dangereux. Pattern : dry-run + diff + tests."

### Démo en 3 étapes sur fichier réel (4 min)
- `git commit -m "wip: snapshot"` (montrer hash)
- Demander 3 améliorations avec impact + risque, sans toucher au code
- Choisir la moins risquée
- Demander le diff sans édition
- Lire le diff entièrement (pause caméra ou voix off "lis avec moi")
- Accepter
- Lancer les tests
- Si OK : commit. Sinon : rollback.

### Anti-patterns (60 sec)
- "Refactore tout ce dossier" → trop large
- "Améliore" → pas mesurable
- Ne pas commit avant → pas de rollback

### Sub-agent (30 sec teaser pour F1)
Si refactor sur 5+ fichiers : sub-agent. Couvert dans F1.

### Outro (15 sec)
"Module 08 : prompting qui marche dès la 2e tentative."
