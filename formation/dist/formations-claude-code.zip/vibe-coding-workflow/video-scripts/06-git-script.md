# Script vidéo — Module 06 : Git workflows

**Durée cible** : 5 min

## Plan

### Intro (15 sec)
"Claude Code peut écrire tes commits, reviewer tes PR, t'aider sur les rebases. Mais pas tout en autonomie."

### Démo commit propre (90 sec)
- `git diff --staged | claude "Génère un commit message conventionnel"`
- Format type/scope/description
- Limite 72 char

### Démo review PR (60 sec)
- "Lis tous les fichiers modifiés vs main. Bugs, sécu, dupli, incohérences."
- Montrer un vrai retour : leak de secret repéré, par exemple

### Sécurité Git autonome (90 sec) — bullet rouge
À l'écran liste :
- OK : status, diff, log, add fichier, commit
- NON : push --force, reset --hard, branch -D, checkout ., rebase

### Démo rebase guidé (45 sec)
"Donne-moi la commande, je l'exécuterai."

### Outro (15 sec)
"Module 07 : refactor sécurisé."
