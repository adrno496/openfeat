# Script vidéo — Module 04 : Multi-projets

**Durée cible** : 4-5 min

## Plan

### Intro (15 sec)
"Tu as plusieurs projets. Sans méthode, Claude Code mélange tes conventions. Solution : un `CLAUDE.md` par projet."

### Démo CLAUDE.md minimum (90 sec)
- Ouvrir un projet réel
- Créer `CLAUDE.md` à 4 sections (Stack, Conventions, Trucs à ne pas faire, Commandes)
- Limite 50 lignes
- Lancer `claude`, demander "Décris-moi ce projet en 3 lignes"

### Switch entre projets (60 sec)
- Fermer la session
- `cd` dans projet B
- `claude` → conventions B chargées automatiquement
- Comparer une suggestion A vs B (montrer la différence)

### Sessions courtes vs persistantes (45 sec)
- Sessions courtes par défaut (multi-projets)
- Persistantes uniquement si même projet toute la journée

### Piège classique (20 sec)
"Mettre 500 lignes dans `CLAUDE.md`. Coupe."

### Outro (15 sec)
"Module 05 : debug assisté qui marche vraiment."
