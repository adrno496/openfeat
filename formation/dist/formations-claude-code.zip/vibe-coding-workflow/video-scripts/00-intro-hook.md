# Script vidéo — Intro hook (≤ 90 sec)

**Format** : caméra face + capture d'écran courte
**Objectif** : convertir un visiteur curieux en inscrit en 90 secondes

---

## Plan détaillé (timing serré)

### 0:00 — 0:08 — Hook
"Tu utilises Claude Code depuis quelques semaines. Et tu te demandes pourquoi tu n'es pas plus rapide qu'avant."

### 0:08 — 0:25 — Problème
"Le problème, ce n'est pas l'outil. C'est que personne ne t'a montré le workflow. Tu cliques au feeling, tu prompts au feeling, et tu perds 30 minutes par jour à cause de petites frictions."

### 0:25 — 0:50 — Promesse
"Cette formation, c'est 9 modules courts. Chacun couvre une habitude qui s'installe en 1 jour. Au bout d'une semaine, tu doubles ta productivité dev. Pas en théorie — en pratique, sur tes vrais projets, avec ton vrai code."

### 0:50 — 1:15 — Preuve / différenciation
"Pas de blabla. Pas de hype. Du concret : `CLAUDE.md` minimum viable, raccourcis, gestion contexte, debug structuré, refactor sans casse, prompting qui marche dès le 2e essai."

### 1:15 — 1:30 — CTA
"Si tu es prêt à arrêter de bricoler avec Claude Code et à en faire un outil quotidien fiable, clique en bas. On commence ensemble."

---

## Notes de réalisation

- **Ton** : direct, pas survolté, regard caméra
- **Pas d'emoji ni de musique invasive**. Une seule ambiance sonore discrète.
- **Capture d'écran** : 1 seul B-roll de 5 sec environ pendant la "preuve" (montrer ton terminal en action)
- **Texte à l'écran** : à l'apparition des 9 modules — afficher leur nom

## Erreurs à éviter

- Promesse de "transformation radicale" — sonne creux
- Comparer Claude Code à un autre outil concurrent — distrait
- Promettre un revenu ou un job — interdit (légal + éthique)

## A/B test possible

- V1 : focus "productivité dev" (script ci-dessus)
- V2 : focus "arrêter de bricoler"
- V3 : focus "9 habitudes en 1 semaine"

Tester sur Twitter/LinkedIn avec budget identique avant de choisir la version pour la landing page.
