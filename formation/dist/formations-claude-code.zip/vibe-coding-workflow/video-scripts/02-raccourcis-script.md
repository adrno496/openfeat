# Script vidéo — Module 02 : Raccourcis VSCode et terminal

**Durée cible** : 4-5 min

## Plan

### Intro (15 sec)
"8 raccourcis. Si tu les intègres cette semaine, tu gagnes 5 minutes par session."

### Démo de chacun (10-20 sec par raccourci)
1. `Cmd+Esc` — invoquer Claude Code
2. Sélection + invocation = contexte attaché
3. `Tab` accept / `Esc` reject
4. `Cmd+Z` après accept
5. `` Ctrl+` `` terminal intégré + session `claude` parallèle
6. `Cmd+P` switch fichiers
7. `F12` go to definition (avant de demander à Claude Code)
8. Compare deux fichiers

### Workflow type "5 minutes" (60 sec)
Refaire en live le scénario "fonction qui bug" :
- sélection fonction → invocation → prompt → accept → vérif diff Git

### Piège classique (20 sec)
"Cliquer Accept sans lire le diff. Toujours lire."

### Outro (15 sec)
"Module 03 : gérer le contexte sans saturer."

## Notes tournage
- Zoom serré sur les raccourcis quand on les exécute
- Annoter à l'écran le nom du raccourci à chaque démo
