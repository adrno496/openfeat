# Script vidéo — Module 03 : Gérer le contexte

**Durée cible** : 5-6 min

## Plan

### Intro (15 sec)
"Le contexte de Claude Code, c'est sa mémoire de session. Mal géré, il dégrade tes réponses sans que tu t'en rendes compte."

### Théorie courte (45 sec)
- Définition du contexte
- Limite de taille
- Ce qui se passe quand on s'approche : qualité dégrade, prix monte

### Trois leviers (90 sec)
- `/clear` : reset complet, destructif
- `/compact` : compresse en gardant l'essentiel
- Sessions courtes : la vraie bonne pratique

### Démo "long thread" qui part en vrille (90 sec)
- Montrer une session simulée à 4h, 8 tâches
- Claude Code propose un fix qui suppose contexte tâche 2
- Dégât silencieux

### Tableau "Quand utiliser quoi" (30 sec) à l'écran
- Nouvelle tâche → fermer-rouvrir
- Même tâche depuis 1h → /compact
- En vrille → /clear

### Outro (15 sec)
"Module 04 : on parle de jongler entre projets sans perdre tes conventions."
