# Script vidéo — Module 05 : Debug

**Durée cible** : 5-6 min

## Plan

### Intro (15 sec)
"90% des sessions Claude Code qui ne marchent pas sur un bug, c'est le même problème : info manquante."

### Les 5 points (60 sec)
À l'écran : Stack / Repro / Attendu / Observé / Hypothèse.
Lecture rapide de chaque.

### Démo bon vs mauvais prompt (2 min)
Côte à côte :
- Mauvais : "ça plante, fix"
- Bon : 5 points complets
Lancer les 2, montrer chronos des résolutions.

### Règle des 3 essais (60 sec)
Stop au 4e. Reformule depuis zéro. Si encore échec : c'est pour toi avec un debugger.

### Quand laisser chercher seul vs guider (45 sec)
- Erreur claire mais source inconnue → laisser
- Source connue → guider sur le fichier précis

### Outro (15 sec)
"Module 06 : Git workflows IA-augmentés sans risque."
