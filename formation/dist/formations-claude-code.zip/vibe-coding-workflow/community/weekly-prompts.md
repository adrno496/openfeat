# Weekly Prompts — Vibe Coding Workflow

12 prompts hebdomadaires à publier dans `#questions-modules` ou `#snippets-utiles` pour entretenir l'activité de la communauté.

Un prompt par semaine pendant 12 semaines (3 mois). Cycle ensuite, ou collecte de nouveaux prompts via la communauté.

---

## Semaine 1
**Sujet** : Partage ton CLAUDE.md
"Poste ton CLAUDE.md projet (anonymisé si besoin) dans #vos-claude-md. Indique : nombre de lignes, stack du projet, et la 'règle dont tu es le plus fier'. On commente, on suggère."

## Semaine 2
**Sujet** : Le pire prompt que tu aies écrit
"Partage un prompt vague ou trop long que tu as utilisé récemment. On le réécrit en groupe avec le squelette à 4 sections."

## Semaine 3
**Sujet** : Ton meilleur raccourci VSCode
"Quel raccourci VSCode (en lien avec Claude Code ou pas) t'a fait gagner le plus de temps cette semaine ?"

## Semaine 4
**Sujet** : 1 bug, 1 protocole 5 points
"Choisis un bug réel de la semaine. Rédige le prompt complet avec les 5 points. Poste-le. On juge la qualité de la rédaction (pas du bug)."

## Semaine 5
**Sujet** : Commit message hall of fame
"Le pire commit message Claude Code que tu as accepté ? Le meilleur ? Capture d'écran bienvenue."

## Semaine 6
**Sujet** : Refactor sécurisé
"Tu as fait un refactor cette semaine avec dry-run + diff + tests ? Raconte. Quelle option as-tu choisie sur les 3 propositions ?"

## Semaine 7
**Sujet** : Sessions courtes — preuve
"Tu as remarqué une différence qualité entre une session de 30 min et une session de 4h ? Donne un exemple."

## Semaine 8
**Sujet** : Mode patch vs réécriture
"Donne un exemple où demander un 'patch' (pas une réécriture) t'a sauvé d'une régression."

## Semaine 9
**Sujet** : Multi-projets dans la journée
"Combien de projets différents tu touches dans une journée ? Comment ton CLAUDE.md t'aide à switcher sans dérive ?"

## Semaine 10
**Sujet** : Git autonomie
"Une fois où Claude Code a proposé une commande Git destructive — tu l'as refusée, et c'était la bonne décision ?"

## Semaine 11
**Sujet** : 3 options avec impact + risque
"Tu as utilisé le pattern 'propose 3 options avec impact + risque' ? Lequel tu as choisi et pourquoi ?"

## Semaine 12
**Sujet** : Ton quotidien à T+3 mois
"Ça fait 3 mois que tu as fini la formation. Mesurable : combien de minutes économisées par jour ? Quelle habitude est restée ? Laquelle a disparu ?"

---

## Notes facilitation

- Publier le lundi matin pour activer la semaine
- Répondre toi-même à chaque prompt en exemple (sois le premier à poster)
- Mettre en avant les 2-3 meilleures réponses chaque vendredi dans `#annonces`
- Ne pas publier 2 prompts en parallèle (saturation)
- Si participation faible (< 5 réponses) : reformule, ou contacte 3 actifs en DM avec invitation directe
