# Onboarding message — Vibe Coding Workflow

Message DM automatique envoyé à chaque nouveau membre du Discord.

---

## Version DM (texte court)

```
Salut [PRENOM] et bienvenue dans la communauté Vibe Coding Workflow.

3 étapes pour bien démarrer :

1. Lis #règles (5 commandements, 30 sec de lecture)
2. Présente-toi dans #présente-toi (prénom, stack, objectif — 3 lignes)
3. Commence le module 00 ici → [LIEN_FORMATION]

Si tu es bloqué sur un module, viens dans #questions-modules. Pas de DM directs au créateur — l'entraide passe par les canaux publics, c'est mieux pour tous.

Tu as 1 semaine pour finir la formation à 1h/jour. À la fin, tu sauras pourquoi 80% des devs utilisent Claude Code à 20% du potentiel — et tu seras dans les 20% restants.

Bon code,
[SIGNATURE]
```

---

## Version "premier message dans #présente-toi" (template à coller comme exemple)

```
Salut tout le monde 👋

Prénom: Axel
Stack principale: Vanilla JS + Capacitor + Supabase
Pourquoi je suis là: shipper plus vite mes apps mobiles
Niveau Claude Code: 6 mois d'usage, je veux structurer mon workflow
Objectif post-formation: gagner 1h par jour de productivité

Hâte d'échanger.
```

---

## Notes

- Le message DM est court. Les apprenants oublient si trop long.
- Les liens directs (formation + module 00) augmentent la complétion de 30-50%.
- Pas de "bot intrusif" qui demande 5 questions interactives. Une fois suffit.
- Pas d'emoji excessif dans le DM. Un seul à l'ouverture max.
