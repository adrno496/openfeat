# Structure Discord — Vibe Coding Workflow

Structure de canaux pour la communauté de la formation. À adapter si tu utilises Slack ou autre.

---

## Catégorie : 👋 Bienvenue

- `#règles` (en lecture seule) — règles de la communauté, code de conduite
- `#présente-toi` — chaque nouvel arrivant écrit 3 lignes : prénom, stack, objectif
- `#annonces` (en lecture seule) — mises à jour formation, nouveaux contenus, événements

## Catégorie : 📚 Formation

- `#questions-modules` — toute question sur les 9 modules
- `#questions-exercices` — focus sur les 3 exercices
- `#feedback-formation` — retours, suggestions d'amélioration

## Catégorie : 💻 Pratique

- `#vos-claude-md` — partage ton `CLAUDE.md` minimum, demande des reviews
- `#snippets-utiles` — copier/coller de prompts qui ont bien marché
- `#bugs-en-cours` — pour appliquer le protocole 5 points en groupe
- `#refactor-stories` — succès et échecs de refactor avec Claude Code

## Catégorie : 🛠 Ressources

- `#liens-utiles` — articles, vidéos, outils complémentaires (curation lente)
- `#actu-claude-code` — releases, changelogs, news Anthropic
- `#mcp-skills-curiosité` — discussions sur les sujets avancés (renvoi vers F1/F3 quand pertinent)

## Catégorie : 💬 Off-topic

- `#café` — discussion générale dev, pas off-tech mais détendu
- `#productivité` — partage de workflows non-Claude (clavier, terminal, etc.)

## Catégorie : 🔧 Support

- `#support-technique` — bug d'accès, paiement, etc.
- `#support-direct` (privé) — ouverture de ticket avec créateur

---

## Règles de la communauté (à pinner dans `#règles`)

1. **Bienveillance**. Personne n'est jugé pour une question "bête". Tout le monde est passé par là.
2. **Pas de promo**. Tu peux mentionner ton projet en passant, mais pas de spam.
3. **Pas de DM spam** vers les autres membres ou le créateur.
4. **Pas de partage du contenu de la formation**. Tu peux partager TES `CLAUDE.md`, prompts, refactors. Pas les vidéos ou modules.
5. **Code en bloc** : utilise les balises Discord ` ``` ` pour le code.
6. **Une question par message**, pas un mur de texte.
7. **Cherche avant de demander**. Tape ta question dans la barre de recherche Discord d'abord.

---

## Modération

- 1 modérateur (toi au début) + 1-2 helpers volontaires si la communauté grandit
- Auto-modération : Wick ou Carl-bot pour les warns automatiques
- Pas de bot trop intrusif (pas de welcome interactif extravagant)

## Onboarding automatique

À l'inscription, message DM automatique :
1. Lien vers `#règles`
2. Lien vers `#présente-toi` avec template court
3. Lien vers le module 00 de la formation

(Le contenu détaillé du message d'onboarding est dans `community/onboarding-message.md`.)
