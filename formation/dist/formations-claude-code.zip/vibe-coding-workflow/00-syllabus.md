# Syllabus — Vibe Coding Workflow

Plan détaillé de la formation, module par module.

---

## Module 00 — Introduction
Niveau : 🟢
Durée : 10 min
Onboarding apprenant. Comment suivre la formation, attentes, communauté.

## Module 01 — Installation et premier flow
Niveau : 🟢
Durée : 25 min
Installer Claude Code (CLI + extension VSCode). Configurer son compte. Faire tourner sa première commande dans un projet existant.

## Module 02 — Raccourcis VSCode et terminal qui changent tout
Niveau : 🟢
Durée : 20 min
Les 8 raccourcis qui font la différence : invocation rapide, sélection contextuelle, copie de code généré, switch entre fichiers ouverts.

## Module 03 — Gérer le contexte sans saturer
Niveau : 🟡
Durée : 30 min
Pourquoi `/clear` n'est pas ton ami. Quand utiliser `/compact`. Comment Claude Code lit ton projet. Le piège des longs threads.

## Module 04 — Multi-projets sans se perdre
Niveau : 🟡
Durée : 25 min
Travailler sur plusieurs repos en parallèle. Sessions persistantes vs sessions courtes. Le `CLAUDE.md` minimum viable par projet.

## Module 05 — Debugging assisté qui marche vraiment
Niveau : 🟡
Durée : 35 min
Donner les bons inputs : stack trace, repro steps, hypothèses. Quand laisser Claude Code chercher tout seul vs quand le guider. La règle des 3 essais.

## Module 06 — Git workflows IA-augmentés
Niveau : 🟡
Durée : 30 min
Commits propres avec Claude Code. Rebases sans casse. Reviews de PR. La sécurité : ce que tu ne dois JAMAIS laisser Claude Code faire en autonomie sur Git.

## Module 07 — Refactor sécurisé à grande échelle
Niveau : 🟡
Durée : 35 min
Refactor un fichier de 500 lignes sans tout casser. Le pattern "dry-run + diff + tests". Quand préférer un sub-agent.

## Module 08 — Prompting qui marche dès la 2e tentative
Niveau : 🟡
Durée : 30 min
Le squelette de prompt qui fonctionne 9 fois sur 10. Pourquoi tes prompts trop longs te plombent. Itérer en mode "patch", pas en mode "réécriture totale".

## Module 09 — Conclusion et next steps
Niveau : 🟢
Durée : 10 min
Récap, plan de pratique sur 4 semaines, vers F1 si tu veux aller plus loin.

---

## Total

≈ 4h30 de contenu structuré (lecture + pratique). Pensé pour être consommé en une semaine à raison de 30–45 min par jour.
