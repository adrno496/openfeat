# Social Posts — Vibe Coding Workflow

10 posts X / LinkedIn / Threads. Pas de prix, pas de hype, focus pédagogique.

---

## Post 1 — X / Threads (court)

```
Tu utilises Claude Code depuis quelques semaines mais tu n'es pas plus rapide qu'avant ?

Le problème n'est pas l'outil. C'est le workflow.

J'ai écrit une formation 100% FR sur les 9 habitudes qui changent tout. ↓
[LIEN]
```

---

## Post 2 — LinkedIn (mi-long)

```
80% des devs qui utilisent Claude Code l'utilisent à 20% du potentiel.

Pourquoi ? Parce qu'on installe l'outil sans installer le workflow.

Les 9 habitudes qui font la différence :

1. Un CLAUDE.md minimum par projet (≤ 50 lignes)
2. Sessions courtes > /clear > /compact
3. Le squelette de prompt à 4 sections
4. Le protocole de debug à 5 points
5. Le pattern dry-run + diff + tests pour refactor
6. La liste des opérations Git interdites en autonomie
7. Les 8 raccourcis VSCode qui sauvent du temps
8. Le mode "patch" plutôt que "réécriture"
9. Demander 3 options avec impact + risque quand tu doutes

Vibe Coding Workflow couvre les 9 en 1 semaine.

[LIEN]
```

---

## Post 3 — X (snippet)

```
Reflexe à installer aujourd'hui :

git diff --staged | claude "Génère un commit message conventionnel"

Sortie en 30 sec : "feat(auth): add password reset flow"

Plus jamais de commit "wip" ou "fix stuff".
```

---

## Post 4 — LinkedIn (storytelling)

```
J'ai mis 3 mois à comprendre pourquoi Claude Code dérivait sur mes longues sessions.

Spoiler : ce n'était pas l'outil. C'était moi qui gardais la même session ouverte pour 8 tâches différentes.

Au bout de 4h, Claude Code me proposait un fix qui supposait le contexte d'une autre tâche. Catastrophe silencieuse.

La règle simple : 1 tâche = 1 session. Tu fermes en finissant. Tu rouvres pour la suivante.

Détails complets dans Vibe Coding Workflow, module 03.

[LIEN]
```

---

## Post 5 — Threads (carousel)

```
[Slide 1] Le squelette de prompt qui marche 9 fois sur 10

[Slide 2] Contexte: tel fichier fait X. On veut Y.

[Slide 3] Objectif: ajouter / modifier / extraire Z.

[Slide 4] Contraintes: pas toucher à A. Pas de nouvelle dépendance.

[Slide 5] Format: diff sur le seul fichier concerné.

[Slide 6] 4 sections. Chacune en 1-3 phrases. Total 4-12 lignes.

[Slide 7] Plus de prompts vagues. Plus de "réécrits tout par hasard".

[Slide 8] Vibe Coding Workflow → [LIEN]
```

---

## Post 6 — X (technique)

```
3 commandes Git que tu ne dois JAMAIS laisser Claude Code lancer en autonomie :

- git push --force
- git reset --hard
- git branch -D <branche>

Tu lis la commande, tu comprends, tu lances toi-même.

Une mauvaise auto-action et tu perds une journée de travail.
```

---

## Post 7 — LinkedIn (preuve)

```
Avant : 3 sessions Claude Code par jour, productivité variable, frustration sur les bugs récurrents.

Après une semaine d'application du workflow : 7-8 sessions par jour, gain de 1h30 par jour, zéro dérive de contexte.

Ce n'est pas magique. C'est juste 9 habitudes appliquées dans le bon ordre.

Vibe Coding Workflow → [LIEN]
```

---

## Post 8 — X (curiosity)

```
Ton CLAUDE.md projet fait combien de lignes ?

Plus de 100 → tu écris pour personne.
Moins de 30 → manque de contexte.
30 à 50 → bon.

Le format minimum viable :
- Stack (5 lignes)
- Conventions code (5 lignes)
- Trucs à ne pas faire (3-5 puces)
- Commandes utiles (3-8 lignes)
```

---

## Post 9 — LinkedIn (anti-hype)

```
Aucune des "techniques de prompting magiques" que je vois sur Twitter ne fonctionne en pratique.

Ce qui fonctionne :
- Donner les bonnes informations dans le bon ordre
- Structurer le prompt en 4 sections (contexte, objectif, contraintes, format)
- Itérer en mode "patch" plutôt qu'en mode "réécriture totale"
- Lire chaque diff avant accept

Tout le reste, c'est du bruit.

Vibe Coding Workflow couvre la base solide en 1 semaine. [LIEN]
```

---

## Post 10 — X (CTA direct)

```
Tu utilises Claude Code mais tu sais que tu en exploites 30%.

Vibe Coding Workflow : 9 modules, 1 semaine, le workflow qu'un dev expérimenté aurait construit après 3 mois.

100% FR. Pas de blabla.

[LIEN]
```

---

## Notes

- Espacer les posts dans le temps (pas 10 d'un coup)
- Variation de format (court / mi-long / carousel) pour tester ce qui performe
- Suivre les répliques en commentaires pour identifier les futurs apprenants
- Pas d'achat de likes/follows. Authentique > volumineux.
