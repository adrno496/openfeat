# Email Sequence — Vibe Coding Workflow

Séquence de 6 emails. Welcome → nurture → upsell soft. Ton direct, tutoiement.

**Aucun prix dans les emails. Lien CTA pointe vers la landing.**

---

## Email 1 — J0 (immédiat après inscription)

**Sujet** : Bienvenue. Ton accès est dans cet email.

**Corps** :

Salut [PRENOM],

Tu es inscrit. Ton accès à *Vibe Coding Workflow* est ici :
[LIEN_ACCES]

Mon conseil : commence aujourd'hui par le module 00 (10 min) et le module 01 (30 min). Tu seras opérationnel en moins d'une heure.

Tu rejoins aussi le Discord ici : [LIEN_DISCORD]

Si tu as une question, réponds à ce mail. Je lis tout.

Bon code,
[SIGNATURE]

---

## Email 2 — J+1

**Sujet** : Le piège qui tue 80% des sessions Claude Code

**Corps** :

Tu utilises Claude Code depuis combien de temps ? Si tu réponds "quelques semaines", il y a 80% de chances que tu sois tombé dans LE piège classique.

Le piège : garder la même session ouverte toute la journée pour 8 tâches différentes.

Au bout de 4h, Claude Code te propose un fix qui suppose le contexte de la tâche 2 — alors que tu travailles sur la tâche 6.

Le module 03 explique ça en détail (et donne le bon protocole). Si tu n'y es pas encore, c'est un bon moment.

[CTA : Accéder au module 03]

À demain,
[SIGNATURE]

---

## Email 3 — J+3

**Sujet** : 5 minutes pour un commit propre

**Corps** :

Petit reflexe à installer dès aujourd'hui :

```bash
git diff --staged | claude "Génère un commit message conventionnel"
```

Tu obtiens un message type `feat(auth): add password reset flow` en moins de 30 sec.

Le module 06 va plus loin : review de PR, opérations Git risquées, ce que tu ne dois JAMAIS laisser Claude Code faire en autonomie.

[CTA : Voir le module 06]

À toi.
[SIGNATURE]

---

## Email 4 — J+7

**Sujet** : Tu as fait l'exercice 03 ?

**Corps** :

Si tu as suivi la formation à un module par jour, tu devrais en être au module 07 — refactor sécurisé.

L'exercice associé est probablement le plus important de la formation : refactorer un fichier réel avec le pattern dry-run + diff + tests, puis rollback à la fin.

C'est en faisant le rollback que tu intègres vraiment que **tu n'es jamais coincé**.

Si tu ne l'as pas fait, fais-le aujourd'hui. C'est 45 min.

[CTA : Voir l'exercice 03]

[SIGNATURE]

---

## Email 5 — J+14 (post-complétion)

**Sujet** : Tu as fini la formation. Et maintenant ?

**Corps** :

Si tu as fini les 9 modules, voilà la suite logique :

**Plan de pratique 4 semaines** (rappel module 09)
- S1 : raccourcis + CLAUDE.md
- S2 : debug + Git
- S3 : refactor
- S4 : prompting

À la fin des 4 semaines, refais l'auto-évaluation. Si 5/6 cases cochées, tu maîtrises la base.

Si tu veux aller plus loin :
- **F1 (Mastery FR)** : la totale — sub-agents, skills, hooks, MCP, optimisation coûts
- **F2 (Solo Founder Stack)** : ship un SaaS production-ready en 30 jours

[CTA : Découvrir F1]

Continue à venir dans le Discord. Les apprenants qui restent actifs progressent 3x plus vite.

[SIGNATURE]

---

## Email 6 — J+21 (upsell soft F1)

**Sujet** : Quand passer à la version avancée

**Corps** :

Question rapide : à quel moment tu sens que tu as "épuisé" Vibe Coding Workflow ?

Pour la majorité, c'est quand tu commences à te dire :
- "J'aimerais créer un sub-agent custom pour ce workflow"
- "Comment je crée un skill réutilisable ?"
- "Comment j'intègre Claude Code à Notion / Slack / ma DB ?"

Si ces questions te trottent dans la tête, F1 est faite pour toi.

[CTA : Voir le programme F1]

Sinon, continue à pratiquer F6. Pas de pression.

[SIGNATURE]

---

## Notes implémentation

- Tester chaque email sur mobile (la majorité des lectures)
- Pas d'images lourdes, pas de tracking pixel agressif
- Désinscription en clair en bas
- Pas plus d'1 CTA par email (sinon dilution)
