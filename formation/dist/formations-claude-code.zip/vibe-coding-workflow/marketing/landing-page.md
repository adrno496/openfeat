# Landing Page — Vibe Coding Workflow

Copy complet. À adapter au format HTML/Tailwind. **Aucun prix dans ce fichier**.

---

## Section 1 — Hero

**Headline** :
Doubler ta productivité dev en 1 semaine avec Claude Code.

**Sous-headline** :
9 modules courts. Des habitudes simples qui s'installent en 1 jour chacune. Du concret, pas du blabla.

**CTA principal** : `Réserver ma place →`
**CTA secondaire** : `Voir le programme`

**Visuel** : screencast loop discret de Claude Code en VSCode (5 sec, sans son)

---

## Section 2 — Le problème

**Titre** : Tu utilises Claude Code, mais pas vraiment.

**Texte** :
Tu l'as installé il y a quelques semaines. Tu l'ouvres au feeling. Parfois ça marche, parfois ça hallucine. Tu prompts trop long. Tu acceptes des diffs sans les lire. Tes commits sont brouillons. Et au final, tu n'es pas plus rapide qu'avant.

C'est normal : personne ne t'a montré le workflow. Et la doc officielle est en anglais, exhaustive, pas adaptée à ton quotidien.

---

## Section 3 — La promesse

**Titre** : 9 modules. 1 semaine. Un workflow qui tient.

**Bullets bénéfice** :
- Tu invoques Claude Code sans hésiter sur le mode à utiliser
- Tu as un `CLAUDE.md` qui marche sur tous tes projets
- Tu ne dérives plus en milieu de session
- Tu débugges 2x plus vite avec un protocole clair
- Tes commits sont propres, conventionnels, en mode IA-assisté
- Tes refactors ne cassent plus rien

---

## Section 4 — Pour qui

**Titre** : Cette formation est faite pour toi si...

- Tu codes déjà (3 mois à 4 ans d'XP)
- Tu utilises Claude Code mais sans vraie méthode
- Tu travailles en solo ou petite équipe
- Tu veux un retour immédiat sur ta productivité

**Pas pour toi si** :
- Tu débutes complètement en code
- Tu es senior avec un workflow IA déjà mature → vise F1
- Tu construis un SaaS et veux la stack complète → vise F2

---

## Section 5 — Le programme

**Titre** : 9 modules courts, ~30 min chacun.

(Liste sobre, pas de tableau décoratif)

1. Installation et premier flow
2. Raccourcis VSCode et terminal qui changent tout
3. Gérer le contexte sans saturer
4. Multi-projets sans se perdre
5. Debugging assisté qui marche vraiment
6. Git workflows IA-augmentés
7. Refactor sécurisé à grande échelle
8. Prompting qui marche dès la 2e tentative
9. Conclusion et plan de pratique 4 semaines

---

## Section 6 — Ce que tu obtiens

- Vidéos courtes en français
- Cheatsheet imprimable
- Templates `CLAUDE.md` et `settings.json`
- 3 exercices avec solutions commentées
- Accès à la communauté Discord
- Mises à jour à vie de la formation

---

## Section 7 — Preuve sociale

[TÉMOIGNAGE 1 — apprenant beta-testeur, 3 phrases max, fonction + résultat concret]

[TÉMOIGNAGE 2 — différent profil de dev, idem]

[TÉMOIGNAGE 3 — focus gain de productivité mesuré]

---

## Section 8 — FAQ

**Je n'ai jamais utilisé Claude Code, c'est trop tôt ?**
Non. Le module 01 t'installe pas à pas.

**J'ai 6 mois d'usage, c'est trop simple ?**
Probablement. Vise F1 ou F3.

**Combien de temps pour finir ?**
~8h étalées sur une semaine.

**Faut-il un compte Claude Code Max ?**
Recommandé, pas obligatoire.

**Ça marche en Go / Python / Rust ?**
Oui. Les principes sont indépendants du langage.

**Accès à vie ?**
Oui. Mises à jour incluses.

**Y a-t-il un certificat ?**
Certificat de complétion interne, oui. Pas un diplôme reconnu.

**Politique de remboursement ?**
Droit de rétractation 14 jours selon CGV.

**Comment poser mes questions ?**
Discord communautaire + email support.

**Ça remplace mon expérience ?**
Non. Ça la démultiplie.

---

## Section 9 — CTA final

**Titre** : Prêt à arrêter de bricoler ?

**Texte** :
Une semaine de pratique sérieuse. Un workflow qui tient. Et plus jamais l'impression de perdre du temps avec ton outil principal.

**CTA** : `Accéder à la formation →`
**Mention sous CTA** : Paiement sécurisé. Accès immédiat. Communauté incluse.

---

## Notes copywriting

- Pas de mots magiques type "explosif", "incroyable", "secret"
- Pas d'urgence artificielle ("plus que 24h !") sauf si vraie deadline
- Témoignages réels uniquement — placeholders à remplacer après collecte
- Mobile-first : section Hero et Programme tiennent en 2 scrolls
- Bouton CTA : couleur contrastée, action verbe à l'infinitif
