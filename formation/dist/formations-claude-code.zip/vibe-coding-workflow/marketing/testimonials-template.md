# Testimonials Template — Vibe Coding Workflow

Structure pour collecter des témoignages réels et exploitables. **Ne jamais inventer un témoignage.**

---

## Email type à envoyer aux apprenants à J+30 post-complétion

**Sujet** : 30 secondes pour m'aider (et aider d'autres devs)

**Corps** :

Salut [PRENOM],

Tu as fini Vibe Coding Workflow il y a un mois. J'aimerais ton retour honnête.

Trois questions, 30 secondes pour répondre :

1. **Avant la formation** : qu'est-ce qui te bloquait le plus avec Claude Code ?
2. **Maintenant** : qu'est-ce qui a changé dans ton quotidien ? (donne un chiffre si tu peux : minutes économisées par jour, bugs résolus plus vite, etc.)
3. **À qui tu recommanderais** cette formation, en une phrase ?

Réponds simplement à ce mail. Si tu acceptes que j'utilise tes réponses (avec ton nom et ta photo si tu veux), confirme-le aussi.

Merci,
[SIGNATURE]

---

## Structure du témoignage exploitable

Un bon témoignage public a 4 éléments :

1. **Identité** : prénom + fonction + lien (Twitter/LinkedIn). Pas de "Jean D., dev." → trop générique pour être crédible.
2. **Avant** : douleur concrète, en 1 phrase
3. **Après** : résultat mesurable, en 1 phrase
4. **Recommandation** : à qui ça s'adresse

### Exemple de format

```
"Avant, je passais 30 min par jour à reformuler mes prompts qui ne donnaient
rien. Après la formation, je tape mes prompts en 30 secondes et j'obtiens
un bon résultat dès le 2e essai. La méthode du squelette à 4 sections a
changé mon usage de Claude Code."

— [PRENOM] [NOM], [FONCTION] chez [ENTREPRISE/PROJET]
[LIEN_PROFIL_PUBLIC]
```

---

## Critères pour publier un témoignage

- Personne réelle, profil vérifiable (LinkedIn, X, GitHub)
- Consentement écrit explicite (mail ou message archivé)
- Résultat **mesurable et plausible** (pas "j'ai 10x ma productivité")
- Diversité des profils dans la collection (junior/senior, freelance/salarié, langages variés)

---

## Ce que tu ne mets PAS comme témoignage

- "Super formation merci" → pas exploitable, trop pauvre
- Témoignage anonymes → ne convainc personne
- Témoignages exagérés → contre-productifs (plus c'est gros, moins c'est crédible)
- Témoignages reformulés / inventés → interdit (légal + éthique)

---

## Si tu n'as pas encore de témoignages

Place des placeholders dans ta landing page :
```
[TÉMOIGNAGE 1 — à collecter]
[TÉMOIGNAGE 2 — à collecter]
[TÉMOIGNAGE 3 — à collecter]
```

C'est mieux qu'inventer. Les visiteurs voient mieux que tu ne le penses.

---

## Échelle de progression

- **0 témoignage** : utilise tes propres résultats mesurés sur tes projets perso (chiffres réels, jamais inventés)
- **3-5 témoignages** : profile diversifiés, à mettre sur la landing
- **10+** : créer une page dédiée `/temoignages` avec plus de profondeur
- **30+** : tester un format vidéo (15-30 sec par apprenant)
