# MASTER-CLAUDE.md

Conventions communes à l'ensemble du dépôt formations. Ce fichier est le `CLAUDE.md` projet : Claude Code le charge automatiquement à la racine.

---

## Voix et ton

- Français direct, tutoiement, phrases courtes (≤ 4 lignes par paragraphe).
- Zéro filler. Pas de "Dans ce module passionnant...". On entre dans le sujet.
- Métaphores concrètes pour concepts abstraits.
- Sans bullshit, technique mais pédagogique.

### Voix par formation (à garder dans la tête en rédigeant)

- **F6 vibe-coding-workflow** — direct, motivant, focus productivité quotidienne. Comme un collègue qui te montre ses raccourcis pendant la pause café.
- **F1 claude-code-mastery-fr** — précis, exhaustif, référence. Comme un manuel de mécanique : tout est listé, tout est sourcé.
- **F2 solo-founder-stack** — pragmatique, ROI-driven, anecdotes terrain. Comme un journal de ship : voilà ce que j'ai fait, voilà le résultat.
- **F3 skills-mcp-builder-pro** — pointu, sans tenir la main. Comme une doc d'architecture : tu sais déjà coder, on parle d'outillage.
- **F5 ai-agency-toolkit** — opérationnel, business-first. Comme un guide de prod : ce qui compte c'est le delivery client.
- **F4 claude-code-quant-macro** — sec, quantitatif, sourcé. Comme une note de recherche : chaque affirmation est testable.

---

## Conventions pédagogiques

### Structure de module (modules/01-XX.md)
1. Niveau (🟢 débutant / 🟡 intermédiaire / 🔴 avancé) en H1 sous le titre
2. Durée estimée (lecture + pratique)
3. Prérequis
4. Théorie courte (≤ 30% du module)
5. Démo avec code réel
6. Exercice pratique
7. Check de validation ("tu dois savoir / pouvoir...")

### Aucun emoji dans le pédagogique
- Modules, exercices, solutions : zéro emoji.
- README, marketing, community, INDEX : emojis OK avec parcimonie.

### Difficulté et durée — toujours en haut de module
Format : `**Niveau** : 🟡 intermédiaire — **Durée** : 35 min lecture + 25 min pratique`

---

## Conventions code

### JavaScript / TypeScript
- Indentation 2 espaces
- Quotes simples (`'foo'`)
- Pas de point-virgule en fin de ligne
- `const` par défaut, `let` quand mutation, jamais `var`
- Pas de `any` en TypeScript sans commentaire d'exception

### Python
- Indentation 4 espaces
- f-strings, pas de `.format()`
- Type hints quand utile

### Shell
- Commandes testées sur macOS Apple Silicon
- Préférer `zsh` quand un détail diffère, sinon POSIX

### Supabase (sécurité — RAPPEL CRITIQUE)
- Toujours sélectionner les colonnes explicitement, **jamais** `select('*')`
- `is_premium` (et tout flag de droits) **jamais muté côté client** — seulement via RPC ou webhook
- RLS activé par défaut sur toutes les tables
- Mentionner ces règles à chaque exemple Supabase

### MCP
- Snippets stdio **et** HTTP fonctionnels selon contexte
- Préciser le transport choisi et pourquoi

---

## Conventions marketing

- **Aucun prix** dans les fichiers. Placeholder : `[PRIX]`
- **Aucune fausse preuve sociale**. Placeholder : `[TÉMOIGNAGE 1]`, `[METRIQUE CLIENT X]`
- Headlines testables : framework PAS (Problem/Agitate/Solution) ou 4U (Useful/Urgent/Unique/Ultra-specific)
- Bullets orientés **bénéfice**, pas feature
- CTA neutres : "Réserver ma place", "Accéder à la formation", "Demander la démo"
- Pas d'urgence artificielle mensongère
- Mobile-first dans la structure visuelle décrite
- FAQ : 8–10 vraies objections par landing page

---

## Conventions templates

- Tous les templates immédiatement réutilisables (copy-paste → ça marche)
- Commentaires inline expliquant chaque section configurable
- Versionner si pertinent (`v1`, `v2`)
- UTF-8 strict

---

## Interdictions strictes

- Aucun prix de vente
- Aucune fausse preuve sociale, faux témoignage, fausse stat
- Aucune promesse de revenu garanti
- Aucun copier-coller de contenu entre formations
- Pas de markdown décoratif (tableaux pour faire joli, emojis dans le pédagogique)
- Pas de `select('*')` dans aucun snippet Supabase
- Pas de mutation de flags de droits côté client

---

## Stack récurrente (utilisée comme fil rouge dans les exemples)

Stack technique qui sert de référence dans F2 et F5 : Vanilla JS, Capacitor, Supabase, Vercel, Lemonsqueezy (paiements one-shot/abos web), RevenueCat (abos mobile).

Aucun produit ou personne réelle ne doit être cité comme preuve sociale dans le contenu de la formation. Pour les témoignages, utilise toujours des placeholders `[TÉMOIGNAGE X]` à remplir après collecte effective.

---

## Quand Claude Code modifie ce dépôt

- Respecter strictement la voix de la formation modifiée (cf. section "Voix par formation")
- Ne jamais introduire de prix, ne jamais inventer de témoignage
- Pour tout exemple Supabase : colonnes explicites + rappel sécurité si pertinent
- Tester mentalement chaque snippet avant de l'écrire (un snippet qui ne tourne pas est pire que pas de snippet)
- Si bloqué sur une formation : marquer `# TODO — à compléter manuellement` plutôt que générer du filler
