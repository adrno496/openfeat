# Social Posts — Claude Code Mastery FR

10 posts. Ton précis, technique. Pas de hype.

---

## Post 1 — X

```
La doc Claude Code est en anglais.
Et organisée par feature, pas par usage.

J'ai écrit la référence francophone : 12 modules
approfondis du CLAUDE.md projet à la création
d'un MCP server custom.

[LIEN]
```

---

## Post 2 — LinkedIn

```
80% des devs qui utilisent Claude Code n'ont jamais
créé de skill, ni configuré un sub-agent custom, ni
écrit un MCP server.

Ce n'est pas dramatique — c'est juste 80% du potentiel
non exploité.

Mastery FR couvre les 12 surfaces avancées de Claude
Code :
- CLAUDE.md projet et contexte
- Sub-agents (isolation + parallélisation)
- Slash commands custom
- Skills auto-déclenchés
- Hooks (intercepter, bloquer, logger)
- Settings et permissions
- MCP Python + TypeScript (stdio + HTTP)
- Optimisation des coûts
- Sécurité avancée

12 modules. Code testé. Templates production-ready.

[LIEN]
```

---

## Post 3 — X (technique)

```
Le frontmatter d'un skill Claude Code, c'est CRITIQUE.

Mauvais : "Outil pour CSP"
Bon : "Audite une politique CSP, détecte unsafe-inline,
unsafe-eval, wildcards. Trigger quand l'utilisateur
mentionne CSP, Content-Security-Policy, ou édite *.csp."

Plus tu donnes de signaux, plus le triggering est précis.
```

---

## Post 4 — LinkedIn

```
Les 3 mécanismes Claude Code qu'on confond tout le temps :

SLASH COMMAND
- Tu invoques explicitement (`/scope ma-tâche`)
- Vit dans ta session courante
- Idéal pour standardiser un workflow rapide

SKILL
- S'auto-déclenche selon le contexte
- Vit dans ta session courante
- Idéal pour automatiser une vérif récurrente (RLS, CSP, etc.)

SUB-AGENT
- Tu lances explicitement
- Vit dans son propre contexte (isolé)
- Idéal pour tâche longue ou risquée

Mauvais usage = du bruit. Bon usage = un outil démultiplié.

Module 06 de Mastery FR fait la cartographie complète.
[LIEN]
```

---

## Post 5 — X

```
3 commandes Git que tu DOIS deny dans ton settings.json
Claude Code projet :

- git push --force
- git reset --hard
- git branch -D

Le jour où Claude Code propose une de ces commandes
et tu acceptes par fatigue, tu perds une journée.

Configure les protections AVANT d'en avoir besoin.
```

---

## Post 6 — LinkedIn (MCP)

```
Tu utilises Stripe / Lemonsqueezy / GitHub / Notion /
Linear plusieurs fois par jour ?

Construis ton premier MCP server.

Avant : "Récupère les abonnements actifs Lemonsqueezy"
en prose, à chaque fois.

Après : `list_subscriptions(status="active")` en 1 token.

2-3h de boulot, super-pouvoir Claude Code à vie.

Mastery FR modules 09-10. [LIEN]
```

---

## Post 7 — X (cost)

```
Lancer Opus partout par "principe de qualité" :

→ tu paies 5x ce que tu paierais en Sonnet
→ pour 80% des tâches, Sonnet suffit
→ pour les tâches simples (recherche), Haiku suffit

Module 11 de Mastery FR explique comment optimiser
sans dégrader la qualité.
```

---

## Post 8 — LinkedIn

```
Sécurité Claude Code en équipe : la checklist minimale.

[ ] .claude/settings.json projet commité avec deny destructeurs
[ ] Hook PreToolUse qui log toutes les Bash
[ ] settings.local.json gitignoré pour les secrets
[ ] MCPs/skills/hooks tiers : code lu avant install
[ ] Compte API dédié (pas le compte prod)
[ ] RLS Supabase + flags premium muté server-side seulement

Si tu n'as pas tout coché : tu prends un risque réel.

Module 12 + exercice 05 de Mastery FR.
[LIEN]
```

---

## Post 9 — X

```
Le sub-agent custom le plus utile à créer :

`explorer` (Haiku, lecture seule, recherche dans codebase)

Tu l'utilises pour tout :
- "Où est défini X ?"
- "Quels fichiers utilisent Y ?"
- "Liste les usages de Z"

Coût ~5x moindre qu'Opus, qualité suffisante pour ces
tâches, et ton contexte principal reste propre.
```

---

## Post 10 — LinkedIn (CTA)

```
Tu utilises Claude Code mais tu sais que tu plafonnes.

Mastery FR couvre la totalité des 12 surfaces :
fondamentaux, sub-agents, skills, hooks, MCP, sécurité.

Référence francophone. Code testé. Mises à jour à vie.

[LIEN]
```
