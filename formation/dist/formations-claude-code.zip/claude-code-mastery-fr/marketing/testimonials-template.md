# Testimonials Template — Claude Code Mastery FR

Structure pour collecter des témoignages réels et exploitables.

---

## Email type — J+45 post-complétion

**Sujet** : Ton retour sur Mastery FR (3 questions, 2 minutes)

Salut [PRENOM], tu as fini Mastery FR il y a 1.5 mois. Pour aider d'autres devs à se décider, j'aimerais ton retour.

3 questions :

1. **Avant la formation** : qu'est-ce que tu maîtrisais le moins en Claude Code ? (sub-agents ? skills ? MCP ? sécurité ?)
2. **Maintenant** : qu'est-ce que tu fais que tu ne savais pas faire avant ? (donne 1 exemple concret avec un chiffre si possible)
3. **À qui tu recommanderais** Mastery FR, en une phrase ?

Réponds simplement à ce mail. Confirme aussi si je peux utiliser ta réponse publiquement avec ton nom et lien (LinkedIn ou X).

[SIGNATURE]

---

## Format de témoignage exploitable

Pour Mastery FR (cible plus technique que F6), un bon témoignage met en avant :
- une **compétence acquise concrète** (un MCP server qui tourne, une équipe formée, etc.)
- un **résultat mesurable** (X heures économisées, Y devs onboardés, Z fonctionnalités buildées)
- un **profil identifiable** (fonction + entreprise + lien public)

### Exemple type

```
"J'ai construit mon premier MCP server pour Lemonsqueezy
en suivant les modules 09-10. Maintenant, mes 3 devs
demandent à Claude Code "récupère les abonnements
actifs" et ça tourne en 1 seconde. On a gagné ~30 min
par dev par jour sur les analyses récurrentes."

— [PRENOM] [NOM], CTO chez [PROJET/SOCIETE]
[LIEN_PROFIL]
```

---

## Critères de publication

- Personne réelle, profil vérifiable
- Consentement écrit explicite
- Résultat mesurable
- Diversité : senior / freelance / lead / solo / équipe

## Ne PAS publier

- "Super formation merci" → trop pauvre
- Témoignages anonymes
- Témoignages exagérés ("10x productivité") → contre-productif
- Inventés / reformulés → interdit

## Si pas encore de témoignages

Placeholders sur la landing :
```
[TÉMOIGNAGE 1 — à collecter]
[TÉMOIGNAGE 2 — à collecter]
[TÉMOIGNAGE 3 — à collecter]
```

Mieux que d'inventer.
