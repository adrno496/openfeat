# Landing Page — Claude Code Mastery FR

Aucun prix dans ce fichier.

---

## Section 1 — Hero

**Headline** :
La référence francophone pour maîtriser Claude Code.

**Sous-headline** :
12 modules approfondis. Du `CLAUDE.md` projet bien fait à la création d'un MCP server custom. Le manuel de mécanique en français.

**CTA primaire** : `Accéder à la formation →`
**CTA secondaire** : `Voir le programme`

**Visuel** : screencast d'un MCP server répondant dans Claude Code.

---

## Section 2 — Le problème

Tu utilises Claude Code depuis plusieurs mois. Tu sens que tu n'exploites pas tout. Sub-agents, skills, MCP, hooks : tu en as entendu parler, mais la doc officielle est en anglais, exhaustive, organisée par feature, pas par usage.

Les tutos disparates sur YouTube ne couvrent jamais le sujet en profondeur.

---

## Section 3 — La promesse

12 modules approfondis, en français, organisés par maturité d'usage :
- Fondamentaux (`CLAUDE.md`, contexte, sub-agents) — modules 01-04
- Outillage (slash commands, skills, hooks) — modules 05-07
- Configuration et sécurité (settings, permissions) — module 08
- MCP servers (Python + TypeScript, stdio + HTTP) — modules 09-10
- Optimisation et sécurité avancée — modules 11-12

À la fin : tu remplaces la doc officielle dans ta tête.

---

## Section 4 — Pour qui

- Devs FR avec 1 à 10 ans d'XP qui veulent **maîtriser** Claude Code
- Freelances qui doivent l'expliquer à leurs clients
- Tech leads qui veulent former leur équipe sur un standard partagé
- Ceux qui ont fait F6 et veulent aller plus loin

**Pas pour toi** :
- Si tu n'as jamais lancé `claude` → fais F6 d'abord
- Si tu veux juste construire un SaaS → vise F2

---

## Section 5 — Le programme (12 modules)

01. Installation, configuration, comptes
02. `CLAUDE.md` projet : le contrat avec ton IA
03. Contexte, mémoire et sessions
04. Sub-agents : isolation et parallélisation
05. Slash commands custom
06. Skills : modules réutilisables
07. Hooks : intercepter les événements
08. Settings et permissions
09. MCP servers en Python
10. MCP servers en TypeScript + transport HTTP
11. Optimisation des coûts
12. Sécurité avancée
13. Conclusion et plan d'application

---

## Section 6 — Ce que tu obtiens

- 12 modules + introduction + conclusion (≈ 12 h de contenu)
- 5 exercices avec solutions commentées
- Templates : `CLAUDE.md`, `settings.json`, sub-agent, skill, MCP server (Python + TS)
- Cheatsheet imprimable dense
- Glossaire complet
- Communauté Discord avancée
- Mises à jour à vie

---

## Section 7 — Preuve sociale

[TÉMOIGNAGE 1 — dev senior qui a structuré son équipe avec ces standards]

[TÉMOIGNAGE 2 — freelance qui a construit son premier MCP server]

[TÉMOIGNAGE 3 — tech lead qui a formé son équipe avec F1]

---

## Section 8 — FAQ

**Quelle différence avec F6 ?** F6 = workflow quotidien (~2h). F1 = référence (~12h+).

**Faut-il connaître Python ET TypeScript ?** Non. Les modules MCP sont indépendants.

**Combien de temps pour finir ?** 2 à 4 semaines selon rythme.

**Y a-t-il un certificat ?** Certificat de complétion interne (non Qualiopi).

**Format ?** Vidéo + texte + code testé.

**Mises à jour ?** Incluses à vie.

**Communauté ?** Discord avancé réservé aux apprenants F1+.

**Ça marche pour mon équipe ?** Oui. Skills, slash commands, settings sont commités via Git.

**Garantie de remboursement ?** Cf. CGV.

**Compte API requis ?** Pro ou Max recommandé. API pay-as-you-go fonctionne mais surveille la facture sur les modules MCP.

---

## Section 9 — CTA final

**Titre** : Passe de 30 % à 90 % du potentiel Claude Code.

**Texte** : 12 modules. Code testé. Templates production-ready. Communauté pointue. Mises à jour à vie.

**CTA** : `Accéder à la formation →`
