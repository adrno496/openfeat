# Email Sequence — Claude Code Mastery FR

6 emails. Welcome → progression → upsell soft.

---

## Email 1 — J0

**Sujet** : Ton accès à Mastery FR

Salut [PRENOM], ton accès est ici : [LIEN]. Discord avancé : [LIEN_DISCORD].
Conseil : commence par les modules 01-04 (fondamentaux) avant de sauter aux MCPs.
[SIGNATURE]

---

## Email 2 — J+2

**Sujet** : Le piège du `CLAUDE.md` à 300 lignes

Tu as probablement un `CLAUDE.md` qui fait 200-300 lignes. C'est trop.
Plus c'est long, moins c'est lu attentivement.
Le module 02 explique le format minimum viable (< 80 lignes) et te montre l'avant/après.
[CTA Voir module 02]

---

## Email 3 — J+5

**Sujet** : Ton premier sub-agent

Tu peux créer un sub-agent en 5 minutes. Modèle Haiku, role lecture seule, focus recherche.
Module 04 + exercice 02 te font construire `explorer` et `code-reviewer`.
Ça change le rapport au refactor.
[CTA Voir module 04]

---

## Email 4 — J+10

**Sujet** : Skills vs slash commands vs sub-agents

Trois mécanismes, trois usages différents. Le module 06 fait la cartographie complète.
Si tu hésites entre les 3 quand tu construis quelque chose, c'est qu'il manque cette grille.
[CTA Voir module 06]

---

## Email 5 — J+18

**Sujet** : Construis ton premier MCP server

Module 09 (Python) ou 10 (TypeScript), au choix. Tu pars d'un service que tu utilises (Stripe, Lemonsqueezy, GitHub) et tu en fais un MCP server brançable.
2-3h de pratique → un super-pouvoir Claude Code permanent.
[CTA Voir modules 09-10]

---

## Email 6 — J+30

**Sujet** : Vers F2 / F3 / F5 / F4

Tu as fait Mastery FR. Tu as les bases solides. Maintenant, spécialisation selon profil :
- F2 si tu construis un SaaS
- F3 si tu veux monétiser des skills/MCP
- F5 si tu es freelance/agence
- F4 si tu fais finance/quant
[CTA selon profil]
