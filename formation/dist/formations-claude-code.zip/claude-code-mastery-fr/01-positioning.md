# Positioning — Claude Code Mastery FR

## USP

La référence francophone exhaustive sur Claude Code. Pas un cours d'introduction, pas un livre de recettes — **le manuel de mécanique**.

## Cible précise

- Devs FR avec 1 à 10 ans d'XP
- Freelances qui veulent expliquer Claude Code à leurs clients
- Tech leads qui veulent former leur équipe sur un standard partagé
- Devs qui ont fait F6 et veulent aller au fond du sujet

## Pas la cible

- Devs débutants absolus → vise F6
- Spécialistes finance/quant → vise F4 (mais F1 reste utile en base)
- Personnes qui veulent juste "construire un SaaS" → vise F2

## Promesse

À la fin de cette formation :
- tu connais TOUTES les surfaces de Claude Code (skills, MCP, hooks, sub-agents, slash commands, settings)
- tu peux construire un sub-agent custom et un MCP server simple
- tu sais sécuriser et auditer une utilisation en équipe
- tu maîtrises la facturation et l'optimisation des coûts
- tu peux remplacer la doc officielle dans ta tête

## Transformation mesurable

Avant : utilisation à 30-50 % du potentiel. Connaissance principalement empirique.
Après : utilisation à 90 %+. Capable d'expliquer à un dev junior en interne. Capable d'évaluer si un nouveau besoin justifie un MCP custom ou un skill.

## Anti-promesse

- On ne te promet pas une expertise sur tous les langages — on parle de l'outil, pas du métier
- On ne couvre pas la création d'agents en SDK Python/TS purs (c'est une autre bête)
- On ne fait pas de comparatif avec Cursor/Copilot/Codex — ce n'est pas le sujet

## Format

Vidéos + texte + code testé. Tu choisis la modalité qui te convient.
