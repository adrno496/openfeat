# Exercice 01 — Audit complet de tes `CLAUDE.md`

Niveau : 🟡
Durée : 1h

## Énoncé

Choisis 3 projets actifs. Pour chacun :
1. Lis le `CLAUDE.md` actuel
2. Liste chaque ligne et juge : actionnable / vague / banale / périmée
3. Réécris en gardant uniquement les actionnables
4. Ajoute la section "Trucs à ne pas faire" si elle manque
5. Vise < 80 lignes

Pour chaque section :
- **Stack** : 5 lignes max
- **Conventions code** : 5 lignes max
- **Règles métier** (si pertinent) : 5 lignes max
- **Trucs à ne pas faire** : 3-5 puces
- **Commandes utiles** : 3-8 commandes

## Critères de réussite

- 3 `CLAUDE.md` réécrits, chacun < 80 lignes
- Aucune ligne "banale" (pas de "écris du bon code")
- Section "Trucs à ne pas faire" présente
- Au moins 1 règle métier non-évidente par projet

## Auto-check

- [ ] Audit complet effectué pour les 3 projets
- [ ] Réécriture commitée
- [ ] Test : Claude Code décrit chaque projet correctement en 3 lignes
- [ ] Test : Claude Code respecte les "Trucs à ne pas faire" sur une vraie tâche
