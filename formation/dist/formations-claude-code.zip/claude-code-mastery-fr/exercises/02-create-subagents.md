# Exercice 02 — Crée 2 sub-agents perso

Niveau : 🟡
Durée : 1h

## Énoncé

Crée 2 sub-agents personnalisés dans `~/.claude/agents/` :

### Sub-agent 1 — `explorer`
- Lecture seule (`tools: Read, Grep, Glob, Bash`)
- Modèle : Sonnet ou Haiku
- Rôle : recherche dans une codebase, retourne chemins + extraits, ne modifie jamais

### Sub-agent 2 — `code-reviewer`
- Lecture seule
- Modèle : Sonnet
- Rôle : review d'une branche par rapport à main, signale bugs/sécu/dupli

Soigne le `description` pour qu'il décrive bien le rôle (utile pour le triggering automatique).

Teste chacun sur un cas réel.

## Critères de réussite

- 2 fichiers `.md` créés dans `~/.claude/agents/`
- `tools` restreint correctement (lecture seule)
- `model` choisi explicitement
- Les 2 sub-agents tournent sans erreur sur 1 cas chacun

## Auto-check

- [ ] `~/.claude/agents/explorer.md` créé
- [ ] `~/.claude/agents/code-reviewer.md` créé
- [ ] Test `explorer` sur "où est défini le composant X" — retour propre
- [ ] Test `code-reviewer` sur une vraie branche — rapport structuré
