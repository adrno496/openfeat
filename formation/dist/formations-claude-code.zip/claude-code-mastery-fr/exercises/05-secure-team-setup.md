# Exercice 05 — Setup sécurité standard équipe

Niveau : 🔴
Durée : 1h

## Énoncé

Sur 1 projet (que tu partages réellement avec une équipe ou que tu simules), mets en place le standard de sécurité Claude Code :

1. `.claude/settings.json` projet (commité) avec :
   - `model` choisi
   - `allow` pour le top 10 des commandes utiles
   - `deny` pour push --force, reset --hard, branch -D, rm -rf
   - hook `PreToolUse` qui log Bash
   - hook `PostToolUse` qui auto-format (Edit|Write)

2. `.claude/settings.local.json.template` (commité, à copier en local) qui montre comment ajouter les variables d'env / overrides perso

3. README au niveau du repo qui explique le setup en 10 lignes

## Critères de réussite

- `.claude/settings.json` engagé dans Git
- `.claude/settings.local.json.template` engagé
- `.gitignore` contient `.claude/settings.local.json`
- Tests de validation :
  - tentative de `git push --force` bloquée
  - log audit se remplit après usage
  - secrets pas commités

## Auto-check

- [ ] `.claude/settings.json` commité
- [ ] `.claude/settings.local.json.template` commité
- [ ] `.claude/settings.local.json` ignoré
- [ ] Test deny destructeurs : ça bloque
- [ ] Test hook log : le fichier de log se remplit
- [ ] README explique l'onboarding équipe en < 15 lignes
