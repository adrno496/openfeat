# Exercice 03 — Construis un skill projet

Niveau : 🔴
Durée : 1h30

## Énoncé

Construis un skill métier pour un de tes projets actifs. Exemples :
- Auditeur RLS Supabase
- Générateur de migration depuis un schéma
- Vérificateur de naming convention
- Auditeur CSP / sécurité headers

Structure :
```
.claude/skills/<nom>/
├── SKILL.md
└── (optionnel) reference/, examples/
```

Le `description` doit être précis et lister les triggers (mots-clés, patterns de fichier).

Teste sur 5 prompts différents : combien de fois il s'auto-déclenche correctement ?

## Critères de réussite

- `SKILL.md` < 100 lignes
- `description` mentionne au moins 3 mots-clés de triggering
- Au moins 3 prompts sur 5 le déclenchent automatiquement
- Le skill produit un output utile (pas juste "OK je vois")

## Auto-check

- [ ] Skill créé et commité dans `.claude/skills/<nom>/`
- [ ] Test triggering : 3/5 ou plus
- [ ] Output exploitable
- [ ] Pas de modification de fichier (sauf si c'est le but explicite du skill)
