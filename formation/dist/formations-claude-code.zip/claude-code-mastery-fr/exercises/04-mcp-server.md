# Exercice 04 — Build un MCP server pour un service que tu utilises

Niveau : 🔴
Durée : 2h30

## Énoncé

Choisis un service que tu utilises au quotidien (Stripe, Lemonsqueezy, GitHub, Notion, Linear, Supabase). Construis un MCP server stdio :

- 2 tools de lecture (ex : `list_X`, `get_X`)
- 1 tool de mutation (ex : `create_X` ou `update_X`) avec validation stricte
- 1 resource exposant la doc/le schéma
- Optionnel : 1 prompt template

Choix Python ou TypeScript libre. Teste via MCP Inspector.

Branche-le dans 1 projet réel via `.claude/settings.local.json`.

## Critères de réussite

- Serveur tourne sans erreur en standalone
- MCP Inspector affiche correctement les 3 tools
- Validation d'entrée stricte (Pydantic en Python, Zod en TS)
- Pas de secret hardcodé (variables d'env uniquement)
- Branchement dans Claude Code fonctionnel

## Auto-check

- [ ] Code commité dans un repo dédié
- [ ] Serveur lance en local
- [ ] Inspector montre les 3 tools avec schémas corrects
- [ ] Test depuis Claude Code : invocation des 3 tools réussie
- [ ] Aucun secret en clair dans le code
