# Solution — Exercice 01 (Audit `CLAUDE.md`)

## Méthode d'audit ligne par ligne

Pour chaque ligne de ton `CLAUDE.md`, classe :
- **Actionnable** : change un comportement de Claude Code
- **Vague** : "écris du code propre" → vire
- **Banal** : "le projet est en JavaScript" → Claude Code voit le code, vire
- **Périmé** : ancienne convention plus utilisée → vire

## Exemple avant / après

### Avant (118 lignes)

```markdown
# Mon projet

Bienvenue sur le projet ! C'est un projet web avec une stack moderne.
Nous valorisons la qualité du code, la maintenabilité et la documentation.

## Histoire
Le projet a été commencé en 2023 par moi tout seul...
[20 lignes d'histoire]

## Technologies
- JavaScript (oui c'est en JS)
- HTML, CSS
- Une base de données
- Un serveur

## Règles
- Écris du bon code
- Sois pédagogique dans tes commentaires
- Pense aux utilisateurs
[15 lignes de banalités]

## Setup
Pour installer le projet:
1. git clone
2. npm install
3. npm run dev
[c'est dans le README]
```

### Après (52 lignes)

```markdown
# CLAUDE.md

## Stack
- Frontend : Vanilla JS (ES Modules natifs, pas de bundler)
- Backend : Supabase (Postgres + Auth + Edge Functions)
- Mobile : Capacitor 6
- Déploiement : Vercel + Play Store

## Conventions code
- 2 espaces, quotes simples, sans point-virgule
- ES Modules, pas de require()
- Pas de framework (React/Vue) sans validation
- Tests : Vitest pour units, Playwright pour e2e

## Règles métier
- is_premium muté uniquement via RPC `set_premium_status`
- Abonnements mobile via RevenueCat, web via Lemonsqueezy
- Tokens auth : durée 1h, refresh auto

## Trucs à ne pas faire
- Pas de select('*') Supabase, toujours colonnes explicites
- Ne pas remplacer fetch par axios
- Ne pas modifier /legacy/* sauf demande explicite
- Ne pas commit sans `npm test`

## Commandes utiles
- `npm run dev` — local sur :3000
- `npm run build` — build prod
- `npm run db:types` — régénère types TS depuis Supabase
- `npx supabase db reset` — reset DB locale
```

## Pourquoi c'est mieux

- 52 lignes au lieu de 118 → entièrement lu attentivement à chaque session
- Aucune ligne banale → chaque ligne change un comportement
- "Trucs à ne pas faire" présent → la section qui économise le plus de back-and-forth
- "Règles métier" capture ce qui n'est pas dans le code (les flux RevenueCat/Lemonsqueezy)
- Pas de duplication avec le README

## Test de validation après réécriture

```
> Décris-moi ce projet en 3 lignes.

[Claude Code répond précisément]

> J'ai oublié, on utilise quoi pour les abonnements mobile ?

[Réponse: RevenueCat]

> Comment muter is_premium ?

[Réponse: via la RPC set_premium_status, jamais côté client]
```

Si les réponses sont précises, ton `CLAUDE.md` est efficace.
