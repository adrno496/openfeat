# Solution — Exercice 04 (MCP server)

## Exemple complet : MCP server Lemonsqueezy en TypeScript

### Structure

```
mcp-lemonsqueezy/
├── package.json
├── tsconfig.json
└── src/
    └── server.ts
```

### `package.json`

```json
{
  "name": "mcp-lemonsqueezy",
  "version": "1.0.0",
  "type": "module",
  "scripts": {
    "build": "tsc",
    "start": "node dist/server.js"
  },
  "dependencies": {
    "@modelcontextprotocol/sdk": "^1.0.0",
    "zod": "^3.22.0"
  },
  "devDependencies": {
    "typescript": "^5.4.0",
    "@types/node": "^20.0.0"
  }
}
```

### `src/server.ts`

```ts
import { Server } from '@modelcontextprotocol/sdk/server/index.js'
import { StdioServerTransport } from '@modelcontextprotocol/sdk/server/stdio.js'
import { z } from 'zod'

const API_KEY = process.env.LEMONSQUEEZY_API_KEY
if (!API_KEY) {
  console.error('LEMONSQUEEZY_API_KEY missing')
  process.exit(1)
}

const STORE_ID = process.env.LEMONSQUEEZY_STORE_ID

const server = new Server(
  { name: 'lemonsqueezy-helper', version: '1.0.0' },
  { capabilities: { tools: {} } }
)

const ListSubsInput = z.object({
  status: z.enum(['active', 'cancelled', 'expired', 'all']).default('active'),
  limit: z.number().int().min(1).max(50).default(10)
})

const GetCustomerInput = z.object({
  customer_id: z.string()
})

server.setRequestHandler('tools/list', async () => ({
  tools: [
    {
      name: 'list_subscriptions',
      description: 'Liste les abonnements Lemonsqueezy filtrés par statut',
      inputSchema: {
        type: 'object',
        properties: {
          status: { type: 'string', enum: ['active', 'cancelled', 'expired', 'all'] },
          limit: { type: 'number', minimum: 1, maximum: 50 }
        }
      }
    },
    {
      name: 'get_customer',
      description: "Récupère les infos d'un client Lemonsqueezy par ID",
      inputSchema: {
        type: 'object',
        properties: { customer_id: { type: 'string' } },
        required: ['customer_id']
      }
    },
    {
      name: 'monthly_revenue',
      description: 'Calcule le MRR à partir des abonnements actifs',
      inputSchema: { type: 'object' }
    }
  ]
}))

server.setRequestHandler('tools/call', async (request) => {
  const { name, arguments: args } = request.params

  try {
    if (name === 'list_subscriptions') {
      const parsed = ListSubsInput.parse(args)
      const url = new URL('https://api.lemonsqueezy.com/v1/subscriptions')
      if (parsed.status !== 'all') url.searchParams.set('filter[status]', parsed.status)
      url.searchParams.set('page[size]', String(parsed.limit))
      if (STORE_ID) url.searchParams.set('filter[store_id]', STORE_ID)

      const res = await fetch(url.toString(), {
        headers: {
          'Authorization': `Bearer ${API_KEY}`,
          'Accept': 'application/vnd.api+json'
        }
      })
      if (!res.ok) throw new Error(`API error: ${res.status}`)
      const json = await res.json() as any
      const data = json.data.map((s: any) => ({
        id: s.id,
        email: s.attributes.user_email,
        status: s.attributes.status,
        product: s.attributes.product_name,
        renews_at: s.attributes.renews_at
      }))
      return { content: [{ type: 'text', text: JSON.stringify(data, null, 2) }] }
    }

    if (name === 'get_customer') {
      const parsed = GetCustomerInput.parse(args)
      const res = await fetch(`https://api.lemonsqueezy.com/v1/customers/${parsed.customer_id}`, {
        headers: {
          'Authorization': `Bearer ${API_KEY}`,
          'Accept': 'application/vnd.api+json'
        }
      })
      if (!res.ok) throw new Error(`API error: ${res.status}`)
      const json = await res.json() as any
      const c = json.data.attributes
      const summary = {
        email: c.email,
        name: c.name,
        status: c.status,
        total_revenue_cents: c.total_revenue_currency,
        mrr_cents: c.mrr,
        country: c.country
      }
      return { content: [{ type: 'text', text: JSON.stringify(summary, null, 2) }] }
    }

    if (name === 'monthly_revenue') {
      const url = new URL('https://api.lemonsqueezy.com/v1/subscriptions')
      url.searchParams.set('filter[status]', 'active')
      url.searchParams.set('page[size]', '100')
      if (STORE_ID) url.searchParams.set('filter[store_id]', STORE_ID)

      const res = await fetch(url.toString(), {
        headers: { 'Authorization': `Bearer ${API_KEY}`, 'Accept': 'application/vnd.api+json' }
      })
      if (!res.ok) throw new Error(`API error: ${res.status}`)
      const json = await res.json() as any
      const total = json.data.reduce((sum: number, s: any) => {
        const item = s.attributes.first_subscription_item
        return sum + (item?.price ?? 0)
      }, 0)
      return { content: [{ type: 'text', text: `MRR (cents): ${total}` }] }
    }

    throw new Error(`Unknown tool: ${name}`)
  } catch (err) {
    return {
      content: [{ type: 'text', text: `Error: ${(err as Error).message}` }],
      isError: true
    }
  }
})

const transport = new StdioServerTransport()
await server.connect(transport)
```

### `tsconfig.json`

```json
{
  "compilerOptions": {
    "target": "ES2022",
    "module": "ES2022",
    "moduleResolution": "node",
    "outDir": "./dist",
    "rootDir": "./src",
    "strict": true,
    "esModuleInterop": true,
    "skipLibCheck": true,
    "resolveJsonModule": true
  }
}
```

### Branchement Claude Code

`.claude/settings.local.json` (NE PAS COMMIT) :

```json
{
  "mcpServers": {
    "lemonsqueezy": {
      "command": "node",
      "args": ["/Users/toi/projects/mcp-lemonsqueezy/dist/server.js"],
      "env": {
        "LEMONSQUEEZY_API_KEY": "ls_...",
        "LEMONSQUEEZY_STORE_ID": "12345"
      }
    }
  }
}
```

### Tests

```bash
npm install
npm run build

# Standalone (ne fait rien sans stdin, c'est normal)
node dist/server.js

# Avec MCP Inspector
npx @modelcontextprotocol/inspector node dist/server.js
```

Inspector → liste les 3 tools → tester `monthly_revenue` → réponse JSON.

Côté Claude Code :
```
Combien d'abonnements actifs on a sur Lemonsqueezy ?
```
Claude Code invoque `list_subscriptions(status="active")` automatiquement.

## Bonnes pratiques appliquées

- Validation Zod sur tous les inputs
- Gestion d'erreurs explicite avec `isError: true`
- Pas de secret hardcodé
- Limit max sur `list_subscriptions` (50)
- Pas de wildcard / "select all" qui exposerait trop de données
- Sortie JSON structurée, parsable
