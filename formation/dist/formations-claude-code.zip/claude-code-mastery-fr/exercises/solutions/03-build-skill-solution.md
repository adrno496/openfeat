# Solution — Exercice 03 (Skill projet)

## Exemple : Skill `supabase-rls-checker`

Adapté à un projet Vanilla JS + Supabase.

```
.claude/skills/supabase-rls-checker/
├── SKILL.md
└── reference/
    └── rls-patterns.md
```

### `SKILL.md`

```markdown
---
name: supabase-rls-checker
description: Audite les politiques RLS d'une migration Supabase pour éviter les fuites de données et les escalades de privilège. Trigger quand tu vois `CREATE POLICY`, `ENABLE ROW LEVEL SECURITY`, un fichier dans `supabase/migrations/`, ou quand l'utilisateur demande "audit RLS", "vérifie les policies", "review migration Supabase".
---

# Supabase RLS Checker

Quand on te demande d'auditer une migration ou un fichier RLS, applique cette grille :

## 1. Activation RLS
- Toute nouvelle table publique doit avoir `ENABLE ROW LEVEL SECURITY`
- Si manquant : signale avec gravité **critique**

## 2. Policies présentes
- Au minimum : SELECT, INSERT, UPDATE, DELETE (selon les besoins métier)
- Une table sans aucune policy après RLS activé = inaccessible (bloquant)

## 3. Conditions des policies
- Aucune `USING (true)` sans condition supplémentaire (vulnérabilité critique)
- Aucune comparaison non sécurisée du type `auth.uid() = user_id` sans index sur `user_id`

## 4. Flags de droits
- Les colonnes `is_premium`, `role`, `is_admin`, `is_verified` ne doivent pas être updatable côté client
- Vérifier qu'aucune policy UPDATE n'autorise la modification de ces colonnes par l'utilisateur

## 5. Cohérence avec les patterns existants

Voir `reference/rls-patterns.md` pour les patterns standards du projet.

## Format de sortie

```
### Audit RLS - <fichier>

#### [Critique] <issue>
Lignes X-Y. Description courte. Suggestion de fix.

#### [Moyen] <issue>
...

Conclusion : OK pour merge / corrections nécessaires.
```
```

### `reference/rls-patterns.md`

```markdown
# Patterns RLS du projet

## Pattern : "user_owns_row"

Toute table avec `user_id` :

```sql
CREATE POLICY "user_owns_row_select" ON public.<table>
  FOR SELECT USING (auth.uid() = user_id);

CREATE POLICY "user_owns_row_modify" ON public.<table>
  FOR UPDATE USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);
```

## Pattern : "premium_only"

Pour les tables accessibles uniquement aux premium :

```sql
CREATE POLICY "premium_only_select" ON public.<table>
  FOR SELECT USING (
    EXISTS (
      SELECT 1 FROM public.profiles
      WHERE profiles.id = auth.uid()
      AND profiles.is_premium = true
    )
  );
```

Ne JAMAIS écrire :
```sql
CREATE POLICY "bad_premium" ON public.<table>
  FOR UPDATE USING (true);  -- bypass complet
```
```

## Test du triggering

5 prompts à tester :

1. "Lis le fichier `supabase/migrations/20250109_add_premium_features.sql` et dis-moi si la migration est sûre" → **devrait trigger** (mention de migrations Supabase)
2. "Audit RLS sur la nouvelle table `subscriptions`" → **devrait trigger** ("audit RLS")
3. "Comment écrire une bonne policy pour la table `posts` ?" → **peut trigger** (sujet RLS)
4. "Vérifie que `auth.uid()` est bien utilisé dans cette migration" → **devrait trigger** (contexte clair)
5. "Décris-moi ce projet" → **ne doit PAS trigger** (hors scope)

Si triggering OK sur 3-4 sur 5, le skill est bien calibré.

## Erreurs fréquentes

- **Description trop vague** : "Outil pour Supabase" → trigger trop large ou pas assez
- **Description trop spécifique** : "Audit RLS pour table profiles uniquement" → ne trigger jamais ailleurs
- **Pas de référence externe** : si tu mets tout dans le `SKILL.md`, il devient trop long. Externalise dans `reference/`
- **Pas d'exemples** : un skill sans exemples produit des outputs incohérents. Ajoute `examples/` si possible
