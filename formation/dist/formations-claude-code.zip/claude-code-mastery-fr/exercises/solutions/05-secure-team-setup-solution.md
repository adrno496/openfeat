# Solution — Exercice 05 (Setup sécurité équipe)

## `.claude/settings.json` (commité)

```json
{
  "model": "claude-opus-4-7",

  "permissions": {
    "allow": [
      "Bash(git status)",
      "Bash(git diff)",
      "Bash(git diff --staged)",
      "Bash(git log:*)",
      "Bash(git branch)",
      "Bash(npm test)",
      "Bash(npm run dev)",
      "Bash(npm run build)",
      "Bash(npm run lint)",
      "Bash(rg:*)",
      "Bash(fd:*)",
      "Read",
      "Edit",
      "Write"
    ],
    "deny": [
      "Bash(git push --force*)",
      "Bash(git push -f*)",
      "Bash(git reset --hard*)",
      "Bash(git branch -D*)",
      "Bash(rm -rf /*)",
      "Bash(rm -rf ~*)",
      "Bash(rm -rf node_modules*)"
    ]
  },

  "hooks": {
    "PreToolUse": [
      {
        "matcher": "Bash",
        "hooks": [
          {
            "type": "command",
            "command": "echo \"[$(date -u +%Y-%m-%dT%H:%M:%SZ)] [$CLAUDE_TOOL_NAME] $CLAUDE_TOOL_INPUT\" >> ~/.claude/logs/audit.log"
          }
        ]
      }
    ],
    "PostToolUse": [
      {
        "matcher": "Edit|Write",
        "hooks": [
          {
            "type": "command",
            "command": "prettier --write \"$CLAUDE_TOOL_FILE_PATH\" 2>/dev/null || true"
          }
        ]
      }
    ]
  }
}
```

## `.claude/settings.local.json.template` (commité)

```json
{
  "_comment": "Copie ce fichier en .claude/settings.local.json (gitignoré). Adapte selon ton dev.",

  "_model_override_example": {
    "model": "claude-sonnet-4-6"
  },

  "_mcp_example": {
    "mcpServers": {
      "lemonsqueezy": {
        "command": "node",
        "args": ["./mcp/lemonsqueezy/dist/server.js"],
        "env": {
          "LEMONSQUEEZY_API_KEY": "ls_REPLACE_ME"
        }
      }
    }
  },

  "_env_example": {
    "env": {
      "DEBUG": "false"
    }
  }
}
```

## `.gitignore` (ajouter)

```
.claude/settings.local.json
.claude/logs/
.env*
!.env.example
```

## `README-claude-code.md` (à la racine, ou section dans le README principal)

```markdown
# Setup Claude Code (équipe)

## Première installation

1. Vérifie que tu as Claude Code installé : `claude --version`
2. Copie le template local :
   ```bash
   cp .claude/settings.local.json.template .claude/settings.local.json
   ```
3. Remplace les `REPLACE_ME` par tes vrais secrets (récupérables dans 1Password / vault équipe)
4. Crée le dossier de logs :
   ```bash
   mkdir -p ~/.claude/logs
   ```
5. Lance `claude` dans le projet, vérifie qu'il démarre sans erreur

## Ce qui est partagé

- `.claude/settings.json` : permissions, hooks, modèle. Standard équipe.
- `.claude/skills/` : skills métier du projet
- `.claude/commands/` : slash commands partagées

## Ce qui est local

- `.claude/settings.local.json` : tes secrets, overrides perso
- `~/.claude/logs/audit.log` : ton log d'audit personnel

## En cas de problème

- Une commande Bash bloquée → c'est probablement un `deny` voulu, ne l'enlève pas du fichier équipe
- Un hook qui plante → vérifie que `prettier` est installé : `npm install`
- Demande dans `#dev-tooling` du Slack
```

## Tests de validation

### Test 1 — Deny destructeur

```
# Dans Claude Code
Lance: git push --force origin main
```

Doit refuser. Vérifie qu'aucun push n'a eu lieu.

### Test 2 — Audit log se remplit

```bash
tail -f ~/.claude/logs/audit.log
```

Lance Claude Code, fais quelques commandes Bash. Le log doit se remplir avec timestamp.

### Test 3 — Pas de secret leaké

```bash
# Vérifie qu'aucun secret ne s'est retrouvé dans settings.json (commité)
grep -i 'api_key\|secret\|token' .claude/settings.json
# Doit retourner vide ou seulement des _comment
```

### Test 4 — Hook prettier marche

Demande à Claude Code d'éditer un fichier JS mal formaté. Vérifie qu'il est auto-formatté après édition.

## Onboarding équipe en 10 minutes

Un nouveau dev qui clone le repo doit pouvoir :
1. Copier le template local (1 commande)
2. Récupérer les secrets dans 1Password (3 min)
3. Lancer Claude Code (instant)
4. Avoir les permissions, hooks, MCPs fonctionnels

Si ça prend plus, c'est que la doc README est trop pauvre.
