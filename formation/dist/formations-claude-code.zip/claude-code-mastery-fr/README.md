# 🎓 Claude Code Mastery FR

**La référence francophone complète sur Claude Code.**

Du `claude` install au sub-agent custom, en passant par les skills, MCP, hooks, slash commands, settings, optimisation des coûts et sécurité avancée.

---

## Pour qui

Devs francophones de niveau junior à senior qui veulent **maîtriser** Claude Code, pas juste l'utiliser.
Freelances qui doivent l'expliquer à leurs clients.
Équipes tech qui veulent former leur staff sur un standard partagé.

---

## Ce que tu obtiens

- 12 modules approfondis (≈ 8-12 h de contenu)
- Référence exhaustive : tout ce que Claude Code propose, expliqué en français
- Code et configurations testés
- Templates de `CLAUDE.md`, `settings.json`, sub-agents, skills
- Une cheatsheet imprimable
- 5 exercices de niveau croissant + solutions
- Accès communauté Discord avancée

---

## Structure

```
claude-code-mastery-fr/
├── 00-syllabus.md
├── 01-positioning.md
├── modules/                 # 13 fichiers (intro + 12 modules + conclusion)
├── exercises/               # 5 exercices + solutions
├── resources/               # cheatsheet, glossaire, faq, liens
├── templates/               # CLAUDE.md, settings.json, sub-agents, skills, hooks
├── video-scripts/           # scripts par module
├── marketing/
└── community/
```

---

## Comment utiliser cette formation

Cette formation est dense. Trois rythmes possibles :

- **Rythme intensif** (1 module/jour) → 2 semaines
- **Rythme normal** (3 modules/semaine) → 4 semaines
- **Rythme référence** (consultation au besoin) → tu reviens chercher l'info quand tu en as besoin

Les modules 01 à 04 sont fondamentaux. Les modules 05 à 12 peuvent être consommés en non-linéaire selon ton besoin.

---

## Prérequis

- Avoir déjà utilisé Claude Code en CLI ou VSCode
- Connaître les bases d'un langage (JS, Python, Go, Rust ou autre)
- Savoir lire/écrire un peu de YAML, JSON, Markdown
- Pour les modules 09 (MCP Python) et 10 (MCP TypeScript) : bases Python ou Node

Si tu n'as pas encore utilisé Claude Code, fais d'abord F6 (`vibe-coding-workflow/`).

---

## Mise à jour

Claude Code évolue régulièrement. Cette formation est mise à jour à chaque release majeure. Tu as accès aux mises à jour à vie.

Date de dernière mise à jour : voir `CHANGELOG.md` à la racine du dossier.
