# Syllabus — Claude Code Mastery FR

12 modules approfondis. Plan détaillé.

---

## Module 00 — Introduction
🟢 — 15 min — Pourquoi cette formation, comment la suivre, prérequis.

## Module 01 — Installation, configuration, comptes
🟢 — 45 min — CLI, VSCode, web. Comptes (API, Pro, Max). Migration multi-machines.

## Module 02 — `CLAUDE.md` projet : le contrat avec ton IA
🟡 — 60 min — Anatomie complète. Hiérarchie (global, projet, sous-dossier). Patterns avancés. Anti-patterns.

## Module 03 — Contexte, mémoire et sessions
🟡 — 60 min — Comment Claude Code charge le contexte. `/clear`, `/compact`, sessions persistantes. Les pièges de la longue conversation.

## Module 04 — Sub-agents : isolation et parallélisation
🟡 — 75 min — Anatomie d'un sub-agent. Quand l'utiliser. Communication parent/enfant. Parallélisation.

## Module 05 — Slash commands custom
🟡 — 50 min — Créer ses commandes `/ma-commande`. Arguments. Frontmatter. Exemples concrets.

## Module 06 — Skills : modules réutilisables
🔴 — 75 min — `SKILL.md`, frontmatter optimisé pour le triggering. Skills composables. Distribution.

## Module 07 — Hooks : intercepter les événements
🔴 — 60 min — `PreToolUse`, `PostToolUse`, `Stop`, `UserPromptSubmit`. Cas d'usage : pre-commit IA, validation, logs.

## Module 08 — Settings et permissions
🟡 — 45 min — `settings.json`, `permissions.allow/deny`, `.claude/settings.local.json`. Hiérarchie d'application.

## Module 09 — MCP servers en Python
🔴 — 90 min — Construire un MCP server stdio en Python. Architecture, tools, resources, prompts.

## Module 10 — MCP servers en TypeScript + transport HTTP
🔴 — 90 min — Version TS du module précédent. HTTP transport pour MCP partagé.

## Module 11 — Optimisation des coûts
🟡 — 50 min — Comprendre la facturation. Cache prompts. Choisir Opus vs Sonnet vs Haiku. Mesurer son ROI.

## Module 12 — Sécurité avancée
🔴 — 60 min — Permissions fines, secrets, audit. Modes de validation. Risques en équipe.

## Module 13 — Conclusion et plan d'application
🟢 — 15 min — Récap, plan 30 jours, ressources continues.

---

## Total

≈ 12 h de contenu structuré + ~6 h de pratique = ~18 h.

À consommer en 2 à 4 semaines selon rythme.
