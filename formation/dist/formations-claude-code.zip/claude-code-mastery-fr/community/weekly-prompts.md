# Weekly Prompts — Claude Code Mastery FR

12 prompts hebdomadaires pour entretenir l'activité de la communauté avancée.

---

## Semaine 1 — Audit `CLAUDE.md`
"Poste ton `CLAUDE.md` projet (anonymisé). Indique nb de lignes, stack, et la règle 'trucs à ne pas faire' la plus utile."

## Semaine 2 — Sub-agent perso
"Quel sub-agent perso utilises-tu le plus ? Description, model, tools. Pourquoi ce model ?"

## Semaine 3 — Skill avec triggering parfait
"Partage un skill dont le `description` te donne ≥ 80% de triggering correct. On commente le wording."

## Semaine 4 — Slash command la plus utile
"Quelle est ta slash command perso #1 ? Code complet en spoiler."

## Semaine 5 — Hook qui sauve
"Tu as un hook qui t'a déjà épargné une catastrophe ? Décris l'événement et le hook."

## Semaine 6 — Permissions équipe
"Comment ton `deny` est-il calibré dans tes projets équipe ? Trop strict ? Pas assez ?"

## Semaine 7 — Premier MCP server
"Si tu as construit ton premier MCP : quel service ? Combien de tools ? Combien de temps pour MVP ?"

## Semaine 8 — stdio vs HTTP
"Tu as un MCP en HTTP ? Si oui, quel auth ? Si non, pourquoi pas ?"

## Semaine 9 — Optimisation coûts
"Action concrète d'optimisation que tu as appliquée cette semaine. Effet mesurable ?"

## Semaine 10 — Sécurité
"Audit ton `~/.claude/logs/audit.log` : 3 commandes les plus fréquentes. Surprises ?"

## Semaine 11 — Sub-agents en parallèle
"As-tu lancé 3+ sub-agents en parallèle sur une vraie tâche ? Décris le scénario et le gain."

## Semaine 12 — Récap 30 jours
"Quelles habitudes Mastery FR sont restées dans ton quotidien après 30 jours ? Lesquelles ont disparu ?"

---

## Notes facilitation

- Publier le lundi matin
- Le créateur poste sa propre réponse en exemple
- Les 2 meilleures réponses mises en avant le vendredi
- Si participation faible : reformuler ou contacter 3 actifs
