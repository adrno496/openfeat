# Onboarding message — Claude Code Mastery FR

DM automatique à chaque arrivée Discord.

---

## Version DM

```
Salut [PRENOM] et bienvenue dans la communauté Mastery FR.

Tu rejoins une communauté technique : sub-agents, skills, MCP, hooks. Niveau attendu plus pointu que F6.

3 étapes :
1. Lis #règles
2. Présente-toi : prénom, stack, profil (solo/team), où tu en es dans la formation
3. Commence par les modules 01-04 si tu débutes la formation

Pour les questions :
- #questions-fondamentaux pour modules 01-04
- #questions-outillage pour 05-08
- #questions-mcp pour 09-10
- #questions-cost-security pour 11-12

Pour partager ton travail :
- #vos-skills, #vos-mcps, #vos-subagents

Pas de DM directs au créateur — l'entraide passe par les canaux publics, c'est mieux pour tous.

Bon code,
[SIGNATURE]
```

---

## Template "présente-toi" à coller en exemple

```
Prénom: Axel
Stack: Vanilla JS + Capacitor + Supabase
Profil: solo founder
Niveau Claude Code: 6 mois d'usage, fait F6
Module en cours: 04 (sub-agents)
Objectif Mastery FR: construire mon premier MCP custom pour Lemonsqueezy

Hâte d'échanger.
```
