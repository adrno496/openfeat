# Structure Discord — Claude Code Mastery FR

Communauté avancée. Réservée aux apprenants Mastery FR (et formations supérieures).

---

## 👋 Bienvenue
- `#règles`
- `#présente-toi`
- `#annonces`

## 📚 Formation
- `#questions-fondamentaux` (modules 01-04)
- `#questions-outillage` (modules 05-08 : slash, skills, hooks, settings)
- `#questions-mcp` (modules 09-10)
- `#questions-cost-security` (modules 11-12)
- `#feedback-formation`

## 🛠 Lab
- `#vos-skills` — partage tes skills, demande review
- `#vos-mcps` — partage tes MCP servers, échange entre builders
- `#vos-subagents` — partage tes sub-agents
- `#prompts-avancés` — patterns de prompting complexes
- `#hooks-config` — configurations partagées

## 🔬 Cas réels
- `#refactor-stories` — refactor à grande échelle
- `#review-de-code` — review de PR avec sub-agent
- `#audit-sécurité` — applications du module 12

## 🌐 Veille
- `#actu-claude-code` — releases, changelogs
- `#actu-mcp` — nouveaux MCP servers publics
- `#articles-tutos` — curation FR

## 💬 Off-topic
- `#café`
- `#productivité`
- `#stack-watch` — discussions sur d'autres outils complémentaires

## 🔧 Support
- `#support-technique`
- `#support-direct` (privé)

---

## Règles particulières

- Niveau attendu : tu sais lancer un MCP Inspector, lire du TypeScript, écrire du JSON valide.
- Pas de questions niveau F6 (sinon redirige vers Discord F6 si applicable).
- Code en blocs Discord ` ``` `.
- Pas de DM spam.
- Pas de partage du contenu de la formation.
- Bienveillance + concision.
