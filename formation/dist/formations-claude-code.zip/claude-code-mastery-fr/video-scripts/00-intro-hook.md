# Script vidéo — Intro hook (≤ 90 sec)

## Plan

### 0:00 — 0:15 — Hook
"Tu utilises Claude Code. Tu as fait F6 ou tu as appris en pratiquant. Et tu sens que tu n'exploites pas tout."

### 0:15 — 0:35 — Problème
"Skills, MCP servers, sub-agents, hooks, slash commands : tu en as entendu parler mais la doc est en anglais, exhaustive, et organisée par feature, pas par usage."

### 0:35 — 1:05 — Promesse
"Mastery FR couvre la totalité de la surface Claude Code en 12 modules approfondis. Du `CLAUDE.md` projet bien fait à la création d'un MCP server custom, en passant par la sécurité d'équipe et l'optimisation des coûts."

### 1:05 — 1:25 — Différenciation
"Pas un cours d'introduction. Pas un livre de recettes. Le manuel de mécanique. Code testé, exemples ancrés sur des projets réels."

### 1:25 — 1:30 — CTA
"Si tu veux passer de 30 % à 90 % du potentiel Claude Code : [LIEN]"

## Notes tournage

- Plan poitrine, regard caméra, ton calme et précis
- B-roll : screencast d'un MCP server qui répond dans Claude Code (5 sec)
- Pas de musique épique
