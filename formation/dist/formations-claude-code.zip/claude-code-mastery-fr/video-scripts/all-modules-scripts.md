# Scripts vidéo — Modules 01 à 13 (consolidé)

Note : pour ce template formation, les scripts des 13 modules sont consolidés dans un seul fichier pour faciliter le tournage. Au tournage effectif, chaque module a sa vidéo dédiée. Au format de production, splitter en 13 fichiers `01-*.md` à `13-*.md` séparés au moment du planning de prod.

---

## Module 01 — Installation, configuration, comptes (6-8 min)

- 0:00 Intro : trois formes (CLI, VSCode, web), trois comptes (API, Pro, Max)
- 0:30 Démo install CLI + premier `claude` dans projet
- 2:00 Démo install VSCode
- 3:00 Hiérarchie de configuration : `~/.claude/`, projet, sous-dossier
- 4:30 Multi-machines : dotfiles, ce qu'on synchronise et pas
- 5:30 Pratique guidée : créer son premier `~/.claude/CLAUDE.md` global
- 7:00 Piège : secrets dans `settings.json` commité — utiliser `.local.json`
- 7:30 Outro

---

## Module 02 — `CLAUDE.md` projet (8-10 min)

- 0:00 Intro : `CLAUDE.md` = contrat avec ton IA
- 0:30 Hiérarchie (global / projet / sous-dossier)
- 1:30 Sections recommandées (Stack, Conventions, Règles métier, Trucs à ne pas faire, Commandes)
- 4:00 Démo : avant/après sur un vrai `CLAUDE.md`
- 6:00 Patterns avancés (référencer fichier externe, monorepo)
- 7:30 Anti-patterns (trop long, trop vague, doc projet vs CLAUDE.md)
- 8:30 Pratique : audit d'un de tes `CLAUDE.md`
- 9:30 Outro

---

## Module 03 — Contexte, mémoire, sessions (7-9 min)

- 0:00 Intro : contexte = mémoire
- 0:30 Composition (system prompt, CLAUDE.md, tools, conversation)
- 1:30 Limites et auto-compaction
- 2:30 Trois leviers : `/clear`, `/compact`, sessions courtes
- 4:00 Démo "long thread qui dérive"
- 5:30 Quand utiliser quoi (tableau)
- 7:00 Pratique : workflow type matinée
- 8:00 Outro

---

## Module 04 — Sub-agents (10-12 min)

- 0:00 Intro : qu'est-ce qu'un sub-agent
- 1:00 Anatomie : frontmatter (name, description, model, tools)
- 2:30 Démo : créer `.claude/agents/explorer.md`
- 4:30 Cas d'usage : tâche longue, recherche large, review indépendante, parallélisation
- 6:30 Communication parent/enfant
- 7:30 Démo parallélisation : 3 sub-agents en parallèle
- 9:00 Limites : sub-agent ne voit pas le parent, consomme tokens, pas de chaînage
- 10:30 Outro

---

## Module 05 — Slash commands custom (6-8 min)

- 0:00 Intro : built-in vs custom
- 0:45 Anatomie : `.claude/commands/<nom>.md` avec frontmatter
- 1:30 Démo : `/commit`, `/review-pr`, `/scope`
- 4:00 Arguments avec `$ARGUMENTS`
- 5:00 Distribution : projet (commité) vs personnel
- 6:00 Quand préférer slash vs sub-agent (tableau)
- 7:00 Outro

---

## Module 06 — Skills (10-12 min)

- 0:00 Intro : skills = réutilisables, auto-déclenchés
- 1:00 Anatomie : `.claude/skills/<nom>/SKILL.md`
- 2:00 Le frontmatter `description` : LE champ critique pour le triggering
- 4:00 Démo : skill `commit-conventional`
- 6:00 Skills composables (références externes, examples/, reference/)
- 7:30 Distribution (projet / personnel / public)
- 9:00 Quand skill vs slash command vs sub-agent
- 10:30 Outro

---

## Module 07 — Hooks (8-10 min)

- 0:00 Intro : hooks = couche système
- 1:00 Événements : PreToolUse, PostToolUse, UserPromptSubmit, Stop, Notification
- 2:00 Configuration dans settings.json : matcher + command
- 3:30 Démos : pre-commit IA, audit log, refus destructeurs, auto-formatting
- 7:00 Hooks vs skills vs slash commands (tableau)
- 8:30 Limites : performance, échec silencieux, sécurité
- 9:30 Outro

---

## Module 08 — Settings et permissions (6-8 min)

- 0:00 Intro : trois niveaux (global / projet / local)
- 1:00 `allow` et `deny`, wildcards
- 2:30 Modes de validation (auto-accept, prompt, plan)
- 4:00 Hiérarchie d'application
- 5:00 Choix du modèle, env vars, MCP servers
- 6:30 Démo : settings projet équipe complet
- 7:30 Outro

---

## Module 09 — MCP Python (12-15 min)

- 0:00 Intro : MCP, transports (stdio/HTTP)
- 1:00 SDK Python, FastMCP
- 2:00 Démo : MCP minimal (`hello`)
- 4:00 Configuration côté Claude Code
- 5:00 Démo complète : MCP Supabase
- 8:00 Resources (lisibles via URI)
- 9:30 Prompts (templates)
- 11:00 Debugging avec MCP Inspector
- 12:30 Bonnes pratiques sécurité
- 14:00 Outro

---

## Module 10 — MCP TypeScript + HTTP (12-15 min)

- 0:00 Intro : TS vs Python, stdio vs HTTP
- 1:30 SDK TS, anatomie minimale
- 3:30 Démo : MCP Lemonsqueezy en TS
- 7:00 Validation Zod stricte
- 9:00 Transport HTTP : pourquoi, quand, comment
- 11:00 Sécurité HTTP (HTTPS, auth token, rate limit, audit)
- 13:00 Stdio vs HTTP (tableau de décision)
- 14:00 Outro

---

## Module 11 — Optimisation des coûts (6-8 min)

- 0:00 Intro : ce qui coûte (modèle, longueur session, tools)
- 1:30 Cache prompts (TTL 5 min, ne pas casser)
- 3:00 Choisir le bon modèle (Opus/Sonnet/Haiku)
- 4:00 7 leviers d'économie
- 6:00 Mesurer (`claude usage`)
- 7:00 API vs Pro vs Max
- 7:30 Outro

---

## Module 12 — Sécurité avancée (8-10 min)

- 0:00 Intro : 3 familles (confidentialité, intégrité, disponibilité)
- 1:30 Confidentialité : ce qui sort, secrets, .env
- 3:30 Intégrité : permissions, hooks de validation, mode plan
- 5:30 Audit : logs, review sessions
- 6:30 Risques équipe : settings standardisés, MCPs/skills/hooks tiers
- 8:00 Risques Supabase : service_key vs anon_key, RLS, is_premium
- 9:00 Checklist sécurité
- 9:30 Outro

---

## Module 13 — Conclusion (4-6 min)

- 0:00 Récap des 12 modules
- 1:30 Plan d'application 30 jours (S1 bases, S2 sub-agents/slash, S3 skills, S4 MCP)
- 3:00 Auto-évaluation finale
- 4:00 Vers F2/F3/F4/F5
- 5:00 Outro

---

## Notes générales tournage

- Plan poitrine quand explication, screencast quand démo
- Annoter à l'écran les noms de fichiers / commandes
- Pas de musique en fond pendant les démos
- Découper chaque vidéo avec une intro 5 sec + outro 10 sec uniformes
