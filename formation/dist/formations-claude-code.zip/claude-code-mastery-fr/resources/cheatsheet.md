# Cheatsheet — Claude Code Mastery FR

Référence dense. Garde-la à côté du clavier.

---

## Hiérarchie de configuration

```
~/.claude/CLAUDE.md                       # global perso
~/.claude/settings.json                   # global perso
<projet>/CLAUDE.md                        # projet, commité
<projet>/.claude/settings.json            # projet, commité (équipe)
<projet>/.claude/settings.local.json      # projet, NON commité (perso)
```

Les `deny` de niveau projet ne peuvent pas être levés en local.

## Slash commands built-in (les utiles)

```
/clear        Reset complet
/compact      Résumé + libère contexte
/exit         Fermer la session
/help         Aide
/usage        Consommation
```

## Slash commands custom

`<projet>/.claude/commands/<nom>.md` ou `~/.claude/commands/<nom>.md`

```markdown
---
name: scope
description: Décrit le scope avant d'attaquer
---

Tâche : $ARGUMENTS
Liste fichiers, risques, estimation effort. Pas de code.
```

## Sub-agents

`<projet>/.claude/agents/<nom>.md` ou `~/.claude/agents/<nom>.md`

```markdown
---
name: explorer
description: Recherche read-only dans la codebase
model: claude-haiku-4-5-20251001
tools: Read, Grep, Glob, Bash
---
[corps des instructions]
```

## Skills

`<projet>/.claude/skills/<nom>/SKILL.md` ou `~/.claude/skills/<nom>/`

```markdown
---
name: csp-auditor
description: [TRIGGER MOTS-CLÉS] Audit politique CSP. Trigger quand `Content-Security-Policy`, `csp.config`, fichiers *.csp.
---
[corps]
```

## Hooks (events)

```
PreToolUse, PostToolUse, UserPromptSubmit, Stop, Notification
```

```json
{
  "hooks": {
    "PreToolUse": [
      { "matcher": "Bash", "hooks": [{ "type": "command", "command": "..." }] }
    ]
  }
}
```

`exit 2` dans la commande = bloquer.

## Permissions

```json
{
  "permissions": {
    "allow": ["Bash(git status)", "Bash(rg:*)", "Read", "Edit", "Write"],
    "deny": ["Bash(git push --force*)", "Bash(git reset --hard*)", "Bash(rm -rf /*)"]
  }
}
```

`deny` est prioritaire. Wildcards avec `*`.

## MCP servers

```json
{
  "mcpServers": {
    "ma-db": {
      "command": "python",
      "args": ["./mcp-server.py"],
      "env": { "DB_URL": "..." }
    },
    "shared-service": {
      "url": "https://mcp.example.com/sse",
      "headers": { "Authorization": "Bearer ..." }
    }
  }
}
```

## Modèles

```
claude-opus-4-7              max capability
claude-sonnet-4-6            balance
claude-haiku-4-5-20251001    fast & cheap
```

## Optimisation coûts

- Sessions courtes (1 tâche = 1 session)
- `CLAUDE.md` < 100 lignes
- Sub-agent Haiku pour la recherche
- Lectures ciblées (lignes spécifiques)
- Skills mal calibrés → désactiver
- Mesure : `claude usage`

## Sécurité — checklist

- `deny` push --force, reset --hard, rm -rf
- Hook PreToolUse pour audit log
- Pas de secret dans `.claude/settings.json` (commité)
- Secrets uniquement dans `.claude/settings.local.json` (gitignoré)
- MCPs / skills / hooks tiers : lire le source avant install
- Compte API dédié à Claude Code (pas prod)
- RLS Supabase + flags de droits muté server-side seulement

## Quand utiliser quoi

```
Workflow rapide perso          -> Slash command
Auto-déclenché par contexte    -> Skill
Tâche isolée, longue/risquée   -> Sub-agent
Bloquer une action             -> Hook PreToolUse (exit 2)
Brancher un service externe    -> MCP server
Standardiser pour l'équipe     -> .claude/settings.json projet commité
```
