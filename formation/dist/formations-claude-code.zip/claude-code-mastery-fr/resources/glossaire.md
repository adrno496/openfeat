# Glossaire — Claude Code Mastery FR

Termes techniques utilisés. Inclut tous ceux de F6 + ceux propres aux modules avancés.

---

**Auto-compaction** — Mécanisme automatique de Claude Code pour réduire le contexte quand il s'approche de la limite. Préfère `/compact` manuel pour le contrôler.

**Cache prompts** — Optimisation Anthropic qui réutilise un input identique sans le refacturer si invoqué dans une fenêtre temporelle (5 min TTL). S'applique au `CLAUDE.md` et autres préambules stables.

**`CLAUDE.md`** — Fichier markdown lu automatiquement à chaque session pour donner le contexte projet.

**`/clear`** — Reset complet de session.

**`/compact`** — Résumé + libération de contexte sans perdre l'essentiel.

**Contexte (context window)** — Mémoire de la session courante. Tout est ré-envoyé à chaque tour.

**Description (frontmatter)** — Champ critique d'un skill ou sub-agent : guide le triggering automatique.

**Hooks** — Commandes shell exécutées à certains événements (`PreToolUse`, `PostToolUse`, etc.).

**MCP (Model Context Protocol)** — Protocole standard pour brancher des outils externes à Claude Code. Tools + Resources + Prompts.

**MCP Inspector** — Outil de debug pour tester un MCP server en standalone.

**Matcher (hook)** — Filtre par type d'outil dans la config du hook.

**Permissions (allow/deny)** — Whitelist / blacklist de commandes Claude Code peut lancer en autonomie.

**Plan mode** — Mode où Claude Code propose un plan avant d'agir, attend validation.

**Resource (MCP)** — Contenu lisible exposé par un MCP server, identifié par URI (ex `schema://users`).

**Skill** — Module réutilisable enseignant à Claude Code à exécuter une tâche, auto-déclenché via le `description`.

**Slash command** — Commande commençant par `/`. Built-in (`/clear`, `/compact`) ou custom.

**stdio (transport)** — Communication MCP via stdin/stdout (local).

**HTTP (transport)** — Communication MCP via HTTPS (distant, partageable).

**Sub-agent** — Sous-processus Claude Code avec contexte isolé. Définissable dans `.claude/agents/`.

**Tool (MCP)** — Fonction invocable exposée par un MCP server, équivalent d'API endpoint.

**Tools (sub-agent)** — Whitelist d'outils accessibles à un sub-agent (Read, Edit, Bash, etc.).

**Trigger** — Mécanisme par lequel un skill s'auto-déclenche en fonction du contexte (mots-clés du `description`).

**Wildcard (permissions)** — `*` dans une expression `Bash(rg:*)` autorise tous les arguments.

**Zod / Pydantic** — Bibliothèques de validation d'inputs (TS / Python). Utilisées dans les MCP servers pour la robustesse.
