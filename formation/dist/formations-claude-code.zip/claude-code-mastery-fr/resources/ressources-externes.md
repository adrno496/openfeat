# Ressources externes — Claude Code Mastery FR

---

## Documentation officielle

- Anthropic / Claude Code : `docs.anthropic.com`
- Claude Code GitHub : `github.com/anthropics/claude-code`
- Anthropic Cookbook : `github.com/anthropics/anthropic-cookbook`
- Spécification MCP : `modelcontextprotocol.io`

## SDKs et outils

- MCP Inspector : `npx @modelcontextprotocol/inspector`
- MCP server-filesystem : `@modelcontextprotocol/server-filesystem`
- Liste curatée de MCPs publics : référencée sur le site officiel MCP

## Lectures

- Articles d'Anthropic sur les agentic workflows et le tool use
- "Building Effective Agents" (Anthropic, blog)
- Spécification Conventional Commits : `conventionalcommits.org`

## Outils complémentaires

- `ripgrep` (`rg`) — grep ultra-rapide
- `fd` — find moderne
- `bat` — cat avec coloration
- `gh` — CLI GitHub officielle
- `lazygit` — TUI Git
- `prettier`, `eslint` — formatters/linters
- `zod` (TS) / `pydantic` (Python) — validation d'inputs

## Communautés

- Discord officiel Anthropic Developers
- Reddit r/ClaudeAI (lire avec esprit critique)
- Hacker News : recherche "Claude Code"

## Veille

- Compte X officiel d'Anthropic
- Comptes X de l'équipe Claude Code (Cat Wu, Boris Cherny, etc.)
- Newsletter "Latent Space"
- Blog d'Anthropic

## Pour aller plus loin que F1

- F2 — Solo Founder Stack (ship un SaaS)
- F3 — Skills MCP Builder Pro (skills + MCP avancés)
- F4 — Claude Code Quant Macro (finance)
- F5 — AI Agency Toolkit (freelance/agence)
