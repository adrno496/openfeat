# FAQ — Claude Code Mastery FR

---

### Cette formation est lourde, dans quel ordre la suivre ?

Modules 01-04 dans l'ordre (fondamentaux). Ensuite, libre. Si tu veux aller vite vers MCP : 05-06-09. Si tu veux la sécurité d'équipe : 07-08-12.

### Quelle est la différence avec F6 ?

F6 = workflow quotidien, format court (~2h). F1 = référence exhaustive (~12h+).

### Faut-il connaître Python ET TypeScript pour les modules MCP ?

Non. Les modules 09 (Python) et 10 (TS) sont indépendants. Choisis le langage qui te plaît.

### Les sub-agents sont indispensables ?

Pour 80 % des usages quotidiens, non. Ils deviennent indispensables quand tu fais du refactor à grande échelle ou de la review systématique.

### Les MCP custom valent vraiment le coup ?

Oui, dès que tu utilises un service externe au moins 3 fois par semaine et que tu écris à chaque fois "récupère les abonnements actifs de Lemonsqueezy" en prose. Un MCP transforme ça en `list_subscriptions(status="active")`.

### Est-ce que cette formation devient obsolète quand Anthropic sort une nouvelle feature ?

La structure (sub-agents, skills, hooks, MCP) est stable. Les détails évoluent. Les modules sont mis à jour à chaque release majeure.

### J'ai un doute sur la sécurité de mon setup Claude Code, que faire ?

Module 12 + exercice 05 + audit ton `~/.claude/logs/audit.log` régulièrement. Si tu n'as pas de log, c'est qu'il faut configurer le hook.

### Puis-je utiliser ces skills/MCPs en équipe ?

Oui, c'est même fait pour. `.claude/skills/`, `.claude/commands/`, `.claude/settings.json` sont commités et partagés via Git.

### Combien de temps pour finir ?

Intensif : 2 semaines. Normal : 4 semaines. Référence : tu reviens chercher l'info au besoin sur 6 mois.

### Y a-t-il un certificat ?

Certificat de complétion interne (non Qualiopi).

### Politique de remboursement ?

Cf. CGV + `LEGAL-NOTES.md`.

### Comment poser mes questions ?

Discord avancé (réservé aux apprenants F1+) + email support.

### Je n'ai pas accès à un compte Max, ça suffit avec API ?

Oui mais surveille ta facturation, surtout sur les modules MCP/skills (consommation accrue lors des tests).

### Et la conf MCP HTTP, c'est obligatoire ?

Non. Pour 90 % des usages, stdio suffit. HTTP devient pertinent quand tu partages un MCP server avec une équipe ou un service.
