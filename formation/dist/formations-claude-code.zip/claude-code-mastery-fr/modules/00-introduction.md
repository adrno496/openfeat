# Module 00 — Introduction

**Niveau** : 🟢 débutant — **Durée** : 15 min lecture

## Pourquoi cette formation existe

La doc officielle de Claude Code est :
- en anglais
- exhaustive (donc longue)
- organisée par feature, pas par usage

Cette formation est :
- en français
- sélective sur ce qui compte vraiment
- organisée par maturité d'usage (du fondamental à l'avancé)

## Pour qui

Devs avec un peu d'expérience Claude Code qui veulent **maîtriser** l'outil. Pas un cours d'intro.

Si tu n'as jamais lancé `claude`, fais d'abord F6.

## Comment suivre

3 rythmes possibles :
- **Intensif** : 1 module/jour pendant 2 semaines
- **Normal** : 3 modules/semaine pendant 4 semaines
- **Référence** : tu lis ce dont tu as besoin au fil de tes projets

Les modules 01–04 sont fondamentaux. Le reste peut se prendre en non-linéaire.

## Engagement minimum

1 h de pratique par module. Lire sans pratiquer ne marche pas pour MCP, skills, hooks. Ces sujets demandent de mettre les mains dans le code.

## Communauté

Le Discord de cette formation est plus pointu que celui de F6. Les questions tournent autour de "comment je structure mon MCP", pas "comment j'installe Claude Code". Si tu débutes, ne te sens pas obligé d'intervenir tout de suite — observe.

## Tech requise

- Claude Code installé (CLI ou VSCode)
- Compte Max ou API actif (les modules avancés consomment du token)
- Node 18+ et Python 3.10+ (pour les modules MCP)
- Un terminal qui te plaît
- Un repo Git de test (pour les exercices destructifs)

## Convention de code

Tous les exemples respectent les conventions définies dans le `MASTER-CLAUDE.md` à la racine du dépôt formations :
- JS : 2 espaces, quotes simples, sans point-virgule
- Python : 4 espaces, f-strings
- Supabase : colonnes explicites, `is_premium` jamais muté côté client

## Démarrage

Ouvre `modules/01-installation-config.md`.
