# Module 11 — Optimisation des coûts

**Niveau** : 🟡 intermédiaire — **Durée** : 35 min lecture + 15 min pratique

## Prérequis

Modules 01 à 10.

## Théorie

Claude Code consomme des tokens. Tu paies (en API ou en plan d'abonnement) pour :
- les **input tokens** (ce qui est envoyé au modèle : ton prompt + contexte + `CLAUDE.md`)
- les **output tokens** (ce que le modèle génère)

Les input tokens ré-augmentent à chaque tour : à chaque message, tout le contexte précédent est renvoyé en entrée.

## Comprendre la facture

Trois leviers principaux qui font monter la facture :
1. **Modèle utilisé** — Opus est ~5x plus cher qu'Haiku
2. **Longueur de session** — plus c'est long, plus chaque tour est cher
3. **Volume des tools calls** — chaque output de tool revient dans le contexte

## Cache prompts

Anthropic propose un **cache** sur les inputs : si tu envoies le même contenu plusieurs fois en peu de temps (5 min de TTL), il n'est pas refacturé au prix plein.

Ce qui est cacheable et utile :
- ton `CLAUDE.md` (rechargé à chaque session, parfait candidat)
- de gros fichiers de référence que tu lis souvent
- un long préambule système

Pour Claude Code, le cache est **automatique** sur les éléments cacheables. Tu n'as rien à faire pour en bénéficier — sauf à éviter de casser le cache.

### Casser le cache, c'est mal

Modifier ton `CLAUDE.md` à chaque session, ou lui ajouter un timestamp à la fin → cache invalidé, paiement plein. Évite.

## Choisir le bon modèle

| Tâche | Modèle conseillé |
|---|---|
| Conversation classique, refactor | Opus 4.7 |
| Génération de tests, code utilitaire | Sonnet 4.6 |
| Explorer/lister/grep/répondre vite | Haiku 4.5 |
| Sub-agent de recherche | Sonnet ou Haiku |
| Sub-agent de code review | Sonnet |

Tu peux mettre un modèle différent par sub-agent (cf. module 04). Très puissant pour économiser.

### Exemple
- Agent principal : Opus
- Sub-agent `explorer` : Haiku (recherche dans codebase, pas besoin de raisonner)
- Sub-agent `code-reviewer` : Sonnet (review, équilibre)

## Mesurer ta consommation

```bash
claude usage
# (commande à vérifier selon version)
```

Sortie type :
- Tokens consommés sur la période
- Coût estimé
- Répartition input/output
- Top sessions par coût

## Stratégies d'économie

### 1. Sessions courtes
Déjà couvert au module 03. Plus tu fermes-rouvres tôt, moins tu payes en input répétitif.

### 2. `CLAUDE.md` court
Chaque ligne du `CLAUDE.md` est rechargée à chaque session. 80 lignes vs 300 lignes = grosse différence sur 100 sessions/mois.

### 3. Skills déclenchés au bon moment
Un skill mal calibré qui se déclenche pour rien gonfle le contexte. Soigne le `description`.

### 4. Tools restreints
Si Claude Code peut utiliser 30 tools mais que la tâche en utilise 3, tout le schéma des 30 est dans son contexte. Restreindre les tools dans un sub-agent diminue le contexte.

### 5. Lectures de fichiers ciblées
Tu peux dire à Claude Code "Lis seulement les lignes 50-150 de ce fichier" plutôt que tout le fichier. Pour les très gros fichiers, c'est un facteur 10.

```
Lis src/services/heavy-file.js, lignes 200-280 seulement.
```

### 6. Refactor par chunks
Refactorer un fichier de 1000 lignes d'un coup → coûteux. Refactorer 200 lignes par 200 lignes → moins cher et plus sûr.

### 7. Eviter l'auto-déclenchement de skills inutiles
Si un skill se déclenche pour rien, son contenu (et celui des fichiers référencés) entre dans le contexte. Désactive les skills que tu n'utilises plus.

## Plans d'abonnement vs API

- **API pay-as-you-go** : tu paies exactement ce que tu consommes. Idéal pour usage variable.
- **Pro/Max** : forfait avec plafond (généreux mais réel). Idéal pour usage stable et intensif.

Comparer les deux : si tu consommes plus de X $ d'API par mois (variable selon tarifs en vigueur), Max devient plus rentable.

## Démo : audit d'une session coûteuse

Imagine une session de 4h avec :
- `CLAUDE.md` à 300 lignes
- 12 tâches différentes
- 50 lectures de fichiers
- Modèle Opus partout

Estimation : potentiellement 10-30x ce qu'aurait coûté la même chose en :
- 12 sessions courtes (1 par tâche)
- `CLAUDE.md` à 80 lignes
- Lectures ciblées (lignes spécifiques)
- Sub-agent Haiku pour les explorations

## Exercice

1. Mesure ta consommation actuelle (`claude usage` ou via dashboard Anthropic)
2. Identifie ta session la plus coûteuse de la semaine
3. Audit : qu'est-ce qui a coûté cher ? (longue session, modèle élevé, gros CLAUDE.md, lectures larges ?)
4. Applique 2 leviers d'économie cette semaine. Mesure à nouveau.

## Check de validation

Tu sais :
- pourquoi les longues sessions coûtent
- comment le cache prompts fonctionne (et comment ne pas le casser)
- choisir le bon modèle par tâche
- mesurer ta consommation
- les 7 leviers d'économie

## Piège classique

Lancer Opus partout par "principe de qualité". 80 % des tâches passent très bien sur Sonnet (ou Haiku). Tu paies 5x pour rien.
