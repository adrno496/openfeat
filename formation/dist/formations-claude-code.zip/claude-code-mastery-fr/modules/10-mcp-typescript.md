# Module 10 — MCP servers en TypeScript + transport HTTP

**Niveau** : 🔴 avancé — **Durée** : 60 min lecture + 30 min pratique

## Prérequis

Modules 01 à 09 + bases Node/TS.

## Théorie

Mêmes concepts qu'en Python (Tools, Resources, Prompts) mais en TypeScript. Avantages côté TS :
- mieux intégré à un projet web/Node existant
- plus simple à déployer en HTTP (équivalent d'un microservice)
- typage natif

## Installation

```bash
npm install @modelcontextprotocol/sdk
# ou
pnpm add @modelcontextprotocol/sdk
```

## Anatomie minimale (stdio)

```ts
// server.ts
import { Server } from '@modelcontextprotocol/sdk/server/index.js'
import { StdioServerTransport } from '@modelcontextprotocol/sdk/server/stdio.js'
import { z } from 'zod'

const server = new Server(
  { name: 'lemonsqueezy-helper', version: '1.0.0' },
  { capabilities: { tools: {} } }
)

server.setRequestHandler('tools/list', async () => ({
  tools: [
    {
      name: 'list_subscriptions',
      description: 'Liste les abonnements actifs Lemonsqueezy',
      inputSchema: {
        type: 'object',
        properties: {
          status: { type: 'string', enum: ['active', 'cancelled', 'all'] }
        }
      }
    }
  ]
}))

server.setRequestHandler('tools/call', async (request) => {
  const { name, arguments: args } = request.params
  if (name === 'list_subscriptions') {
    const status = args?.status ?? 'active'
    const data = await fetchSubscriptions(status)
    return { content: [{ type: 'text', text: JSON.stringify(data) }] }
  }
  throw new Error(`Unknown tool: ${name}`)
})

async function fetchSubscriptions(status: string) {
  const res = await fetch(`https://api.lemonsqueezy.com/v1/subscriptions?filter[status]=${status}`, {
    headers: {
      'Authorization': `Bearer ${process.env.LEMONSQUEEZY_API_KEY}`,
      'Accept': 'application/vnd.api+json'
    }
  })
  const json = await res.json()
  return json.data.map((s: any) => ({
    id: s.id,
    customer_email: s.attributes.user_email,
    status: s.attributes.status,
    plan: s.attributes.product_name
  }))
}

const transport = new StdioServerTransport()
await server.connect(transport)
```

Configuration côté Claude Code :
```json
{
  "mcpServers": {
    "lemonsqueezy-helper": {
      "command": "node",
      "args": ["./mcp-lemon/dist/server.js"],
      "env": { "LEMONSQUEEZY_API_KEY": "..." }
    }
  }
}
```

## Transport HTTP

Quand utiliser HTTP plutôt que stdio :
- serveur partagé (équipe, CI, prod)
- serveur qui doit être déployé indépendamment de la machine du dev
- intégration avec une infra existante

### Exemple HTTP

```ts
import express from 'express'
import { Server } from '@modelcontextprotocol/sdk/server/index.js'
import { SSEServerTransport } from '@modelcontextprotocol/sdk/server/sse.js'

const app = express()
const mcp = new Server({ name: 'lemonsqueezy-helper', version: '1.0.0' }, { capabilities: { tools: {} } })

// ... handlers identiques ...

app.get('/sse', async (_req, res) => {
  const transport = new SSEServerTransport('/messages', res)
  await mcp.connect(transport)
})

app.post('/messages', express.json(), async (req, res) => {
  // routing vers le transport actif
})

app.listen(3000, () => console.log('MCP HTTP server on :3000'))
```

Configuration côté Claude Code :
```json
{
  "mcpServers": {
    "lemonsqueezy-helper": {
      "url": "https://mcp.tonsite.com/sse"
    }
  }
}
```

(L'API exacte évolue — vérifier la doc MCP courante.)

## Sécurité HTTP

Le serveur HTTP MCP doit être :
- en HTTPS (jamais HTTP en prod)
- authentifié (token, OAuth, mTLS)
- rate-limited
- audité (logger toutes les invocations de tools)

Exemple d'auth simple par token :

```ts
app.use((req, res, next) => {
  const token = req.headers.authorization?.replace('Bearer ', '')
  if (token !== process.env.MCP_TOKEN) {
    return res.status(401).json({ error: 'Unauthorized' })
  }
  next()
})
```

Configuration Claude Code avec token :
```json
{
  "mcpServers": {
    "lemonsqueezy-helper": {
      "url": "https://mcp.tonsite.com/sse",
      "headers": {
        "Authorization": "Bearer XXXX"
      }
    }
  }
}
```

## Validation d'entrée stricte avec Zod

```ts
const SubscriptionListInput = z.object({
  status: z.enum(['active', 'cancelled', 'all']).default('active'),
  limit: z.number().int().min(1).max(100).default(10)
})

server.setRequestHandler('tools/call', async (request) => {
  const { name, arguments: args } = request.params
  if (name === 'list_subscriptions') {
    const parsed = SubscriptionListInput.parse(args)
    const data = await fetchSubscriptions(parsed.status, parsed.limit)
    return { content: [{ type: 'text', text: JSON.stringify(data) }] }
  }
  throw new Error(`Unknown tool: ${name}`)
})
```

Si Claude Code envoie un argument hors enum, ça plante côté serveur avec un message clair (et pas un comportement non défini).

## stdio vs HTTP — comment choisir

| Critère | stdio | HTTP |
|---|---|---|
| Setup | trivial | déploiement nécessaire |
| Authent | hérité du process | à gérer (token, OAuth) |
| Partage équipe | non | oui (un serveur, plusieurs devs) |
| Vitesse | locale, instantanée | latence réseau |
| Logs centralisés | non | oui |
| Coût hébergement | nul | hébergement nécessaire |

Règle : commence en stdio. Passe en HTTP quand l'usage devient partagé.

## Démo : MCP TS stdio minimal

```bash
mkdir hello-mcp-ts && cd hello-mcp-ts
npm init -y
npm install @modelcontextprotocol/sdk
npm install -D typescript @types/node
```

```ts
// src/server.ts
import { Server } from '@modelcontextprotocol/sdk/server/index.js'
import { StdioServerTransport } from '@modelcontextprotocol/sdk/server/stdio.js'

const server = new Server({ name: 'hello-ts', version: '1.0.0' }, { capabilities: { tools: {} } })

server.setRequestHandler('tools/list', async () => ({
  tools: [{ name: 'hello', description: 'Say hello', inputSchema: { type: 'object', properties: { name: { type: 'string' } } } }]
}))

server.setRequestHandler('tools/call', async (req) => {
  const name = req.params.arguments?.name ?? 'world'
  return { content: [{ type: 'text', text: `Hello, ${name}` }] }
})

await server.connect(new StdioServerTransport())
```

```bash
npx tsc
node dist/server.js   # rien ne se passe, attend stdin
```

Branche-le dans `settings.local.json` et teste.

## Exercice

Construis un MCP TS pour un service que tu utilises (Stripe, Lemonsqueezy, GitHub, Notion, Linear) :
- 2 tools de lecture (ex : list, get)
- 1 tool de mutation (ex : create) avec validation Zod stricte
- Tests via MCP Inspector
- Optionnel : déployer en HTTP sur Railway/Fly

## Check de validation

Tu sais :
- créer un MCP TS stdio
- passer à HTTP avec authentification
- valider strictement les inputs avec Zod
- choisir entre stdio et HTTP selon contexte

## Piège classique

Exposer un MCP HTTP sans authent. Tout le monde peut l'invoquer. Tu te fais drainer ton API tierce. Toujours auth en HTTP.
