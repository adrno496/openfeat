# Module 03 — Contexte, mémoire et sessions

**Niveau** : 🟡 intermédiaire — **Durée** : 45 min lecture + 15 min pratique

## Prérequis

Modules 01 et 02 complétés.

## Théorie

Le "contexte" de Claude Code = la mémoire de la session courante.

Il est composé de :
- Le system prompt (interne, non visible)
- Les `CLAUDE.md` chargés (global + projet)
- Les outputs de tool calls (lectures de fichiers, sorties de commandes shell)
- Les messages utilisateur et réponses Claude depuis le début de la session

Quand tu envoies une nouvelle requête, **tout ce contexte est renvoyé en entrée** au modèle. Plus la session est longue, plus chaque requête est chère et plus la qualité dégrade.

## Limites

- La fenêtre de contexte d'Opus 4.7 est de 1M tokens (contexte étendu).
- À mesure qu'on s'approche de la limite, le système compresse automatiquement les messages les plus anciens (auto-compaction).
- Avant cette compression auto, **tu peux et dois agir manuellement**.

## Trois leviers

### 1. `/clear`
Reset complet. Vide tout. Tu repars à zéro avec uniquement les `CLAUDE.md` chargés.

Quand : changement radical de tâche, conversation partie en vrille, pollution évidente.

### 2. `/compact`
Demande à Claude Code de **résumer** la conversation et de remplacer le long historique par ce résumé. Garde l'essentiel, libère du contexte.

Quand : tâche en cours mais conversation longue, tu veux continuer sans perdre les décisions clés.

### 3. Sessions courtes par défaut
Souvent la meilleure stratégie : 1 tâche = 1 session. Tu fermes en finissant. Tu relances pour la suivante.

## Comment Claude Code lit ton projet

À chaque session, il reçoit :
- Les `CLAUDE.md` automatiquement
- Une vision haute-level du projet (généralement la liste de dossiers/fichiers principaux)

Il **ne charge pas tout le code**. Il lit les fichiers à la demande, quand il en a besoin pour répondre.

Conséquence : si tu commences ta session avec "Refactore tel fichier" sans préciser le chemin, il va d'abord faire `find` ou `grep` pour le localiser. Donne le chemin direct quand tu le connais.

## Pièges des longues conversations

### Drift sémantique
Tu as dit "n'utilise pas axios" à la 5e minute. Au bout de 2h, Claude Code te propose un refactor avec axios. Pourquoi ? Le pattern de tes 50 derniers messages a "poussé" cette ancienne contrainte hors du focus implicite.

**Solution** : redire la contrainte dans le `CLAUDE.md` projet. Ce qui est dans `CLAUDE.md` n'est jamais oublié — il est rechargé à chaque tour.

### Contradiction silencieuse
Tu as commencé sur la tâche A. Tu as dérivé sur la tâche B. Au bout de 1h, tu reposes une question liée à A. Claude Code répond avec le contexte de B.

**Solution** : `/clear` quand on bascule de tâche.

### Coût qui monte
Plus le contexte est long, plus chaque requête te coûte. Sessions de 4h = sessions chères et peu performantes.

## Mesurer ta consommation

```bash
claude usage
# Affiche un résumé : tokens consommés, sessions, etc.
```

(La commande exacte peut varier — vérifie `claude --help`.)

## Démo

Workflow type "matinée de dev" :

```
9h00  - cd projet-A, claude
        Tâche : ajouter endpoint /api/reset-password
        ~30 min, terminé.
        /exit

9h35  - claude (même projet, session fresh)
        Tâche : fixer un bug d'auth
        ~25 min, terminé.
        /exit

10h05 - cd projet-B, claude
        Tâche : refactor du composant Settings
        ~45 min, en cours
        /compact (la conversation devient longue)
        Continue ~20 min.
        /exit
```

Total : 4 tâches accomplies. 0 dérive. 0 contamination entre projets.

## Exercice

Sur une journée de dev :
1. Note combien de fois tu lances `claude`
2. Combien de tâches différentes tu accomplis
3. Combien de fois tu utilises `/clear` ou `/compact`
4. À la fin de la journée, fais le bilan : as-tu été dans le pattern "1 session = 1 tâche" ?

## Check de validation

Tu sais :
- de quoi est composé le contexte
- quand préférer `/clear`, `/compact`, ou fermer-rouvrir
- comment éviter le drift sémantique
- pourquoi les longues sessions sont chères et peu performantes

## Piège classique

Garder une session ouverte "au cas où on doit revenir au contexte". 9 fois sur 10, tu perds plus en pollution que tu ne gagnes en réutilisation.
