# Module 01 — Installation, configuration, comptes

**Niveau** : 🟢 débutant — **Durée** : 30 min lecture + 15 min pratique

## Prérequis

Aucun, sinon avoir un terminal opérationnel et VSCode.

## Théorie

Claude Code se présente sous 3 formes qui partagent ton compte mais pas tes sessions :

- **CLI** (`claude` dans ton terminal)
- **Extension VSCode** (sidebar, intégrée à l'éditeur)
- **Web** (`claude.ai/code`, utile en mobilité)

Chacune lit les mêmes fichiers de configuration : `~/.claude/settings.json` (global) et `.claude/settings.json` (projet).

## Comptes

Trois types principaux :

- **API** (pay-as-you-go) — tu charges du crédit, tu consommes
- **Pro** (abonnement mensuel à plafond) — usage modéré
- **Max** (abonnement haut volume) — usage intensif, recommandé pour devs full-time

Pour cette formation : Max recommandé pour ne pas se restreindre sur les exercices MCP/skills.

## Installation CLI

```bash
npm install -g @anthropic-ai/claude-code
claude --version
```

Première session :
```bash
claude
```

Authentification OAuth → ouverture browser → token stocké dans `~/.claude/auth.json` (le chemin exact peut évoluer, vérifier la doc).

## Installation VSCode

Marketplace → "Claude Code" (officiel Anthropic). Installer. Raccourci par défaut `Cmd+Esc` (macOS) / `Ctrl+Esc` (Linux/Windows).

L'extension s'authentifie automatiquement si tu as déjà la CLI configurée.

## Hiérarchie de configuration

Quand Claude Code démarre dans un dossier, il charge dans cet ordre :

1. `~/.claude/CLAUDE.md` (instructions globales utilisateur)
2. `~/.claude/settings.json` (préférences globales)
3. `<projet>/CLAUDE.md` (instructions projet)
4. `<projet>/.claude/settings.json` (settings projet, partagés via Git)
5. `<projet>/.claude/settings.local.json` (settings locaux, non commités)
6. `<projet>/<sous-dossier>/CLAUDE.md` (si présent — rarement utile)

Les valeurs plus spécifiques écrasent les plus générales.

## Multi-machines

Si tu travailles sur plusieurs machines :

- `~/.claude/` n'est pas synchronisé automatiquement
- Tu peux le mettre dans un repo dotfiles privé (sauf les tokens)
- Les `CLAUDE.md` de projets sont commités via Git, donc partagés naturellement

```bash
# Exemple : dotfiles privés
ln -s ~/dotfiles-private/claude/CLAUDE.md ~/.claude/CLAUDE.md
```

## Démo

Workflow d'installation propre :

```bash
# 1. Installation
npm install -g @anthropic-ai/claude-code

# 2. Premier lancement
cd ~/projects/test-project
claude

# 3. Vérification du CLAUDE.md global
cat ~/.claude/CLAUDE.md

# 4. Configuration projet
cat <<EOF > .claude/settings.json
{
  "model": "claude-opus-4-7"
}
EOF
```

## Exercice

1. Vérifie ta version : `claude --version`
2. Installe l'extension VSCode si pas déjà fait
3. Crée un `~/.claude/CLAUDE.md` global (instructions perso) — 30 lignes max
4. Sur 1 projet, crée `.claude/settings.json` avec un model par défaut

## Check de validation

Tu sais :
- la différence entre les 3 formes (CLI, VSCode, web)
- la hiérarchie de chargement des configs
- où sont tes tokens
- ce qu'il faut commit et ne pas commit

## Piège classique

Mettre des secrets ou clés API dans `.claude/settings.json` (qui peut être commité). Toujours utiliser `.claude/settings.local.json` (gitignoré par défaut) pour ce genre de valeur.
