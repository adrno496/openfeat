# Module 06 — Skills : modules réutilisables

**Niveau** : 🔴 avancé — **Durée** : 50 min lecture + 25 min pratique

## Prérequis

Modules 01 à 05 complétés.

## Théorie

Un **skill** est un module réutilisable qui :
- enseigne à Claude Code à exécuter une tâche spécifique
- peut s'auto-déclencher quand le contexte le justifie (via le `description`)
- est packageable, partageable, monétisable

Différence avec une slash command :
- Slash command = invoquée explicitement par toi (`/scope`)
- Skill = peut s'auto-déclencher si Claude Code juge qu'il s'applique

## Anatomie d'un skill

Structure type :
```
~/.claude/skills/<nom-du-skill>/
└── SKILL.md
```

Pour les skills projet :
```
.claude/skills/<nom>/SKILL.md
```

```markdown
---
name: csp-auditor
description: Auditer une politique CSP et détecter les directives dangereuses (unsafe-inline, unsafe-eval, *). Trigger quand on voit "CSP", "Content-Security-Policy", "csp.config", ou un fichier *.csp.
---

# CSP Auditor

Quand tu vois une politique CSP (Content-Security-Policy), audite-la selon ces règles :

## Directives critiques à signaler
- `unsafe-inline` → vulnérabilité XSS
- `unsafe-eval` → exécution de code arbitraire
- `*` (wildcard) → bypass complet
- `data:` dans `script-src` → vecteur XSS
- absence de `default-src` → permissif par défaut

## Format du rapport
- Note globale : critique / acceptable / bonne
- Liste des directives problématiques avec ligne
- Suggestion de remplacement pour chaque

## Quand NE PAS appliquer
- Si la CSP est en mode `Report-Only` et explicitement marquée "draft"
- Si on est dans `node_modules/` ou `.tmp/`
```

## Le frontmatter optimisé pour le triggering

Le `description` est **critique**. Claude Code l'utilise pour décider d'auto-charger le skill. Règle :

> Inclure dans `description` les **mots-clés** qui apparaîtront naturellement quand l'utilisateur a besoin du skill.

### Mauvais
```yaml
description: Un outil utile pour CSP
```

### Bon
```yaml
description: Auditer une politique CSP et détecter les directives dangereuses
  (unsafe-inline, unsafe-eval, wildcards). Trigger quand l'utilisateur mentionne
  CSP, Content-Security-Policy, ou édite un fichier *.csp ou csp.config.
```

Plus tu donnes de signaux concrets, plus le triggering est précis.

## Skills composables

Un skill peut référencer d'autres ressources via des chemins relatifs :

```
.claude/skills/csp-auditor/
├── SKILL.md
├── examples/
│   ├── safe-csp.txt
│   └── unsafe-csp.txt
└── reference/
    └── mdn-csp-spec.md
```

Dans `SKILL.md` :
```markdown
Voir `examples/safe-csp.txt` pour une politique correcte de référence.
```

Claude Code lira le fichier référencé si nécessaire pendant l'exécution du skill.

## Distribution

### Skills personnels
`~/.claude/skills/<nom>/`. Suivent ton utilisateur sur toutes les machines.

### Skills projet
`.claude/skills/<nom>/` à la racine du repo. Commités, partagés en équipe.

### Skills publics
Tu peux héberger un skill sur GitHub et donner les instructions d'installation. Le standard MCP (qu'on voit aux modules 09-10) permet aussi des skills servis par un serveur distant.

## Patterns avancés

### Skill avec checklist
```markdown
---
name: pre-deploy-check
description: Vérifie qu'un projet est prêt pour le déploiement prod. Trigger avant `git push origin main` ou quand l'utilisateur dit "déploiement", "prod", "ship".
---

# Pre-Deploy Check

Lance les vérifications dans cet ordre. Stop au premier échec.

1. Tests : `npm test` doit passer
2. Lint : `npm run lint` doit passer
3. Build : `npm run build` doit passer
4. Variables d'env : vérifier que `.env.production` n'est pas commité
5. Secrets : grep dans le diff pour clés API en clair
6. Migrations : vérifier que les migrations sont à jour

Rapport final : OK / KO + raison.
```

### Skill avec spécialisation linguistique
```markdown
---
name: supabase-rls-checker
description: Vérifier les politiques RLS d'une migration Supabase. Trigger quand tu vois `CREATE POLICY`, `ALTER TABLE ... ENABLE ROW LEVEL SECURITY`, ou un fichier dans `supabase/migrations/`.
---

# Supabase RLS Checker

Pour chaque table avec RLS activé :
1. Vérifier qu'il y a au moins une policy SELECT, INSERT, UPDATE, DELETE
2. Vérifier qu'aucune policy n'utilise `USING (true)` sans condition
3. Vérifier que `is_premium` (ou tout flag de droits) n'est jamais updatable côté client

Si une politique permet la mutation de flags critiques par l'utilisateur, **erreur bloquante**.
```

## Quand créer un skill vs une slash command

| Cas | Skill | Slash command |
|---|---|---|
| Auto-déclenchement contextuel | Oui | Non |
| Invocation explicite seulement | Non | Oui |
| Usage par toute l'équipe | Oui (skills projet) | Oui |
| Tâche complexe avec sous-fichiers de référence | Oui | Non |
| Workflow personnel rapide | Non | Oui |

## Démo

Crée un skill `commit-conventional` :

```bash
mkdir -p .claude/skills/commit-conventional
cat > .claude/skills/commit-conventional/SKILL.md <<'EOF'
---
name: commit-conventional
description: Génère un commit message au format Conventional Commits depuis le diff staged.
  Trigger quand l'utilisateur demande "génère un commit", "commit message",
  ou après `git add` / `git diff --staged`.
---

# Commit Conventional

Lis `git diff --staged`. Génère un message au format :

`type(scope): description`

Types : feat, fix, refactor, chore, docs, test, perf, build, ci, style.

Règles :
- max 72 caractères
- pas de point final
- impératif présent : "add", pas "added"
- scope optionnel mais recommandé
- corps optionnel séparé par ligne vide

Affiche uniquement le message final.
EOF
```

Test : modifie un fichier, `git add`, puis dis :
```
Génère le commit pour mon diff staged.
```

Claude Code devrait auto-déclencher `commit-conventional`.

## Exercice

1. Crée 2 skills projets utiles à ton workflow :
   - un `pre-deploy-check` adapté à ta stack
   - un `<n-import-quoi>` métier (ex : un linter de naming, un vérificateur de tests)
2. Soigne le `description` pour qu'il se déclenche bien
3. Teste sur 5 prompts différents : combien de fois il s'auto-déclenche correctement ?

## Check de validation

Tu sais :
- créer un skill avec frontmatter optimisé
- distinguer skill vs slash command vs sub-agent
- structurer un skill avec ressources externes
- distribuer en projet vs personnel

## Piège classique

Description trop vague → triggering raté. Description trop large → le skill se déclenche partout, pollue le contexte. Soigne ce champ.
