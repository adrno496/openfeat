# Module 09 — MCP servers en Python

**Niveau** : 🔴 avancé — **Durée** : 60 min lecture + 30 min pratique

## Prérequis

Modules 01 à 08 + bases Python.

## Théorie

MCP (Model Context Protocol) est un protocole standard pour brancher Claude Code (et autres clients MCP) à des outils externes : DB, APIs, filesystems, services tiers.

Un **MCP server** expose 3 types d'éléments :
- **Tools** — fonctions invocables (équivalent d'API endpoints)
- **Resources** — contenus lisibles (fichiers, données)
- **Prompts** — templates de prompts paramétrables

Claude Code = MCP client. Tu construis un MCP server custom = tu donnes de nouveaux super-pouvoirs à Claude Code.

## Transports

- **stdio** — le serveur tourne en local, Claude Code l'invoque via stdin/stdout
- **HTTP** — le serveur est distant, Claude Code parle via HTTPS

Pour ce module : stdio (le plus courant en Python). HTTP au module 10.

## SDK Python

```bash
pip install mcp
```

Ou avec `uv` :
```bash
uv add mcp
```

## Anatomie minimale d'un serveur

```python
# server.py
from mcp.server.fastmcp import FastMCP

mcp = FastMCP("supabase-helper")

@mcp.tool()
def count_users(table: str = "users") -> str:
    """Compte le nombre d'utilisateurs dans une table donnée."""
    # Logique métier ici (ex: appel à Supabase)
    return f"Found 42 rows in {table}"

if __name__ == "__main__":
    mcp.run(transport="stdio")
```

## Configuration côté Claude Code

Dans `.claude/settings.json` :

```json
{
  "mcpServers": {
    "supabase-helper": {
      "command": "python",
      "args": ["/Users/dreano/projects/mcp-supabase/server.py"]
    }
  }
}
```

Au démarrage de Claude Code, il lance `python server.py`, parle via stdio, et expose les tools.

## Exemple complet : MCP server pour Supabase

```python
# supabase_mcp.py
import os
from supabase import create_client, Client
from mcp.server.fastmcp import FastMCP

mcp = FastMCP("supabase-helper")

SUPABASE_URL = os.environ["SUPABASE_URL"]
SUPABASE_KEY = os.environ["SUPABASE_SERVICE_KEY"]
supabase: Client = create_client(SUPABASE_URL, SUPABASE_KEY)

@mcp.tool()
def list_tables() -> list[str]:
    """Liste toutes les tables publiques du projet Supabase."""
    response = supabase.rpc("list_public_tables").execute()
    return response.data

@mcp.tool()
def query_table(table: str, columns: str, limit: int = 10) -> list[dict]:
    """
    Lit des lignes d'une table. Spécifier les colonnes explicitement.
    Args:
        table: nom de la table
        columns: colonnes séparées par virgule (ex: 'id, email, created_at')
        limit: max 100
    """
    if limit > 100:
        limit = 100
    if "*" in columns:
        return [{"error": "wildcards not allowed, specify columns explicitly"}]
    response = supabase.table(table).select(columns).limit(limit).execute()
    return response.data

@mcp.tool()
def count_rows(table: str, where: str = "") -> int:
    """Compte les lignes d'une table avec filtre optionnel."""
    query = supabase.table(table).select("id", count="exact")
    if where:
        # Note : ne pas faire de SQL raw, utiliser les filtres typés Supabase
        # Ici simplifié pour l'exemple
        pass
    response = query.execute()
    return response.count

if __name__ == "__main__":
    mcp.run(transport="stdio")
```

## Configuration de l'environnement

```bash
# .env (NE PAS COMMIT)
SUPABASE_URL=https://xxx.supabase.co
SUPABASE_SERVICE_KEY=eyJ...

# settings.local.json (NE PAS COMMIT)
{
  "mcpServers": {
    "supabase-helper": {
      "command": "python",
      "args": ["./supabase_mcp.py"],
      "env": {
        "SUPABASE_URL": "https://xxx.supabase.co",
        "SUPABASE_SERVICE_KEY": "eyJ..."
      }
    }
  }
}
```

## Resources : exposer des données lisibles

```python
@mcp.resource("schema://{table}")
def get_table_schema(table: str) -> str:
    """Retourne le schéma d'une table."""
    response = supabase.rpc("get_table_schema", {"table_name": table}).execute()
    return str(response.data)
```

Claude Code peut alors lire `schema://users` comme s'il s'agissait d'un fichier.

## Prompts : templates partagés

```python
@mcp.prompt()
def review_migration(migration_file: str) -> str:
    """Prompt pour reviewer une migration Supabase."""
    return f"""
Lis le fichier {migration_file}.

Vérifie :
- RLS activé sur les nouvelles tables
- Au moins une policy SELECT par table
- Aucun wildcard dans les policies
- Les flags de droits (is_premium, role) ne sont pas updatable côté client

Rapporte ce qui manque.
"""
```

## Debugging

```bash
# Tester le serveur en standalone
python server.py
# (rien ne se passe — c'est normal, il attend stdin)

# Mieux : utiliser MCP Inspector
npx @modelcontextprotocol/inspector python server.py
```

L'Inspector ouvre une UI web où tu peux tester chaque tool/resource/prompt indépendamment.

## Bonnes pratiques

### Sécurité
- Jamais de `select('*')` exposé via MCP
- Jamais de mutation directe de flags critiques (is_premium, role) — passer par RPC server-side
- Limiter les pouvoirs : préférer `service_key` côté serveur MCP, jamais côté client
- Toujours utiliser des clés `.env`, jamais en dur dans le code

### Robustesse
- Type hints partout (le SDK les utilise pour générer les schémas)
- Docstrings claires (Claude Code les lit pour décider d'invoquer le tool)
- Gérer les erreurs : retourner des objets structurés `{"error": "..."}` plutôt que lever des exceptions

### Performance
- Cache local pour les requêtes répétitives
- Timeouts sur les appels distants
- Limit max sur les retours volumineux

## Démo

Crée et teste un MCP minimal :

```python
# /tmp/hello-mcp/server.py
from mcp.server.fastmcp import FastMCP

mcp = FastMCP("hello")

@mcp.tool()
def say_hello(name: str = "world") -> str:
    """Dit bonjour à quelqu'un."""
    return f"Hello, {name}"

if __name__ == "__main__":
    mcp.run(transport="stdio")
```

Configure dans `.claude/settings.local.json` :
```json
{
  "mcpServers": {
    "hello": {
      "command": "python",
      "args": ["/tmp/hello-mcp/server.py"]
    }
  }
}
```

Lance Claude Code, demande : "Utilise le tool say_hello avec name=Axel."

## Exercice

Construis un MCP server pour ton projet :
1. 1 tool de lecture (ex : count, list, query)
2. 1 tool de mutation (avec validation stricte)
3. 1 resource exposant la doc ou le schéma
4. Test via MCP Inspector

## Check de validation

Tu sais :
- créer un MCP stdio en Python
- exposer tools, resources, prompts
- configurer côté Claude Code
- debugger avec MCP Inspector

## Piège classique

Exposer un tool dangereux (ex : `delete_user(id)`) sans validation et sans confirmation. Toujours réfléchir : "qu'est-ce qui se passe si Claude Code l'invoque par erreur ?"
