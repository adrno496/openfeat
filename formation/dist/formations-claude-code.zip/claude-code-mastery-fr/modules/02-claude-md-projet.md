# Module 02 — `CLAUDE.md` projet : le contrat avec ton IA

**Niveau** : 🟡 intermédiaire — **Durée** : 45 min lecture + 15 min pratique

## Prérequis

Module 01 complété.

## Théorie

`CLAUDE.md` est lu **automatiquement** au démarrage de chaque session Claude Code dans un projet. C'est ton contrat avec l'IA pour ce projet.

Les bons `CLAUDE.md` partagent 4 caractéristiques :
- **courts** (< 100 lignes idéalement)
- **actionnables** (chaque ligne change un comportement)
- **spécifiques** (pas de banalités type "écris du code propre")
- **maintenus** (mis à jour quand le projet évolue)

## Hiérarchie des `CLAUDE.md`

```
~/.claude/CLAUDE.md           # tes préférences perso (toutes machines)
<projet>/CLAUDE.md            # contrat projet (commité, partagé en équipe)
<projet>/<module>/CLAUDE.md   # rare, pour sous-projet à conventions différentes
```

Les trois sont concaténés dans le contexte. Le projet écrase la perso quand contradiction.

## Sections recommandées

### 1. Stack
Le minimum pour situer le projet en 5 lignes.

```markdown
## Stack
- Frontend : Vanilla JS (ES Modules natifs, pas de bundler)
- Backend : Supabase (Postgres + Auth + Storage + Edge Functions)
- Mobile : Capacitor 6
- Déploiement : Vercel + Play Store
```

### 2. Conventions code
Les vraies, pas les évidences.

```markdown
## Conventions code
- Indentation 2 espaces, quotes simples, sans point-virgule
- ES Modules natifs, pas de require()
- Pas de framework (React, Vue) ajouté sans validation explicite
- Tests : Vitest pour les utils, Playwright pour le e2e
```

### 3. Règles métier non évidentes
Ce qui n'est pas dans le code et qui doit le rester.

```markdown
## Règles métier
- is_premium ne se mute jamais côté client (toujours via RPC server-side)
- Les abonnements mobile passent par RevenueCat, web par Lemonsqueezy
- Les tokens d'auth ont une durée de vie de 1h, refresh auto
```

### 4. Trucs à ne pas faire
La section la plus efficace de toutes.

```markdown
## Trucs à ne pas faire
- Ne pas remplacer fetch par axios
- Ne pas ajouter de framework côté frontend
- Ne pas modifier /legacy/* sauf demande explicite
- Ne jamais select('*') sur Supabase (toujours colonnes explicites)
- Ne pas commiter sans run de `npm test` au préalable
```

### 5. Commandes utiles
Le top 5 à 10. Pas plus.

```markdown
## Commandes utiles
- `npm run dev` — serveur local sur :3000
- `npm run build` — build prod
- `npm run db:types` — régénère types TS depuis Supabase
- `npx supabase db reset` — reset de la DB locale
```

### 6. Architecture (optionnel, pour gros projet)
3 à 5 lignes, pas plus. Le code doit parler de lui-même au-delà.

## Patterns avancés

### Inclure un fichier externe

Tu peux référencer un autre fichier sans le copier :

```markdown
## Architecture
Voir `docs/architecture.md` pour le détail de la couche services.
```

Claude Code le lira si pertinent.

### Variables et conventions de nommage

Si ton projet a un système de nommage spécifique, documente-le :

```markdown
## Nommage
- Composants : kebab-case (`user-card.js`)
- Hooks personnalisés : préfixe `use-` (`use-auth.js`)
- Constantes : SCREAMING_SNAKE_CASE
```

### CLAUDE.md hiérarchique

Pour un monorepo :

```
mon-monorepo/
├── CLAUDE.md          # conventions générales (TS strict, tests obligatoires)
├── apps/
│   ├── web/CLAUDE.md  # conventions spécifiques web (Astro)
│   └── api/CLAUDE.md  # conventions spécifiques api (Fastify)
```

Chaque sous-projet a ses spécificités, le commun reste à la racine.

## Anti-patterns

### Trop long
500 lignes de banalités. Personne ne les lit. Coupe.

### Trop vague
"Écris du bon code." → zéro signal actionnable.

### Trop spécifique
"La fonction `parseUserInput` doit toujours utiliser le regex /^[a-z]+$/i." → ce genre de chose va dans le code, pas dans `CLAUDE.md`.

### Documentation projet ≠ `CLAUDE.md`
`CLAUDE.md` n'est pas un README. Pas de "Comment installer le projet" — ça, c'est dans `README.md`.

## Démo

Avant/après sur un vrai `CLAUDE.md` :

### Avant (mauvais)
```markdown
# Mon projet

C'est un super projet. Nous utilisons des technologies modernes.
Quand tu codes, fais attention à écrire du code propre et maintenable.
Suis les bonnes pratiques. Documente bien tes fonctions.
```

### Après (bon)
```markdown
# CLAUDE.md

## Stack
Vanilla JS + Supabase + Vercel.

## Conventions
- 2 espaces, quotes simples, pas de point-virgule
- ES Modules, pas de bundler
- Pas de framework JS ajouté sans validation

## Trucs à ne pas faire
- Pas de select('*') Supabase
- is_premium muté uniquement via RPC server
- Ne pas toucher /legacy/

## Commandes
- npm run dev
- npm run build
- npm test
```

## Exercice

Pour 3 de tes projets actifs :
1. Audit du `CLAUDE.md` actuel
2. Coupe tout ce qui est banal ou non actionnable
3. Ajoute la section "Trucs à ne pas faire" si elle manque
4. Vise < 80 lignes par fichier

## Check de validation

Tu peux écrire un `CLAUDE.md` projet en 15 minutes qui :
- fait moins de 80 lignes
- n'a aucune ligne "banale"
- a une section "Trucs à ne pas faire" pertinente

## Piège classique

Penser que `CLAUDE.md` doit être "complet". Non — il doit être **utile**. 30 lignes utiles > 200 lignes banales.
