# Module 08 — Settings et permissions

**Niveau** : 🟡 intermédiaire — **Durée** : 30 min lecture + 15 min pratique

## Prérequis

Modules 01 à 07 complétés.

## Théorie

`settings.json` contrôle le comportement de Claude Code : modèle, permissions, hooks, etc.

Trois niveaux :
1. `~/.claude/settings.json` — global, perso
2. `.claude/settings.json` — projet, commité (équipe)
3. `.claude/settings.local.json` — projet, non commité (perso sur ce projet)

Le plus spécifique gagne.

## Permissions : `allow` et `deny`

```json
{
  "permissions": {
    "allow": [
      "Bash(git status)",
      "Bash(git diff)",
      "Bash(git diff --staged)",
      "Bash(npm test)",
      "Bash(rg:*)",
      "Read",
      "Edit",
      "Write"
    ],
    "deny": [
      "Bash(git push --force*)",
      "Bash(git reset --hard*)",
      "Bash(rm -rf /*)",
      "Bash(rm -rf ~/*)"
    ]
  }
}
```

`allow` = exécuté sans demander confirmation.
`deny` = refusé immédiatement, même si l'utilisateur tente d'autoriser.

Le `*` est un wildcard : `Bash(rg:*)` autorise n'importe quel argument après `rg`.

## Modes de validation

Trois modes principaux (varient selon version) :

- **`auto-accept`** : Claude Code peut exécuter sans confirmation tout ce qui est `allow`
- **`prompt`** : Claude Code demande confirmation pour chaque outil non listé en `allow`
- **`plan`** : Claude Code propose un plan avant toute action et attend validation explicite

Choisir selon contexte :
- Dev solo, projet de test → `auto-accept` avec `allow` large
- Travail en prod, action risquée → `plan`
- Standard équipe → `prompt`

## Hiérarchie complète

```
~/.claude/settings.json                       # baseline perso
↓ écrasé/complété par
<projet>/.claude/settings.json                # standard équipe
↓ écrasé/complété par
<projet>/.claude/settings.local.json          # ajustements perso projet
```

Ce qui veut dire qu'une `deny` en `.claude/settings.json` du projet ne peut PAS être levée en `.local.json`. Les `deny` sont prioritaires.

## Choix du modèle

```json
{
  "model": "claude-opus-4-7"
}
```

Modèles disponibles (varient avec le temps) :
- `claude-opus-4-7` — le plus capable, plus cher, plus lent
- `claude-sonnet-4-6` — équilibre qualité/coût
- `claude-haiku-4-5-20251001` — rapide, peu cher, suffisant pour beaucoup de tâches

Tu peux mettre un modèle différent par projet en utilisant `.claude/settings.json` du projet.

## Variables d'environnement

```json
{
  "env": {
    "DEBUG": "true",
    "EDITOR": "code"
  }
}
```

Disponibles dans les commandes Bash lancées par Claude Code et dans les hooks.

## MCP servers

```json
{
  "mcpServers": {
    "filesystem": {
      "command": "npx",
      "args": ["-y", "@modelcontextprotocol/server-filesystem", "/Users/dreano/projects"]
    }
  }
}
```

(Détail complet aux modules 09-10.)

## Exemple complet — settings.json projet équipe

```json
{
  "_comment": "Settings standard équipe pour le repo X",
  "model": "claude-opus-4-7",
  "permissions": {
    "allow": [
      "Bash(git status)",
      "Bash(git diff)",
      "Bash(git log:*)",
      "Bash(git branch)",
      "Bash(npm test)",
      "Bash(npm run build)",
      "Bash(npm run lint)",
      "Bash(rg:*)",
      "Bash(fd:*)",
      "Read",
      "Edit",
      "Write"
    ],
    "deny": [
      "Bash(git push --force*)",
      "Bash(git reset --hard*)",
      "Bash(git branch -D*)",
      "Bash(rm -rf /*)",
      "Bash(rm -rf ~/*)"
    ]
  },
  "hooks": {
    "PostToolUse": [
      {
        "matcher": "Edit|Write",
        "hooks": [
          {
            "type": "command",
            "command": "prettier --write \"$CLAUDE_TOOL_FILE_PATH\" 2>/dev/null || true"
          }
        ]
      }
    ]
  }
}
```

Engagé dans Git → toute l'équipe partage les mêmes permissions et hooks.

## Démo

Workflow type "j'arrive sur un nouveau projet équipe" :

```bash
git pull
cat .claude/settings.json    # tu vois les permissions standardisées
cp ~/.claude/settings.local.json.template .claude/settings.local.json
# tu ajoutes tes ajustements perso (ex : modèle plus cher pour ton dev)
```

## Exercice

1. Sur 1 projet, crée `.claude/settings.json` avec :
   - allow : top 10 des Bash que tu utilises
   - deny : les destructeurs (`push --force`, `reset --hard`, `rm -rf`)
   - model : `claude-opus-4-7`
2. Commit
3. Vérifie qu'à la prochaine session, Claude Code n'embête plus pour les commandes courantes

## Check de validation

Tu sais :
- la hiérarchie global / projet / local
- la différence entre `allow` et `deny` (deny est prioritaire)
- comment écrire un wildcard (`Bash(rg:*)`)
- comment configurer un modèle par projet

## Piège classique

Mettre des secrets ou clés API dans `.claude/settings.json` (commité). Toujours en `settings.local.json`.
