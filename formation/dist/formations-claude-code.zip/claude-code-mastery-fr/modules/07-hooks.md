# Module 07 — Hooks : intercepter les événements

**Niveau** : 🔴 avancé — **Durée** : 40 min lecture + 20 min pratique

## Prérequis

Modules 01 à 06 complétés.

## Théorie

Les hooks sont des commandes shell exécutées **automatiquement** sur certains événements de Claude Code. Ils permettent de :
- bloquer une action (ex : refuser un `git push --force`)
- logger des événements (audit, métriques)
- enrichir la session (ex : auto-charger un contexte)
- valider une sortie (ex : lint après chaque édition)

## Événements disponibles (les principaux)

- `PreToolUse` — avant un appel d'outil (Bash, Edit, Write, etc.)
- `PostToolUse` — après un appel d'outil (sortie disponible)
- `UserPromptSubmit` — quand l'utilisateur soumet un prompt
- `Stop` — fin de turn (Claude termine sa réponse)
- `Notification` — événements ponctuels (besoin d'une approbation, etc.)

(La liste exacte évolue — vérifier la doc.)

## Configuration

Dans `~/.claude/settings.json` ou `.claude/settings.json` :

```json
{
  "hooks": {
    "PreToolUse": [
      {
        "matcher": "Bash",
        "hooks": [
          {
            "type": "command",
            "command": "echo 'Bash about to run' >> ~/claude-audit.log"
          }
        ]
      }
    ]
  }
}
```

Le `matcher` filtre par type d'outil. Le `command` est un shell exécuté.

## Cas d'usage : pre-commit IA

Avant chaque édition de fichier, on peut lancer un linter et bloquer si erreur :

```json
{
  "hooks": {
    "PostToolUse": [
      {
        "matcher": "Edit|Write",
        "hooks": [
          {
            "type": "command",
            "command": "npm run lint:staged --silent || (echo 'Lint failed, please fix before continuing' && exit 2)"
          }
        ]
      }
    ]
  }
}
```

`exit 2` = bloquer Claude Code et lui faire savoir qu'il y a une erreur.

## Cas d'usage : audit log

```json
{
  "hooks": {
    "PreToolUse": [
      {
        "matcher": "Bash",
        "hooks": [
          {
            "type": "command",
            "command": "echo \"[$(date -u)] Bash: $CLAUDE_TOOL_INPUT\" >> /var/log/claude/audit.log"
          }
        ]
      }
    ]
  }
}
```

Variables d'environnement injectées dans le hook (selon contexte) : `$CLAUDE_TOOL_INPUT`, `$CLAUDE_PROJECT_PATH`, etc. (vérifier doc pour la liste exacte).

## Cas d'usage : refus de commandes destructives

```json
{
  "hooks": {
    "PreToolUse": [
      {
        "matcher": "Bash",
        "hooks": [
          {
            "type": "command",
            "command": "if echo \"$CLAUDE_TOOL_INPUT\" | grep -E 'rm -rf /|git push --force|git reset --hard'; then echo 'Blocked destructive command' && exit 2; fi"
          }
        ]
      }
    ]
  }
}
```

## Cas d'usage : auto-formatting

```json
{
  "hooks": {
    "PostToolUse": [
      {
        "matcher": "Edit|Write",
        "hooks": [
          {
            "type": "command",
            "command": "prettier --write \"$CLAUDE_TOOL_FILE_PATH\" 2>/dev/null || true"
          }
        ]
      }
    ]
  }
}
```

## Hooks vs slash commands vs skills

| Critère | Hook | Skill | Slash command |
|---|---|---|---|
| Automatique sur événement | Oui | Oui (via description) | Non |
| Peut bloquer une action | Oui | Non | Non |
| Code shell pur | Oui | Non (markdown) | Non |
| Modifie le contexte conversationnel | Non | Oui | Oui |

Hooks = couche système. Skills = couche IA. Slash commands = workflow utilisateur.

## Limites et pièges

### Performance
Un hook lent ralentit chaque action. Garde-les rapides (< 500 ms idéalement).

### Échec silencieux
Un hook qui plante n'arrête pas forcément Claude Code (selon le code de retour). Teste tes hooks indépendamment avant de les activer.

### Chemins absolus
Dans tes commandes shell, utilise des chemins absolus ou des variables d'env. Ne suppose jamais que tu es dans un PWD particulier.

### Sécurité
Un hook peut exécuter n'importe quel shell. Si tu télécharges un `settings.json` d'ailleurs, **lis-le entièrement** avant de l'activer.

## Démo

Hook simple : log des bash commands dans un fichier :

```bash
mkdir -p ~/.claude/logs
cat > ~/.claude/settings.json <<'EOF'
{
  "hooks": {
    "PreToolUse": [
      {
        "matcher": "Bash",
        "hooks": [
          {
            "type": "command",
            "command": "echo \"[$(date -u)] $CLAUDE_TOOL_INPUT\" >> ~/.claude/logs/bash-audit.log"
          }
        ]
      }
    ]
  }
}
EOF
```

Lance Claude Code, demande-lui de lancer une commande shell. Vérifie le fichier de log.

## Exercice

1. Configure un hook qui :
   - log toutes les commandes Bash avec timestamp
   - bloque tout `git push --force` ou `rm -rf /`
2. Teste en demandant à Claude Code de tenter une commande bloquée
3. Vérifie que le log se remplit

## Check de validation

Tu sais :
- les principaux événements (`PreToolUse`, `PostToolUse`, `UserPromptSubmit`, `Stop`)
- comment écrire un hook avec matcher
- comment bloquer une action (exit 2)
- la différence avec skills et slash commands

## Piège classique

Mettre des hooks qui plantent silencieusement. Toujours tester un hook en standalone (`bash -c "<commande>"`) avant de le câbler dans `settings.json`.
