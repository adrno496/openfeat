# Module 05 — Slash commands custom

**Niveau** : 🟡 intermédiaire — **Durée** : 35 min lecture + 15 min pratique

## Prérequis

Modules 01 à 04 complétés.

## Théorie

Les slash commands sont des raccourcis invocables dans une session Claude Code en tapant `/<nom>`. Claude Code en fournit certaines (`/clear`, `/compact`, `/help`). Tu peux créer les tiennes.

Cas d'usage :
- automatiser un workflow récurrent
- forcer un format de sortie
- standardiser un comportement entre membres d'équipe

## Anatomie

Une slash command custom est un fichier dans :
- `.claude/commands/<nom>.md` (projet)
- `~/.claude/commands/<nom>.md` (global)

```markdown
---
name: review-pr
description: Review du diff entre la branche courante et main, avec rapport structuré
---

Lis tous les fichiers modifiés sur la branche courante par rapport à `main`.

Pour chaque fichier modifié, rapporte :
- bugs potentiels
- failles de sécurité (XSS, SQL injection, secrets, validation manquante)
- duplications avec d'autres fichiers
- patterns incohérents avec le reste du projet

Format de sortie :
- 1 section par fichier
- Niveau de gravité (critique / moyen / faible)
- Suggestions de fix concrètes (sans modifier le code)

Ne modifie aucun fichier.
```

Invocation :
```
/review-pr
```

Claude Code exécute le contenu du fichier comme s'il s'agissait de ton prompt.

## Arguments

Une slash command peut accepter des arguments :

```markdown
---
name: explain-file
description: Explique un fichier en 5 points
---

Lis le fichier `$ARGUMENTS`.

Explique-moi en 5 points :
- son rôle dans le projet
- ses dépendances principales
- ses points de complexité
- ce qui pourrait être refactoré
- ce qui semble inachevé ou risqué
```

Invocation :
```
/explain-file src/auth/middleware.js
```

`$ARGUMENTS` est remplacé par tout ce que tu mets après le nom de la commande.

## Patterns utiles

### `/commit`
```markdown
---
name: commit
description: Génère un commit message conventionnel depuis le diff staged
---

Lis le diff staged via `git diff --staged`.

Génère un commit message conventionnel :
- format : type(scope): description
- types : feat, fix, refactor, chore, docs, test
- max 72 caractères
- pas de point final
- impératif présent ("add" pas "added")

Affiche uniquement le message, sans explication.
```

### `/test-failing`
```markdown
---
name: test-failing
description: Lance les tests, analyse les échecs et propose des fixes
---

1. Lance `npm test` (ou la commande équivalente du projet)
2. Pour chaque test qui échoue :
   - identifie la cause racine
   - propose le fix minimal
   - n'applique pas le fix sans confirmation
3. Si tous les tests passent : dis-le clairement et termine.
```

### `/scope`
```markdown
---
name: scope
description: Décrit le scope d'une tâche avant de l'attaquer
---

Tâche à scoper : $ARGUMENTS

Avant de coder, rapporte :
- fichiers que tu prévois de modifier (avec lignes approximatives)
- nouveaux fichiers à créer
- dépendances à ajouter (le cas échéant)
- risques de régression
- estimation : faible / moyen / fort effort

Ne touche pas au code. Attends ma validation pour passer à l'exécution.
```

## Distribution

### Commandes projet (commitées)
Dans `.claude/commands/` à la racine du repo. Toute l'équipe en bénéficie automatiquement.

```bash
git add .claude/commands/
git commit -m "chore: add /review-pr and /commit slash commands"
```

### Commandes globales (perso)
Dans `~/.claude/commands/`. Suivent ton compte sur toutes machines (à condition de synchroniser tes dotfiles).

## Démo

Création de `/scope` pour ton prochain ticket :

```bash
mkdir -p .claude/commands
cat > .claude/commands/scope.md <<'EOF'
---
name: scope
description: Décrit le scope avant d'attaquer
---

Tâche : $ARGUMENTS

Liste fichiers modifiés, fichiers créés, dépendances, risques.
Estimation effort. Pas de code.
EOF
```

Test :
```
/scope ajouter un endpoint POST /api/reset-password avec email token
```

## Quand préférer une slash command vs un sub-agent

| Critère | Slash command | Sub-agent |
|---|---|---|
| Réutilise du contexte de la session | Oui | Non |
| Tâche courte (< 5 min) | Oui | Non (overhead) |
| Tâche longue / risquée | Non | Oui (isolation) |
| Pas de pollution contexte | Non | Oui |
| Permissions restreintes possibles | Non | Oui |

Règle simple : slash command pour standardiser un workflow rapide dans la session courante. Sub-agent pour isoler une grosse tâche.

## Exercice

1. Crée 3 slash commands utiles à TON workflow :
   - une pour le commit message
   - une pour le scope avant tâche
   - une pour la review de PR
2. Commit-les dans `.claude/commands/` du projet.
3. Utilise-les pendant 1 semaine et adapte selon retour.

## Check de validation

Tu sais :
- créer une slash command projet ou globale
- utiliser `$ARGUMENTS` pour passer du contexte
- choisir entre slash command et sub-agent
- distribuer des commandes via Git pour ton équipe

## Piège classique

Faire des slash commands trop longues (200 lignes d'instructions). À ce stade-là, c'est un sub-agent qu'il te faut.
