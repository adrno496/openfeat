# Module 12 — Sécurité avancée

**Niveau** : 🔴 avancé — **Durée** : 45 min lecture + 15 min pratique

## Prérequis

Modules 01 à 11.

## Théorie

Trois familles de risques :
1. **Confidentialité** — Claude Code lit ton code et tes secrets, qu'est-ce qui sort ?
2. **Intégrité** — Claude Code peut écrire/exécuter, qu'est-ce qui peut être cassé ?
3. **Disponibilité** — Claude Code peut tuer un process, supprimer un fichier, planter un service

## Confidentialité

### Ce qui est envoyé à Anthropic
- Ton prompt
- Le contexte de session (fichiers lus, outputs de tools)
- Les `CLAUDE.md` chargés

### Ce qui n'est PAS envoyé (en théorie, à vérifier dans la doc Anthropic à jour)
- Les fichiers que Claude Code n'a pas explicitement lus
- Les fichiers exclus via `.claudeignore` ou équivalent

### Bonnes pratiques

- **Ne pas mettre de secrets dans le code** (utiliser `.env`, secret managers)
- **`.env` dans le `.gitignore`** ET dans le pattern d'exclusion Claude Code
- **Pas de PII / données clients** dans les fichiers que Claude Code peut lire
- **Compte API dédié** pour Claude Code, jamais ton compte production

### Patterns de secrets à éviter

```python
# JAMAIS
API_KEY = "sk-proj-abc123..."

# OK
import os
API_KEY = os.environ["API_KEY"]
```

## Intégrité

### Permissions strictes

Voir module 08. Récap clé :
- `deny` les opérations destructives (`git push --force`, `rm -rf`, `git reset --hard`)
- `allow` la liste blanche de ce que tu utilises souvent
- Tout le reste reste en mode "demander à l'utilisateur"

### Hooks de validation

Hooks `PreToolUse` qui bloquent les commandes dangereuses (cf. module 07).

### Mode plan

Pour les opérations risquées (refactor large, migration), passe en mode "plan" : Claude Code propose, tu valides explicitement avant exécution.

## Audit

### Logs systémiques

Hook qui log toutes les commandes Bash :
```json
{
  "hooks": {
    "PreToolUse": [
      {
        "matcher": "Bash",
        "hooks": [
          {
            "type": "command",
            "command": "echo \"[$(date -u)] $CLAUDE_TOOL_INPUT\" >> ~/.claude/logs/audit.log"
          }
        ]
      }
    ]
  }
}
```

### Review des sessions

`claude history` (commande à vérifier) — voir l'historique de tes sessions. Utile en post-mortem si quelque chose s'est mal passé.

## Risques spécifiques en équipe

### Settings projet pour standardiser
`.claude/settings.json` commité = baseline de sécurité partagée. Utilise-le.

### MCP servers d'origine douteuse
Un MCP server tiers qui exécute du shell sur ta machine. **Lis le code source** avant de l'installer.

### Skills d'origine douteuse
Un skill avec `description` malicieux peut s'auto-déclencher pour des prompts piégés. Lis chaque skill avant de l'installer.

### Hooks d'origine douteuse
Un hook = du shell qui s'exécute. Lis chaque hook avant d'activer un `settings.json` tiers.

## Risques côté Supabase / DB

### Service key vs anon key

```python
# Pour MCP server (server-side, isolé) — service_key OK
supabase = create_client(URL, os.environ["SERVICE_KEY"])

# Pour client web frontend — JAMAIS service_key, toujours anon_key
const supabase = createClient(url, ANON_KEY)
```

Si tu donnes la service_key à un MCP exposé en HTTP non sécurisé → tout ton DB est compromis.

### RLS comme dernière ligne de défense

Toutes les tables Supabase avec RLS activé. Chaque MCP tool qui touche la DB doit être conçu en supposant que l'utilisateur final pourrait avoir des droits limités.

### `is_premium` ne se mute jamais côté client

Rappel critique. Côté MCP, **n'expose pas** un tool qui modifie ces flags directement. Toujours via RPC server-side avec validation (paiement, signature webhook, etc.).

## Risques côté code généré

### Injections (SQL, command, etc.)

Claude Code peut générer du code vulnérable. Toujours review.

```js
// MAUVAIS — Claude Code peut générer ça si tu ne fais pas attention
const query = `SELECT * FROM users WHERE id = ${userId}`

// BON
const query = 'SELECT id, email FROM users WHERE id = $1'
const result = await db.query(query, [userId])
```

### XSS

```js
// MAUVAIS
element.innerHTML = userInput

// BON
element.textContent = userInput
```

Toujours examiner les outputs de Claude Code pour ces patterns avant accept.

### Secrets en dur

Claude Code peut, par confusion, écrire un secret qu'il a vu en contexte dans un fichier. Vérifie avant commit.

## Checklist sécurité

Avant tout déploiement Claude Code en équipe :

- [ ] `.claude/settings.json` projet commité avec `deny` pour opérations destructives
- [ ] Hooks d'audit log activés (au moins en dev)
- [ ] Pas de secrets dans `CLAUDE.md` (jamais)
- [ ] Pas de secrets dans `settings.json` projet (uniquement dans `settings.local.json`)
- [ ] Tous les MCP servers tiers ont eu leur code lu
- [ ] Tous les hooks tiers ont eu leur shell lu
- [ ] Compte API dédié à Claude Code (pas ton compte prod)
- [ ] RLS activé sur toutes les tables Supabase
- [ ] `is_premium` muté uniquement via RPC server-side validée

## Démo : audit log activé

```json
{
  "hooks": {
    "PreToolUse": [
      {
        "matcher": "Bash|Edit|Write",
        "hooks": [
          {
            "type": "command",
            "command": "echo \"[$(date -u)] [$CLAUDE_TOOL_NAME] $CLAUDE_TOOL_INPUT\" >> ~/.claude/logs/audit.log"
          }
        ]
      }
    ]
  }
}
```

Lance Claude Code, demande quelques actions, vérifie `~/.claude/logs/audit.log`.

## Exercice

1. Audite ton `~/.claude/settings.json` global :
   - y a-t-il des `deny` pour les destructeurs ?
   - y a-t-il un hook d'audit ?
2. Audite tes `.claude/settings.json` projets pareil.
3. Pour 1 projet, ajoute :
   - hook `PreToolUse` qui log toutes les Bash
   - `deny` sur push --force, reset --hard, branch -D
4. Vérifie que ça bloque bien en testant un cas

## Check de validation

Tu sais :
- les 3 familles de risques (confidentialité, intégrité, disponibilité)
- les patterns de secrets à éviter
- comment auditer une session
- les risques spécifiques aux MCP/skills/hooks tiers
- les risques côté Supabase / RLS / flags premium

## Piège classique

Penser "ça ne m'arrivera pas". Le jour où Claude Code lance `git push --force` ou supprime un fichier, ce sera trop tard. Configure les protections **avant** d'en avoir besoin.
