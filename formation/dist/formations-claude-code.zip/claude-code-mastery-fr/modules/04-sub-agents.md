# Module 04 — Sub-agents : isolation et parallélisation

**Niveau** : 🟡 intermédiaire — **Durée** : 50 min lecture + 25 min pratique

## Prérequis

Modules 01 à 03 complétés.

## Théorie

Un **sub-agent** est un sous-processus de Claude Code qui :
- vit dans son propre contexte (pas pollué par ta session principale)
- a sa propre identité (peut avoir son propre system prompt)
- communique avec l'agent parent par messages
- peut tourner en parallèle d'autres sub-agents

Les sub-agents servent à 3 choses :
1. **Isoler** une tâche longue ou risquée du contexte principal
2. **Paralléliser** plusieurs investigations indépendantes
3. **Spécialiser** : un sub-agent peut avoir des permissions ou tools restreints

## Anatomie d'un sub-agent custom

Tu peux définir des sub-agents personnalisés dans `.claude/agents/<nom>.md`.

```markdown
---
name: code-reviewer
description: Review du code modifié sur la branche courante. Cherche bugs, failles, duplications.
model: sonnet
tools: Read, Bash, Grep
---

Tu es un reviewer de code expérimenté. Quand on t'invoque :

1. Identifier les fichiers modifiés via `git diff main`
2. Lire chaque fichier en intégralité
3. Pour chaque, signaler :
   - bugs potentiels (null pointer, race condition, off-by-one)
   - failles de sécurité (XSS, SQL injection, secrets en dur)
   - duplications de code
   - patterns incohérents avec le reste du projet

Ne pas modifier le code. Juste rapporter.
```

Le frontmatter définit :
- `name` : identifiant invocable
- `description` : ce que fait l'agent (utilisée pour le triggering automatique)
- `model` : modèle utilisé (sonnet/opus/haiku, indépendant de la session principale)
- `tools` : whitelist explicite des outils accessibles

## Quand utiliser un sub-agent

### Cas 1 — Tâche longue
Refactor sur 10 fichiers. Lancer un sub-agent qui s'occupe du refactor entier, ton agent principal reste libre pour autre chose.

### Cas 2 — Recherche large
"Trouve tous les endroits où on utilise tel pattern dans le projet et liste-les." Sub-agent dédié, qui revient avec le résultat sans polluer ta session.

### Cas 3 — Review indépendante
Tu finis une feature. Tu lances un sub-agent `code-reviewer` qui fait un audit indépendant.

### Cas 4 — Parallélisation
Tu veux explorer 3 hypothèses pour un bug. 3 sub-agents en parallèle, chacun investigue une piste.

## Communication parent → enfant

L'agent parent invoque un sub-agent avec un prompt complet (puisque le sub-agent ne voit pas le contexte parent).

```
Lance un sub-agent "code-reviewer" pour reviewer la branche feat/auth.
Il doit me rapporter en moins de 200 mots.
```

Le sub-agent reçoit son prompt + la définition (`description` + body), exécute, retourne un message au parent.

## Communication enfant → parent

Le sub-agent ne peut **pas** appeler d'autres sub-agents (pas de chaînage). Il termine et son output devient un message dans la conversation parent.

## Parallélisation

Tu peux lancer plusieurs sub-agents en parallèle dans le même message :

```
Lance en parallèle :
- sub-agent "explorer" : où est défini le composant UserProfile dans le code ?
- sub-agent "explorer" : quels endpoints REST utilisent UserProfile ?
- sub-agent "explorer" : quels tests couvrent UserProfile ?

Synthétise les 3 réponses.
```

Trois investigations en parallèle, gain de temps net.

## Démo : créer ton premier sub-agent

```bash
mkdir -p .claude/agents
cat > .claude/agents/explorer.md <<'EOF'
---
name: explorer
description: Recherche dans la codebase sans modifier de fichiers. Renvoie chemins et extraits.
model: sonnet
tools: Read, Grep, Glob, Bash
---

Tu es un agent de recherche. Tu n'écris jamais. Tu lis, tu cherches, tu rapportes.

Quand on te demande de trouver quelque chose :
1. Utilise Grep / Glob pour localiser
2. Lis les fichiers pertinents en partie (pas tout)
3. Rapporte sous format :
   - fichier:ligne
   - contexte (3 lignes)
   - pertinence (forte / moyenne / faible)

Sois concis. Pas de commentaire éditorial.
EOF
```

Maintenant, dans une session :

```
Lance un sub-agent "explorer" : où sont définis les flags is_premium dans la codebase ?
```

Tu obtiens un rapport propre, sans polluer ton contexte.

## Limites et pièges

### Le sub-agent ne sait rien du parent
Si tu as 30 minutes de discussion utile avec ton agent principal, le sub-agent ne le voit pas. Tu dois lui réécrire le contexte nécessaire.

### Le sub-agent consomme des tokens
Chaque sub-agent = nouvelle conversation = nouveau contexte chargé. Pour des tâches courtes (< 5 min), ça ne vaut souvent pas la peine — fais-le dans la session principale.

### Pas de chaînage
Sub-agent → autre sub-agent = pas possible. Pour des workflows complexes, il faut orchestrer côté parent.

### Permissions des outils
Si ton sub-agent a `tools: Read` mais qu'il "veut" écrire, il échoue silencieusement. Vérifie les permissions.

## Exercice

1. Crée 2 sub-agents personnalisés :
   - `explorer` (lecture seule, recherche dans la codebase)
   - `code-reviewer` (lecture seule, review de branche)
2. Sur un projet réel, lance `explorer` pour répondre à une question que tu te poses
3. Sur une vraie branche, lance `code-reviewer` avant de push

## Check de validation

Tu sais :
- créer un sub-agent dans `.claude/agents/<nom>.md`
- choisir le bon `model` selon la tâche
- restreindre les `tools` pour la sécurité
- décider quand lancer un sub-agent vs faire directement

## Piège classique

Tout faire en sub-agent par "principe d'isolation". Tu paies en tokens et en latence ce que tu gagnes en propreté. Pour 80 % des tâches courtes, la session principale suffit largement.
