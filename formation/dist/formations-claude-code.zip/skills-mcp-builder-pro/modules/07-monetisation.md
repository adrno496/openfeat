# Module 07 — Monétisation

**Niveau** : 🟡 — **Durée** : 30 min lecture

## 3 modèles testés

### 1. SaaS MCP (le plus scalable)

Tu déploies un MCP server HTTP en mode multi-tenant. Chaque utilisateur paie un abonnement pour avoir accès à ton serveur.

**Cas d'usage type** : MCP qui se branche à une API tierce coûteuse (ex: TradingView Premium, scrapers Glassnode/Dune en quant). L'utilisateur paie ton SaaS, tu factures la tranche d'API derrière.

**Pricing type** :
- Free : 100 requêtes/mois, 1 tool
- Pro : 5000 requêtes/mois, tous les tools
- Team : illimité, support, SLA

**Stack** :
- Backend MCP HTTP (Express + SSE) sur Fly.io ou Railway
- Auth Bearer token
- Paiements Lemonsqueezy (perso, MoR pour TVA UE)
- Audit + analytics

### 2. Skill packs licenced

Tu vends un pack de skills ou de MCP servers (code source + LICENSE) sous license commerciale.

**Cas d'usage type** : un pack "Solo Founder Skills" (15 skills + 3 MCPs) vendu une seule fois ou en abonnement annuel pour les mises à jour.

**Pricing type** :
- One-shot : prix unique, accès au repo privé en lecture
- Subscription annuel : updates inclus, accès au Discord

**Stack** :
- Repo privé GitHub
- Lemonsqueezy pour le paiement
- Webhook qui invite l'acheteur sur le repo privé

### 3. Consulting / custom MCPs

Tu construis des MCPs custom pour des clients (agences, fonds, équipes tech). Tarification au projet ou au TJM.

**Cas d'usage type** : un fonds quant veut un MCP qui se branche à leur stack interne (Refinitiv, Bloomberg, ou data warehouse propriétaire). Tu construis sur mesure.

**Pricing type** :
- Discovery (1 jour) : pour scoper
- MVP (2-4 semaines) : forfait
- Maintenance : abonnement mensuel

## Choix selon profil

| Profil | Modèle recommandé |
|---|---|
| Dev solo, peu de temps | Skill packs licenced |
| Dev qui veut scaler | SaaS MCP |
| Freelance senior | Consulting (TJM élevé) |
| Agence | Combo : SaaS MCP + consulting |

## Pricing : ne sous-évalue pas

Erreur fréquente : pricer trop bas par insécurité.

Repère :
- Un MCP qui économise 1h/semaine à un dev senior = $100-300/mois facilement justifiable
- Un skill pack qui condense 50h de R&D = $200-500 one-shot raisonnable
- Un MCP custom 2 semaines = $5k-15k forfait

Si tes clients trouvent pas cher, augmente. Si beaucoup refusent, tu es trop cher OU ton positioning est mauvais.

## Fiscalité (FR)

Cf. `LEGAL-NOTES.md` racine du dépôt formations.

Points clés :
- Statut : auto-entrepreneur OK pour démarrer (jusqu'à 37 500 € HT services)
- Au-delà : société (SAS, SASU)
- TVA : franchise en base si AE sous seuil, sinon collecte 20 % (Lemonsqueezy MoR aide à gérer le multi-pays)

## Distribution monétisée — schémas pratiques

### SaaS MCP avec auth + billing

```
Utilisateur signup → Lemonsqueezy checkout → webhook → DB user créé avec token API
Utilisateur configure son client Claude Code avec son token
Chaque appel MCP = vérif token → exécution → log billing
Mois suivant → Lemonsqueezy facture le forfait
```

### Skill pack one-shot

```
Utilisateur achète sur Lemonsqueezy
Webhook → invite GitHub via API
Utilisateur clone le repo privé
Mises à jour = git pull (gratuit pour la durée d'accès achetée)
```

### Consulting

```
Discovery call (gratuit ou facturé)
Proposition + scope écrit
Acompte 30-50 %
Build (2-4 semaines)
Livraison + formation
Solde + (optionnel) contrat de maintenance
```

## Marketing minimal pour vendre tes MCPs/skills

Tu n'as pas besoin de marketing massif. Tu as besoin de présence ciblée :
- 1 post X/LinkedIn par semaine sur ton domaine
- 1 article de blog tous les 15 jours qui démontre la valeur
- 1 démo vidéo (90 sec) par MCP/skill qui montre l'usage réel
- Présence dans les communautés de ton secteur (Discord, Slack, forums)

L'objectif : devenir LE référent sur ton créneau étroit.

## Anti-patterns

### Vendre sans avoir utilisé toi-même
Si tu n'utilises pas ton MCP au quotidien, tu ne sais pas ce qui marche pour les utilisateurs. Mange ta propre dogfood d'abord.

### Pricing au feeling
Tu sous-évalues, tu n'arrives plus à scaler le support, tu hates ton produit. Mesure le ROI client, price en fonction.

### Promesses non tenues
"100 % uptime", "0 latence", "support 24/7 par moi-même solo founder". Dans 6 mois tu craques. Sois honnête.

## Exercice

1. Identifie 1 MCP ou skill que tu as construit qui pourrait être monétisé
2. Choisis 1 modèle (SaaS / pack / consulting)
3. Définis 3 personas client cible (qui paie, combien, pour quoi)
4. Estime un prix raisonnable + comment tu le justifies
5. Documente : si tu publies aujourd'hui, quel est ton MVP de pricing page ?

## Check

Tu peux répondre en 1 paragraphe à : "qu'est-ce que je vends, à qui, à quel prix, pour quel ROI client ?"

Si tu peux pas, tu n'es pas prêt à monétiser.
