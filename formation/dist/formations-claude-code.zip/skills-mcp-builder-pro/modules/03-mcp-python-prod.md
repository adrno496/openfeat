# Module 03 — MCP server Python production-grade

**Niveau** : 🔴 — **Durée** : 60 min lecture + 30 min pratique

## Théorie

Un MCP "qui marche en démo" est facile. Un MCP "production-grade" demande :
- Validation d'inputs stricte (Pydantic)
- Gestion d'erreurs structurée (jamais de stack trace au client)
- Tests (unitaires + golden output)
- Packaging propre (uv ou Poetry)
- Configuration via env vars (jamais hardcoded)
- Logs structurés (JSON, pas du print sauvage)

## Architecture

```
mcp-lemonsqueezy-py/
├── pyproject.toml
├── README.md
├── src/
│   └── mcp_lemonsqueezy/
│       ├── __init__.py
│       ├── server.py
│       ├── api.py            # client Lemonsqueezy
│       ├── models.py         # Pydantic models
│       └── logging_config.py
├── tests/
│   ├── test_api.py
│   └── golden/               # outputs de référence pour les tests
└── .github/
    └── workflows/
        └── ci.yml
```

## `pyproject.toml`

```toml
[project]
name = "mcp-lemonsqueezy"
version = "1.0.0"
description = "MCP server for Lemonsqueezy"
requires-python = ">=3.11"
dependencies = [
    "mcp>=1.0",
    "httpx>=0.27",
    "pydantic>=2.0",
    "structlog>=24.0",
]

[project.scripts]
mcp-lemonsqueezy = "mcp_lemonsqueezy.server:main"

[build-system]
requires = ["hatchling"]
build-backend = "hatchling.build"
```

Avec `uv` :
```bash
uv venv
uv pip install -e .
```

## `models.py` — validation stricte

```python
from pydantic import BaseModel, Field, field_validator
from typing import Literal

class ListSubscriptionsInput(BaseModel):
    status: Literal["active", "cancelled", "expired", "all"] = "active"
    limit: int = Field(default=10, ge=1, le=50)

class GetCustomerInput(BaseModel):
    customer_id: str = Field(min_length=1, max_length=64)

    @field_validator("customer_id")
    @classmethod
    def alphanumeric(cls, v: str) -> str:
        if not v.replace("_", "").isalnum():
            raise ValueError("customer_id must be alphanumeric")
        return v
```

## `api.py` — client API

```python
import httpx
import structlog
from .models import ListSubscriptionsInput

log = structlog.get_logger()

class LemonsqueezyClient:
    def __init__(self, api_key: str, base_url: str = "https://api.lemonsqueezy.com/v1"):
        self.client = httpx.AsyncClient(
            base_url=base_url,
            headers={
                "Authorization": f"Bearer {api_key}",
                "Accept": "application/vnd.api+json",
            },
            timeout=10.0,
        )

    async def list_subscriptions(self, params: ListSubscriptionsInput) -> list[dict]:
        query = {"page[size]": params.limit}
        if params.status != "all":
            query["filter[status]"] = params.status
        try:
            res = await self.client.get("/subscriptions", params=query)
            res.raise_for_status()
        except httpx.HTTPStatusError as e:
            log.error("api_error", status=e.response.status_code, url=str(e.request.url))
            raise
        data = res.json()["data"]
        return [
            {
                "id": s["id"],
                "email": s["attributes"]["user_email"],
                "status": s["attributes"]["status"],
                "product": s["attributes"]["product_name"],
                "renews_at": s["attributes"]["renews_at"],
            }
            for s in data
        ]

    async def close(self):
        await self.client.aclose()
```

## `server.py` — MCP exposition

```python
import asyncio
import json
import os
import sys
from mcp.server.fastmcp import FastMCP
from .api import LemonsqueezyClient
from .models import ListSubscriptionsInput, GetCustomerInput
from .logging_config import setup_logging

setup_logging()

mcp = FastMCP("lemonsqueezy")

API_KEY = os.environ.get("LEMONSQUEEZY_API_KEY")
if not API_KEY:
    print("ERROR: LEMONSQUEEZY_API_KEY missing", file=sys.stderr)
    sys.exit(1)

client = LemonsqueezyClient(API_KEY)

@mcp.tool()
async def list_subscriptions(status: str = "active", limit: int = 10) -> str:
    """Liste les abonnements Lemonsqueezy filtrés par statut."""
    try:
        params = ListSubscriptionsInput(status=status, limit=limit)
    except ValueError as e:
        return json.dumps({"error": "invalid_input", "details": str(e)})
    try:
        results = await client.list_subscriptions(params)
        return json.dumps(results)
    except Exception as e:
        return json.dumps({"error": "api_error", "details": str(e)})

@mcp.tool()
async def get_customer(customer_id: str) -> str:
    """Récupère les infos d'un client Lemonsqueezy."""
    try:
        params = GetCustomerInput(customer_id=customer_id)
    except ValueError as e:
        return json.dumps({"error": "invalid_input", "details": str(e)})
    # ... appel API ...

def main():
    try:
        mcp.run(transport="stdio")
    finally:
        asyncio.run(client.close())

if __name__ == "__main__":
    main()
```

## `logging_config.py`

```python
import logging
import structlog

def setup_logging():
    logging.basicConfig(
        format="%(message)s",
        stream=sys.stderr,
        level=logging.INFO,
    )
    structlog.configure(
        processors=[
            structlog.contextvars.merge_contextvars,
            structlog.processors.add_log_level,
            structlog.processors.TimeStamper(fmt="iso"),
            structlog.processors.JSONRenderer(),
        ],
    )
```

Logs JSON sur stderr (stdout est réservé au protocole MCP).

## Gestion d'erreurs : structurée

**Jamais** de stack trace au client. Toujours :
```python
return json.dumps({
    "error": "<short_code>",
    "details": "<human-readable, no internal info>"
})
```

Côté Claude Code, l'utilisateur voit "error: api_error, details: rate limit exceeded", pas un internal traceback Python.

## Tests

```python
# tests/test_api.py
import pytest
from mcp_lemonsqueezy.models import ListSubscriptionsInput

def test_list_subscriptions_input_valid():
    params = ListSubscriptionsInput(status="active", limit=10)
    assert params.status == "active"

def test_list_subscriptions_input_limit_too_high():
    with pytest.raises(ValueError):
        ListSubscriptionsInput(limit=200)

def test_list_subscriptions_input_invalid_status():
    with pytest.raises(ValueError):
        ListSubscriptionsInput(status="weird")
```

## Packaging et publication

```bash
# Build
uv build

# Tester l'install locale
uv pip install dist/mcp_lemonsqueezy-1.0.0-py3-none-any.whl

# Publier sur PyPI
uv publish
```

Tu peux aussi distribuer via `uvx` directement depuis Git :
```json
{
  "mcpServers": {
    "lemonsqueezy": {
      "command": "uvx",
      "args": ["--from", "git+https://github.com/toi/mcp-lemonsqueezy", "mcp-lemonsqueezy"],
      "env": { "LEMONSQUEEZY_API_KEY": "ls_..." }
    }
  }
}
```

## Anti-patterns

- `print()` partout : pollue stdout, casse le protocole MCP. Toujours stderr.
- Secrets hardcodés : impardonnable.
- Pas de validation d'input : tu vas crasher en prod sur un payload edge.
- Stack traces au client : info leak, pas pro.

## Exercice

1. Forke ton MCP de l'exercice F1
2. Refactor en architecture du module (api.py, models.py, server.py, logging_config.py)
3. Ajoute Pydantic sur tous les inputs
4. Ajoute structlog
5. Ajoute 5 tests unitaires sur les models
6. Package en `pyproject.toml` + test install via `uv pip install -e .`

## Check

- `uv pip install -e .` marche
- 5 tests passent
- Logs JSON sur stderr
- Aucun secret dans le code
- Aucun stack trace exposé au client
