# Module 05 — Tests, versionning, CI

**Niveau** : 🔴 — **Durée** : 40 min lecture + 20 min pratique

## Tests

### Tests unitaires des models (Pydantic / Zod)

```python
# tests/test_models.py
import pytest
from mcp_lemonsqueezy.models import ListSubscriptionsInput

def test_status_valid():
    assert ListSubscriptionsInput(status="active").status == "active"

def test_status_invalid():
    with pytest.raises(ValueError):
        ListSubscriptionsInput(status="weird")

def test_limit_too_high():
    with pytest.raises(ValueError):
        ListSubscriptionsInput(limit=200)
```

### Tests "golden output"

Tu valides que le format de sortie d'un tool reste stable :

```python
# tests/test_golden.py
import json
from pathlib import Path

GOLDEN_DIR = Path(__file__).parent / "golden"

def test_subscription_format(monkeypatch):
    # Mock l'API response
    fake_response = json.loads((GOLDEN_DIR / "lemonsqueezy_subs_response.json").read_text())
    # Assert que la transformation produit un format spécifique
    expected = json.loads((GOLDEN_DIR / "expected_output.json").read_text())
    # ...
```

Si tu changes le format de sortie sans mettre à jour le golden, le test casse → tu vois immédiatement la breaking change.

### Tests d'intégration légers (sans appeler l'API)

```python
# tests/test_server.py
import pytest
from unittest.mock import AsyncMock, patch

@pytest.mark.asyncio
async def test_list_subscriptions_success():
    with patch("mcp_lemonsqueezy.server.httpx.AsyncClient") as mock_client:
        mock_client.return_value.__aenter__.return_value.get = AsyncMock(
            return_value=AsyncMock(status_code=200, json=lambda: {"data": []})
        )
        from mcp_lemonsqueezy.server import list_subscriptions
        result = await list_subscriptions(status="active")
        assert "[]" in result
```

## Versionning sémantique

Format `MAJOR.MINOR.PATCH` :
- **MAJOR** : breaking change (renommer un tool, changer un schéma)
- **MINOR** : nouvelle fonctionnalité (nouveau tool, nouveau resource)
- **PATCH** : bug fix sans breaking change

Stocké dans `pyproject.toml` (Python) ou `package.json` (TS).

### Tag git

```bash
git tag v1.2.0
git push --tags
```

### CHANGELOG.md

```markdown
# Changelog

## [1.2.0] - 2026-05-15

### Added
- Tool `monthly_revenue` (calcule MRR depuis subscriptions actives)

### Changed
- `list_subscriptions` retourne maintenant `renews_at` en ISO 8601

### Fixed
- Crash si Lemonsqueezy retourne `data: null`

## [1.1.0] - 2026-04-20
...
```

À chaque release : pas de `git tag` sans CHANGELOG mis à jour.

## CI GitHub Actions

`.github/workflows/ci.yml` :

```yaml
name: CI
on:
  push:
    branches: [main]
  pull_request:

jobs:
  test:
    runs-on: ubuntu-latest
    strategy:
      matrix:
        python-version: ['3.11', '3.12']
    steps:
      - uses: actions/checkout@v4
      - uses: astral-sh/setup-uv@v3
      - run: uv venv
      - run: uv pip install -e ".[dev]"
      - run: uv run pytest -v
```

Pour TypeScript :
```yaml
jobs:
  test:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - uses: actions/setup-node@v4
        with:
          node-version: '20'
      - run: npm ci
      - run: npm run build
      - run: npm test
```

## Release automation (optionnel)

Avec **changesets** (TS) ou **release-please** (multi-langage) :

`.github/workflows/release.yml` :
```yaml
name: Release
on:
  push:
    branches: [main]
jobs:
  release:
    runs-on: ubuntu-latest
    steps:
      - uses: googleapis/release-please-action@v4
        with:
          release-type: python  # ou node
```

À chaque PR mergée, release-please met à jour CHANGELOG + version + tag.

## Pré-release et beta

Pour tester une version sans casser les utilisateurs :
- `1.2.0-beta.1`, `1.2.0-rc.1` (pre-release, pas installé par défaut)
- Branche `next` sur npm pour TS
- Label `pre-release` sur GitHub

## Démo : pipeline complet

```bash
# Dev local
git checkout -b feat/new-tool
# code + tests
pytest
git commit -m "feat: add monthly_revenue tool"
git push origin feat/new-tool

# Open PR sur GitHub → CI lance pytest sur 2 versions Python
# Review → merge

# Sur main, release-please détecte le commit conventionnel
# Crée une PR "Release v1.2.0" avec CHANGELOG mis à jour
# Tu merges → tag v1.2.0 + release GitHub + (optionnel) publish npm/PyPI
```

## Exercice

1. Forke ton MCP du module 03
2. Ajoute pytest + 5 tests sur les models
3. Crée `.github/workflows/ci.yml`
4. Push, vérifie que CI tourne
5. Tag v1.0.0, vérifie le release sur GitHub

## Check

- 5 tests passent
- CI verte sur PR et main
- Tag v1.0.0 créé
- CHANGELOG.md initial créé

## Piège

Skip le CHANGELOG en disant "je le ferai plus tard". 6 mois plus tard, tu ne sais plus ce qui a changé. Discipline obligatoire.
