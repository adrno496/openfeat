# Module 06 — Distribution : privée, équipe, publique

**Niveau** : 🟡 — **Durée** : 40 min lecture + 15 min pratique

## 3 niveaux de distribution

### Privée (perso)
Tu es le seul utilisateur. `~/.claude/skills/`, `~/.claude/agents/`, `~/.claude/commands/`.

### Équipe
Plusieurs devs partagent. Repo Git avec `.claude/` commité. Setup automatique au clone.

### Publique
Tout le monde peut installer. Repo public + registry MCP.

## Distribution privée

Pas grand-chose à dire. Backup tes dotfiles (privés ou publics selon le cas).

```bash
# Versionning de tes ~/.claude/
mkdir -p ~/dotfiles/claude
cp -r ~/.claude/{CLAUDE.md,settings.json,skills,agents,commands} ~/dotfiles/claude/
cd ~/dotfiles && git init && git add . && git commit -m "snapshot"
```

Sur nouvelle machine :
```bash
git clone <ton-dotfiles-repo>
cp -r dotfiles/claude/* ~/.claude/
```

## Distribution équipe

### Repo central avec `.claude/`

```
mon-projet-equipe/
├── .claude/
│   ├── settings.json           (commité)
│   ├── settings.local.json.template  (commité)
│   ├── skills/                 (commité)
│   ├── agents/                 (commité)
│   └── commands/               (commité)
├── .gitignore                  (avec .claude/settings.local.json)
└── README-claude-code.md       (instructions onboarding)
```

### Onboarding automatisé

Script `setup-claude.sh` à la racine :
```bash
#!/bin/bash
set -e
echo "Setting up Claude Code for this project..."
mkdir -p ~/.claude/logs
if [ ! -f .claude/settings.local.json ]; then
  cp .claude/settings.local.json.template .claude/settings.local.json
  echo "✓ Template local copié — remplace les REPLACE_ME par tes secrets"
fi
echo "Done. Lance 'claude' dans ce dossier."
```

Nouvel arrivant :
```bash
git clone repo
cd repo
./setup-claude.sh
# édite .claude/settings.local.json avec ses secrets
claude
```

### Repo de skill pack interne

Si tu as un grand pool de skills à partager entre projets :

```
internal-claude-tools/
├── skills/
│   ├── supabase-rls/
│   ├── csp-auditor/
│   └── pre-deploy/
├── commands/
└── README.md (instructions install)
```

Chaque projet équipe consomme via :
```bash
git clone <internal-claude-tools> ~/.claude/_internal-tools
ln -s ~/.claude/_internal-tools/skills ~/.claude/skills
```

## Distribution publique

### Skills/Agents/Commands sur GitHub

Repo public avec README clair :
```
mon-skill-public/
├── SKILL.md
├── reference/
├── examples/
├── README.md           (install instructions, usage, examples)
└── LICENSE             (MIT, Apache, etc.)
```

Install user :
```bash
git clone https://github.com/toi/mon-skill-public ~/.claude/skills/mon-skill
```

### MCP servers publics

Pour les **MCP Python** :
- Publier sur PyPI : `uv publish`
- Install user : `uvx --from mon-mcp-package mon-mcp-bin`

Pour les **MCP TypeScript** :
- Publier sur npm : `npm publish`
- Install user : `npx -y @toi/mon-mcp`

### Registry MCP officiel

Le projet `modelcontextprotocol/servers` sur GitHub liste les MCPs publics. Tu peux soumettre une PR pour ajouter le tien.

Format type :
```markdown
## My MCP Server
A description...

```json
{
  "mcpServers": {
    "my-server": {
      "command": "uvx",
      "args": ["--from", "my-package", "my-server"]
    }
  }
}
```

GitHub : https://github.com/toi/my-mcp
```

### README qui convertit (pour public)

À inclure :
- 1 ligne de description
- Installation en 1 commande
- Configuration JSON copy-paste
- 3 exemples d'utilisation
- Liste des tools/resources/prompts exposés
- Sécurité : ce que ton MCP a comme permissions
- License + contributing

## Démo : publier un skill sur GitHub

```bash
mkdir csp-auditor-public
cd csp-auditor-public
cp ../path/to/SKILL.md .
git init
git add .
git commit -m "v1.0.0"
gh repo create csp-auditor-public --public --source=. --remote=origin --push
```

Maintenant n'importe qui peut faire :
```bash
git clone https://github.com/toi/csp-auditor-public ~/.claude/skills/csp-auditor
```

## Anti-patterns

### Distribuer sans LICENSE
Sans LICENSE, tes utilisateurs ne peuvent légalement pas l'utiliser. Toujours MIT ou Apache 2.0 par défaut.

### Distribuer sans tests publics
Personne ne va trust ton MCP sans tests visibles dans le repo. CI verte aide aussi.

### Distribuer sans CHANGELOG
Idem. Personne ne sait ce qui change entre versions.

### Distribuer un MCP qui demande secrets en clair dans config
Documente toujours les variables d'env, jamais hardcoded.

## Exercice

1. Choisis 1 skill ou MCP que tu as construit
2. Crée un repo public sur GitHub avec README + LICENSE + CHANGELOG
3. (Pour MCP) Publie sur PyPI ou npm
4. Documente install + usage
5. Demande feedback dans la communauté

## Check

- Repo public avec README clair
- LICENSE en place
- (Si MCP) installable via `uvx`/`npx` en 1 commande
- 1 utilisateur tiers a réussi à l'installer (test avec un ami)

## Piège

Publier en public sans avoir testé l'install fresh. Toujours tester sur une machine vierge avant de pousser comme "v1.0.0 stable".
