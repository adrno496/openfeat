# Module 08 — Maintenance long-terme

**Niveau** : 🟡 — **Durée** : 30 min lecture

## Réalité du long-terme

Construire un skill ou un MCP est facile. Le maintenir 6, 12, 24 mois pendant que :
- Claude Code évolue (breaking changes possibles)
- L'API tierce que tu wraps évolue (déprécations)
- Tes utilisateurs grandissent et exigent plus
- Toi tu as moins de temps

C'est beaucoup plus difficile que la construction initiale.

## Versions Claude Code

Anthropic publie régulièrement des mises à jour. Conséquences possibles :
- Format du `description` skill change → ton triggering devient moins précis
- Format des `tools` change → tu dois adapter les schemas
- Nouveaux modèles → tu dois choisir si tu pin sur l'ancien ou suis le nouveau
- Permissions / hooks API change → tes settings cassent

**Pratique** :
- Lis le CHANGELOG Anthropic à chaque release majeure
- Run tes tests automatiquement contre la dernière version (CI matrix)
- Tag tes versions selon la version Claude Code minimum supportée

## Breaking changes : comment les gérer

### Documenter en amont
Dans ton CHANGELOG, sépare clairement :
```markdown
## [2.0.0] - 2026-XX-XX

### BREAKING CHANGES
- `list_subscriptions` retourne maintenant un objet `{data, total}` au lieu d'un array
- Migration : remplacer `result.length` par `result.total`, `result[i]` par `result.data[i]`
```

### Période de deprecation
Pour les changes pas critiques :
- v1.5 : ajoute le nouveau format
- v1.5 → 1.9 : les deux formats coexistent, ancien marqué `deprecated`
- v2.0 : ancien format retiré

Les utilisateurs ont 3-6 mois pour migrer, pas 0.

### Issue tracker actif
Réponds aux issues GitHub sous 48h. Même si c'est juste "merci, j'en prends note, fix dans 1 semaine".

## API tierces : surveiller les déprécations

Si ton MCP wraps Lemonsqueezy / Stripe / GitHub / etc., tu es sensible à leurs changements.

**Pratique** :
- Subscribe aux annoncements de l'API (mailing list, blog, RSS)
- Test contractuels qui appellent vraiment l'API (au moins 1/semaine en CI)
- Surveille les codes de retour : si tu commences à voir `Sunset` headers ou `X-Deprecated`, tu as ~6 mois

## Support utilisateur

### Niveau gratuit (open source)
- Issues GitHub seulement
- SLA : pas de SLA, "best effort"
- Documentation claire en remplacement du support direct

### Niveau payant (SaaS / pack)
- Email support sous 24-48h
- Discord prioritaire
- Pour les SLA stricts : facture en plus

### Documentation = ton meilleur support
Plus ta doc est claire, moins tu reçois de questions stupides. Investis dans :
- README avec quickstart en 5 min
- FAQ avec les 10 questions les plus fréquentes
- Exemples concrets (pas seulement reference doc)
- Vidéo démo de 2-5 min

Un bon doc divise ton volume de support par 3-5x.

## Métriques à surveiller (si SaaS)

- **Uptime** : % de temps où ton MCP HTTP répond
- **Latence p50, p95, p99** : si p99 > 5s, tu as un souci d'API tierce ou de DB
- **Taux d'erreur** : > 1 % = enquête immédiate
- **MAU** : utilisateurs actifs par mois
- **Churn** : combien partent par mois
- **Top 5 tools les plus utilisés** : focus tes optimisations
- **Top 5 erreurs** : focus tes fixes

Outils : Sentry (erreurs), Plausible/Umami (analytics simples), Grafana + Prometheus (si tu veux du sérieux), Logflare (logs).

## Stratégie d'archivage / sunset

Si un skill ou un MCP n'a plus de sens (API tierce qui ferme, modèle qui change radicalement) :

1. **Annoncer à T-3 mois** : email + bannière README + post X
2. **T-1 mois** : dernier rappel
3. **T-0** : repo archivé (pas supprimé), package marqué `deprecated`
4. **Garder le code accessible** pour ceux qui veulent forker

Ne jamais supprimer brutalement un repo public. Gens utilisent en silence et tu ne le sais pas.

## Le piège de "je vais le maintenir tout seul"

Si tu sors un MCP utilisé par 50+ personnes, tu ne peux pas le maintenir comme un side-project en weekend.

3 stratégies :
1. **Limiter la croissance** : ne pas faire de marketing massif
2. **Monétiser** : avec du revenu, tu peux y passer du temps légitimement
3. **Open-source en équipe** : recruter 1-2 maintainers (dur sur les petits projets)

Le pire scenario : tu maintiens gratuitement, tu craques, tu abandonnes, 50 utilisateurs sont laissés en plan. Évite.

## Anti-patterns

### Ignorer les issues
6 mois sans réponse = tes utilisateurs partent.

### Faire évoluer sans tester chez les utilisateurs
Test interne = pas de test. Beta testers (3-5) = test utile.

### Sur-engineer "au cas où"
Ton MCP n'a pas besoin de gérer 1M req/sec aujourd'hui. Quand tu auras 1k req/sec, optimise.

### Ne pas écouter les utilisateurs
Si 5 personnes te demandent la même feature, c'est un signal. Si 50 → c'est un ordre.

## Démo : process de release sain

Toutes les 2-4 semaines :
```
1. Review issues ouvertes
2. Choisir 3-5 fixes/features pour la release
3. Implémenter sur une branche par item
4. Tests + CI
5. Merge dans main
6. Release-please ou manuel : tag + CHANGELOG + publish
7. Annonce courte sur X/Discord
```

Fréquence régulière > release massive irrégulière.

## Exercice

Pour 1 de tes skills/MCPs publics ou semi-publics :

1. Audit : à quand remonte le dernier commit ? la dernière release ? la dernière réponse à une issue ?
2. CHANGELOG à jour ?
3. README à jour ?
4. Test E2E manuel : install fresh sur machine vierge, ça marche encore ?
5. Plan de maintenance pour les 3 prochains mois

## Check

Tu peux répondre :
- "Quand est la prochaine release prévue ?"
- "Quelle est la doc d'install à jour ?"
- "Quels tests CI tournent automatiquement ?"
- "Comment je sunset si je dois ?"

## Final F3

Tu as construit. Tu sais distribuer. Tu sais monétiser. Tu sais maintenir. Tu es passé du côté builder.

Il te reste à appliquer. Vers F5 si tu veux scaler en agence, F4 si tu veux la finance.
