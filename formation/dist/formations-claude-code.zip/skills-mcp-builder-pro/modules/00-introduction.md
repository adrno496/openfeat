# Module 00 — Introduction

**Niveau** : 🟢 — **Durée** : 15 min lecture

## Builder mindset

Cette formation te fait passer de l'autre côté du miroir. Tu n'es plus consommateur de skills/MCPs. Tu es créateur.

3 différences mentales :
1. **Tu réfléchis API design**, pas juste "ça marche". Un skill mal nommé / mal frontmatter-é = personne ne l'utilise.
2. **Tu réfléchis robustesse**. Un MCP qui crash sur un input edge case te fait perdre la confiance des users en 1 jour.
3. **Tu réfléchis distribution**. Construire pour soi est facile. Construire pour 100 utilisateurs (toi compris dans 6 mois) est différent.

## Ce qu'on va construire

Fil rouge : un **MCP server pour Lemonsqueezy** + un **skill pack Supabase RLS** packagés et publiés.

Au passage : un MCP HTTP authentifié pour usage en équipe, un skill auto-déclenché qui valide les migrations Supabase, un MCP Python pour TradingView (préparation F4 si tu vas vers la finance).

## Comment suivre

- Module 01-02 : skills (côté markdown / IA-friendly)
- Module 03-04 : MCP servers (côté code / robustesse)
- Module 05 : tests + CI
- Module 06-07 : distribution + monétisation
- Module 08 : maintenance long-terme

Tu peux faire 01-04 dans l'ordre. 05-08 sont plus indépendants.

## Engagement

10h de contenu + 10-15h de pratique. Étalées sur 3-4 semaines à raison de 1h/jour.

Sans pratique réelle, tu n'apprendras rien.

## Communauté

Discord builders. Réservé F3. Ambiance "showcase et review entre pros". Si tu n'es pas prêt à montrer ton code et recevoir du feedback, ce n'est pas pour toi.

## Tech requise

- Claude Code installé
- Node 18+ et Python 3.11+
- `uv` (Python) recommandé : `pip install uv`
- Compte GitHub avec Actions
- Compte Anthropic Pro ou Max

## Démarrage

`modules/01-anatomie-skill.md`.
