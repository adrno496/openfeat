# Module 02 — Skills composables avec ressources externes

**Niveau** : 🔴 — **Durée** : 40 min lecture + 20 min pratique

## Théorie

Un skill complexe sans ressources externes devient un mur de markdown de 200+ lignes. Inmaintenable.

La solution : **composer**.

```
.claude/skills/<nom>/
├── SKILL.md                    # Le contrat, < 100 lignes
├── reference/
│   ├── patterns.md             # Patterns de référence
│   └── api-spec.md             # Spec d'une API
├── examples/
│   ├── good-policy.txt         # Exemples positifs
│   └── bad-policy.txt          # Exemples négatifs
└── scripts/
    └── validator.sh            # Script appelable
```

Claude Code charge le `SKILL.md` au triggering. Il **lit les ressources externes à la demande** quand le body les référence.

## Stratégies de découpe

### Ressource "patterns" (référence)

Quand le skill applique un pattern récurrent que tu veux centraliser :

```markdown
# SKILL.md

[...]

## Méthode

Pour chaque table à auditer :
1. Vérifier l'application du `Pattern: user_owns_row` (voir `reference/patterns.md`)
2. Si le pattern n'est pas appliqué, signaler.
```

```markdown
# reference/patterns.md

## Pattern: user_owns_row

```sql
ENABLE RLS;
CREATE POLICY "owner_select" FOR SELECT USING (auth.uid() = user_id);
[...]
```
```

Claude Code chargera `reference/patterns.md` quand il en a besoin, pas avant. Économie de contexte.

### Ressource "examples" (positifs / négatifs)

Pour les skills qui doivent reconnaître un pattern :

```markdown
# SKILL.md

[...]

## Apprendre du contexte

Voir `examples/good-policy.txt` pour des exemples positifs.
Voir `examples/bad-policy.txt` pour des exemples à signaler.
```

Claude Code peut lire les exemples comme reference avant de juger un nouveau cas.

### Ressource "scripts" (action)

Si ton skill appelle un script :

```markdown
## Méthode

1. Lance `scripts/validator.sh <fichier>`
2. Parse la sortie
3. Rapporte
```

```bash
# scripts/validator.sh
#!/bin/bash
FILE=$1
grep -E 'unsafe-inline|unsafe-eval|\*' "$FILE" || echo "OK"
```

Claude Code lance le script via Bash tool. Pratique pour des validations qui ont déjà un outil natif (linters, etc.).

## Re-use entre skills

Tu as 3 skills qui touchent à Supabase. Tu factorises les patterns RLS dans un fichier partagé :

```
.claude/skills/
├── supabase-rls-checker/
│   └── SKILL.md      (référence ../shared/supabase-rls-patterns.md)
├── supabase-migration-reviewer/
│   └── SKILL.md      (référence ../shared/supabase-rls-patterns.md)
└── shared/
    └── supabase-rls-patterns.md
```

Inconvénient : si Claude Code découvre 1 skill et que tu as déplacé l'autre, le chemin relatif peut casser. Préfère la duplication contrôlée à la sur-factorisation pour les ressources critiques.

## Versionning de skill

```markdown
---
name: csp-auditor
description: [...]
version: 1.2.0
---
```

`version` n'est pas un champ standard utilisé par Claude Code mais c'est utile en équipe pour tracer.

À chaque changement majeur du body ou de la structure, incrémente. Dans tes release notes, indique ce qui change pour le triggering vs ce qui change pour le comportement.

## Démo : skill `supabase-rls-checker` complet

```
.claude/skills/supabase-rls-checker/
├── SKILL.md
├── reference/
│   ├── rls-patterns.md
│   └── common-anti-patterns.md
└── examples/
    ├── secure-migration.sql
    └── insecure-migration.sql
```

`SKILL.md` (~80 lignes) référence les autres fichiers. Quand un user invoque "audit RLS sur cette migration", Claude Code :
1. Charge `SKILL.md`
2. Lit la migration cible
3. Lit `reference/rls-patterns.md` pour les standards
4. Lit `examples/secure-migration.sql` si besoin de comparer
5. Rapporte

## Anti-patterns

### Tout dans `SKILL.md`
Body de 300 lignes. Coupe en ressources.

### Trop de ressources
`reference/`, `examples/`, `scripts/`, `templates/`, `data/`, `i18n/`. Un skill qui ressemble à un projet entier est probablement un sub-agent ou un MCP déguisé.

### Ressources non référencées dans le body
Tu as 5 fichiers dans `reference/` mais le `SKILL.md` n'en mentionne aucun. Claude Code ne les lira jamais.

## Exercice

1. Prends un skill existant qui dépasse 100 lignes
2. Identifie 2-3 sections candidates à externaliser (patterns, exemples, scripts)
3. Restructure : `SKILL.md` < 80 lignes, ressources externes
4. Teste : le triggering reste-t-il bon ? Le comportement reste-t-il identique ?

## Check de validation

Tu as au moins 1 skill qui :
- A un `SKILL.md` < 80 lignes
- A 2+ ressources externes
- Référence explicitement les ressources dans le body
- Garde un comportement identique à la version monolithique précédente

## Piège classique

Externaliser des choses critiques (règles dures) dans une ressource, et puis Claude Code ne charge pas la ressource → règles non appliquées. Garde dans le `SKILL.md` ce qui DOIT être lu à chaque trigger.
