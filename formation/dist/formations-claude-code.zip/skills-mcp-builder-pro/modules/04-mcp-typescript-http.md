# Module 04 — MCP TypeScript + transport HTTP avec auth

**Niveau** : 🔴 — **Durée** : 60 min lecture + 30 min pratique

## Théorie

Stdio = local, simple. HTTP = partagé, plus complexe mais nécessaire pour :
- MCP utilisé par toute une équipe (1 serveur, plusieurs devs)
- MCP intégré à une infra existante (déployé en cloud)
- Audit centralisé des invocations

## Architecture HTTP

```
mcp-shared-service/
├── package.json
├── tsconfig.json
├── src/
│   ├── server.ts                # Express + MCP SSE
│   ├── auth.ts                  # Bearer token validation
│   ├── ratelimit.ts             # Rate limiting
│   ├── handlers/                # Tool implementations
│   └── audit.ts                 # Logging
├── Dockerfile                   # Pour déploiement (Fly, Railway, etc.)
└── .env.example
```

## Skeleton Express + MCP SSE

```ts
import express from 'express'
import rateLimit from 'express-rate-limit'
import { Server } from '@modelcontextprotocol/sdk/server/index.js'
import { SSEServerTransport } from '@modelcontextprotocol/sdk/server/sse.js'
import { authMiddleware } from './auth.js'
import { auditLog } from './audit.js'

const app = express()

app.use(rateLimit({ windowMs: 60_000, max: 60 }))
app.use(authMiddleware)

const mcp = new Server({ name: 'shared-service', version: '1.0.0' }, { capabilities: { tools: {} } })

// ... handlers tools/list, tools/call ...

app.get('/sse', async (req, res) => {
  auditLog({ event: 'mcp_connect', user: req.user })
  const transport = new SSEServerTransport('/messages', res)
  await mcp.connect(transport)
})

app.post('/messages', express.json(), async (req, res) => {
  // routing vers le transport actif (le SDK gère)
})

app.listen(3000, () => console.log('MCP HTTP on :3000'))
```

## Auth Bearer

```ts
import type { Request, Response, NextFunction } from 'express'

declare module 'express-serve-static-core' {
  interface Request {
    user?: { id: string; scopes: string[] }
  }
}

const TOKENS_DB: Record<string, { id: string; scopes: string[] }> = {
  // En prod : DB ou OAuth provider, jamais hardcoded
}

export function authMiddleware(req: Request, res: Response, next: NextFunction) {
  const auth = req.headers.authorization
  const token = auth?.replace('Bearer ', '')
  if (!token || !TOKENS_DB[token]) {
    return res.status(401).json({ error: 'unauthorized' })
  }
  req.user = TOKENS_DB[token]
  next()
}
```

Côté client Claude Code :
```json
{
  "mcpServers": {
    "shared-service": {
      "url": "https://mcp.tonsite.com/sse",
      "headers": {
        "Authorization": "Bearer <user_token>"
      }
    }
  }
}
```

## Rate limiting

```ts
import rateLimit from 'express-rate-limit'

app.use(rateLimit({
  windowMs: 60_000,        // 1 minute
  max: 60,                 // 60 requêtes / minute / IP
  standardHeaders: true,
  legacyHeaders: false,
  keyGenerator: (req) => req.user?.id ?? req.ip
}))
```

Sans rate limit, un dev avec un script en boucle peut consommer toute ta quota API tierce en 5 min.

## Audit log structuré

```ts
import { writeFile } from 'fs/promises'

interface AuditEvent {
  ts: string
  event: string
  user?: { id: string }
  tool?: string
  args?: unknown
  duration_ms?: number
  status: 'ok' | 'error'
  error?: string
}

export async function auditLog(event: Partial<AuditEvent>) {
  const entry: AuditEvent = {
    ts: new Date().toISOString(),
    status: 'ok',
    ...event
  }
  // En prod : envoyer à un log aggregator (Loki, Datadog, etc.)
  await writeFile('/var/log/mcp-shared/audit.jsonl', JSON.stringify(entry) + '\n', { flag: 'a' })
}
```

## Déploiement

### Dockerfile minimal

```dockerfile
FROM node:20-alpine
WORKDIR /app
COPY package*.json ./
RUN npm ci --omit=dev
COPY dist/ ./dist/
EXPOSE 3000
CMD ["node", "dist/server.js"]
```

### Hébergeurs simples

- **Fly.io** — `fly launch` puis `fly deploy`
- **Railway** — connect GitHub → auto-deploy
- **Render** — idem Railway
- **Self-host** — VPS Hetzner/OVH + Caddy reverse proxy

Domaine custom + cert Let's Encrypt automatique sur tous ces hébergeurs.

## Sécurité critique

### HTTPS obligatoire en prod
Jamais HTTP. Si tu bypass HTTPS pour dev, désactive l'auth en même temps pour éviter les copier-coller dangereux en prod.

### Tokens : rotation
- Token utilisateur expire en 30j-90j max
- Pas de tokens "long-lived sans expiration"
- Process de révocation immédiate documenté

### Secrets isolés
Toutes les API keys utilisées par les tools sont en variables d'env serveur. Jamais dans le code.

### Validation stricte
Tous les inputs Zod validés. Refuse tout schema non conforme avec un 400 clair.

## Démo : test E2E

Local :
```bash
npm install
npm run build
LEMONSQUEEZY_API_KEY=ls_test_... node dist/server.js
# http://localhost:3000
```

Test côté Claude Code :
```json
{
  "mcpServers": {
    "shared-test": {
      "url": "http://localhost:3000/sse",
      "headers": { "Authorization": "Bearer test_token" }
    }
  }
}
```

## Exercice

1. Forke ton MCP stdio du module 03 (Lemonsqueezy)
2. Ajoute Express + SSE + auth Bearer + rate limit
3. Test localement
4. Déploie sur Fly.io ou Railway (gratuit pour test)
5. Connecte un client Claude Code à ton URL HTTPS

## Check

- HTTPS en prod
- Auth Bearer fonctionne (401 sans token, 200 avec)
- Rate limit fonctionne (60/min testé)
- Audit log se remplit
- Aucun secret dans le code

## Piège

Exposer un MCP HTTP sans auth en prod. Tout le monde peut l'invoquer. Tu te fais drainer ton API tierce en 1h.
