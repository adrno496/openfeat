# Module 01 — Anatomie avancée d'un SKILL.md

**Niveau** : 🟡 — **Durée** : 30 min lecture + 15 min pratique

## Théorie

Un SKILL.md professionnel a 4 sections fonctionnelles :

1. **Frontmatter** — métadonnées (`name`, `description`)
2. **Body** — instructions à Claude Code
3. **Ressources externes** — fichiers complémentaires (`reference/`, `examples/`)
4. **Tests de triggering** — non visibles au runtime mais documentés au build

## Frontmatter optimisé

```markdown
---
name: <slug-stable>
description: <verbe d'action> <objet> <contexte de déclenchement>. Trigger quand l'utilisateur mentionne <X|Y|Z>, édite <patterns>, ou demande <expressions>.
---
```

Règles :
- `name` : kebab-case, pas plus de 30 caractères, stable dans le temps (changer le name casse les références)
- `description` : 200-400 caractères. Trop court = trigger imprécis. Trop long = pollution.
- Inclure **3 à 8 mots-clés** spécifiques au domaine du skill
- Inclure des **patterns de fichier** si applicable (`*.csp`, `supabase/migrations/`)
- Inclure des **expressions naturelles** que l'utilisateur tape ("audit RLS", "vérifie CSP")

### Exemple optimisé

```yaml
description: Audite une politique CSP (Content-Security-Policy) et détecte directives dangereuses (unsafe-inline, unsafe-eval, wildcards). Trigger quand l'utilisateur mentionne CSP, Content-Security-Policy, csp.config, header de sécurité, ou édite un fichier *.csp ou contenant l'expression Content-Security-Policy.
```

8 mots-clés, 2 patterns de fichier, 1 expression naturelle. Le triggering tape juste 9 fois sur 10.

## Body : structurer pour la lecture rapide

Claude Code lit le body pour appliquer le skill. Plus c'est lisible, plus c'est appliqué fidèlement.

```markdown
# <Nom humain du skill>

## Quand t'appliquer
[1-3 cas spécifiques en plus du triggering automatique]

## Méthode
[Étapes numérotées, courtes]
1. ...
2. ...

## Règles dures
[Choses non négociables]

## Format de sortie
[Le format exact attendu, avec exemple]

## Cas où ne PAS appliquer
[Faux positifs courants à exclure]

## Références (optionnel)
Voir `reference/X.md` pour [détail].
```

Sections numérotées et limitées. Pas de prose longue.

## Tests de triggering

À la phase de design, tu écris une **suite de prompts** et tu mesures combien de fois ton skill se déclenche.

```markdown
# tests-triggering.md (non publié, mais utile au dev)

| Prompt | Doit trigger ? | Trigger réel ? |
|---|---|---|
| Audit la CSP de ce site | OUI | ✓ |
| Lis ce fichier csp.config | OUI | ✓ |
| Vérifie les headers de sécurité | OUI | ✓ |
| Crée une fonction de validation | NON | ✓ (n'a pas trigger) |
| Décris ce projet | NON | ✓ (n'a pas trigger) |
```

Tu vises **4/5 minimum sur les "OUI"** et **0/5 sur les "NON"**.

## Démo

Avant (trigger flou) :
```yaml
description: Outil pour CSP
```
Test : trigger 2/5 OUI, 1/5 faux positifs.

Après (trigger optimisé) :
```yaml
description: Audite une politique CSP (Content-Security-Policy) et détecte directives dangereuses (unsafe-inline, unsafe-eval, wildcards). Trigger quand l'utilisateur mentionne CSP, Content-Security-Policy, csp.config, header de sécurité, ou édite un fichier *.csp.
```
Test : trigger 4/5 OUI, 0/5 faux positifs.

L'écart ne se voit pas à l'œil nu mais est massif à l'usage.

## Anti-patterns

### Description marketing
"Le meilleur outil pour gérer CSP." → Claude Code ne s'intéresse pas au superlatif. Il veut des signaux concrets.

### Description par-feature
"Liste les features : analyse, rapport, audit." → trop générique. Liste les triggers, pas les features.

### Body de 300 lignes
À ce stade, tu as un sub-agent caché derrière un skill. Soit tu factorises en ressources externes, soit tu en fais un sub-agent.

## Exercice

1. Choisis un skill que tu as déjà ou que tu veux créer
2. Écris 3 versions de `description` (court, moyen, optimisé)
3. Teste sur 10 prompts (5 qui doivent trigger, 5 qui ne doivent pas)
4. Mesure le ratio. Itère sur la version qui passe le test.

## Check de validation

Tu peux écrire en 15 min un `description` qui obtient ≥ 80 % de triggering correct sur ta suite de tests.

## Piège classique

Optimiser le body avant le frontmatter. Si ton skill ne se déclenche pas, le meilleur body du monde ne sert à rien. Frontmatter d'abord.
