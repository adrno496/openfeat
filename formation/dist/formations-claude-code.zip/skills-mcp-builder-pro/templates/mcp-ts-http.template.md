# Template MCP TypeScript HTTP

## Structure

```
mcp-shared-service/
├── package.json
├── tsconfig.json
├── README.md
├── CHANGELOG.md
├── LICENSE
├── Dockerfile
├── fly.toml                  (si Fly.io)
├── src/
│   ├── server.ts
│   ├── auth.ts
│   ├── ratelimit.ts
│   ├── audit.ts
│   └── handlers/
└── tests/
```

## Dockerfile

```dockerfile
FROM node:20-alpine
WORKDIR /app
COPY package*.json ./
RUN npm ci --omit=dev
COPY dist/ ./dist/
EXPOSE 3000
ENV NODE_ENV=production
CMD ["node", "dist/server.js"]
```

## fly.toml (Fly.io)

```toml
app = "mcp-shared-service"
primary_region = "cdg"

[build]
dockerfile = "Dockerfile"

[env]
PORT = "3000"

[http_service]
internal_port = 3000
force_https = true
auto_stop_machines = true
auto_start_machines = true
min_machines_running = 0
```

## CI

```yaml
name: CI
on: [push, pull_request]
jobs:
  test:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - uses: actions/setup-node@v4
        with: { node-version: '20' }
      - run: npm ci
      - run: npm run build
      - run: npm test
      - run: npx tsc --noEmit
```

## Voir aussi

`_deliverable/mcp-servers/lemonsqueezy-ts/` à la racine pour le code complet (version stdio, à adapter en HTTP avec `auth.ts` et `ratelimit.ts`).
