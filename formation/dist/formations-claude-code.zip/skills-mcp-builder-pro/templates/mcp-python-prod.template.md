# Template MCP Python production-grade

## Structure

```
mcp-mon-server/
├── pyproject.toml
├── README.md
├── CHANGELOG.md
├── LICENSE
├── src/
│   └── mcp_mon_server/
│       ├── __init__.py
│       ├── server.py
│       ├── api.py            # client API
│       ├── models.py         # Pydantic
│       └── logging_config.py
├── tests/
│   ├── test_models.py
│   └── test_api.py
└── .github/
    └── workflows/
        └── ci.yml
```

## pyproject.toml

```toml
[project]
name = "mcp-mon-server"
version = "1.0.0"
description = "MCP server for ..."
requires-python = ">=3.11"
dependencies = [
    "mcp>=1.0",
    "httpx>=0.27",
    "pydantic>=2.0",
    "structlog>=24.0",
]

[project.optional-dependencies]
dev = [
    "pytest>=8.0",
    "pytest-asyncio>=0.23",
    "mypy>=1.10",
]

[project.scripts]
mcp-mon-server = "mcp_mon_server.server:main"

[build-system]
requires = ["hatchling"]
build-backend = "hatchling.build"

[tool.hatch.build.targets.wheel]
packages = ["src/mcp_mon_server"]
```

## Voir aussi

`_deliverable/mcp-servers/lemonsqueezy-py/` à la racine du dépôt formations pour un exemple complet fonctionnel.
