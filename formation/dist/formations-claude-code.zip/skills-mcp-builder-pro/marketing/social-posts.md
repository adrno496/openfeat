# Social Posts — Skills & MCP Builder Pro

10 posts. Ton: pointu, technique, pas de hype.

---

## 1 — X
```
Le frontmatter d'un skill Claude Code, c'est 80% du résultat.

Mauvais : "Outil pour CSP"
Bon : "Audite politique CSP, détecte unsafe-inline, unsafe-eval, wildcards. Trigger quand l'utilisateur mentionne CSP, Content-Security-Policy, csp.config, ou édite *.csp."

Triggering : 5/5 vs 2/5.
```

## 2 — LinkedIn
```
3 mécanismes Claude Code qu'on confond tout le temps :

SLASH COMMAND : invoquée par /commande
SKILL : auto-déclenché selon contexte (frontmatter)
SUB-AGENT : tâche isolée, contexte propre

Mauvais usage = bruit. Bon usage = outil démultiplié.

Builder Pro module 02 fait la cartographie complète. [LIEN]
```

## 3 — X
```
MCP HTTP sans auth en prod = ton API tierce drainée en 1h.

Toujours :
- HTTPS
- Bearer token
- Rate limit (60/min/IP)
- Audit log JSON

Module 04 de Builder Pro. [LIEN]
```

## 4 — LinkedIn
```
3 modèles testés pour monétiser des MCPs :

1. SaaS MCP HTTP (multi-tenant, abonnement)
2. Skill pack licenced (one-shot ou subscription annuel)
3. Custom MCP en consulting (TJM élevé)

Choisir selon profil : solo dev / agence / consultant.

Builder Pro module 07 explique pricing + fiscalité.
[LIEN]
```

## 5 — X
```
Pydantic strict (Python) ou Zod strict (TS) sur tous les inputs MCP.

Pas optionnel. Sans validation :
- Crash en prod sur edge cases
- Stack trace exposé client
- Failles de sécurité
- Maintenance impossible
```

## 6 — LinkedIn
```
Anatomie d'un MCP server production-grade Python :

api.py        client API tierce
models.py     Pydantic input validation
server.py     exposition MCP
logging.py    JSON sur stderr (stdout réservé au protocole)
tests/        pytest unit + golden output
.github/      CI matrix sur 2 versions Python

Pas dans `_one_big_file.py`.

Module 03 Builder Pro. [LIEN]
```

## 7 — X
```
Les 3 commandes pour distribuer ton MCP :

uv build && uv publish              # PyPI
npm publish                         # npm
git tag v1.0.0 && git push --tags  # Release GitHub

Mais avant : LICENSE, README, CHANGELOG. Sinon personne ne trust.
```

## 8 — LinkedIn
```
Ton skill ne se déclenche jamais ?

3 corrections à essayer dans cet ordre :

1. Description trop vague → ajoute 4-8 mots-clés concrets
2. Description trop large → ajoute "Trigger quand l'utilisateur..."
3. Manque de patterns de fichier → ajoute "ou édite *.ext"

Test sur 10 prompts (5 OUI / 5 NON). Vise 4/5 et 0/5.
```

## 9 — X
```
Maintenance long-terme d'un MCP : 80% du vrai travail.

- Versions Claude Code qui changent
- API tierces qui dépréciènt
- Issues utilisateurs à répondre sous 48h
- CHANGELOG à jour
- Sunset annoncé à T-3 mois minimum

Construire est facile. Maintenir est l'épreuve.
```

## 10 — LinkedIn (CTA)
```
Tu veux passer d'utilisateur à builder Claude Code.

Skills MCP Builder Pro. 8 modules avancés. Templates fork-able. Code testé.

Pour devs qui maîtrisent déjà Python ET TypeScript.

[LIEN]
```
