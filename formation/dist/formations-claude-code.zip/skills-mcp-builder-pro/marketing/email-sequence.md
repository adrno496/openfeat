# Email Sequence — Skills & MCP Builder Pro

5 emails. Cible builders avancés.

---

## E1 — J0 — Welcome
**Sujet** : Ton accès Builder Pro

Salut [PRENOM]. Accès : [LIEN]. Discord builders : [LIEN_DISCORD].
Ordre conseillé : 01 → 02 → 03 (ou 04 selon ton langage) → 05 → 06.
[SIGNATURE]

---

## E2 — J+5 — Triggering optimisé
**Sujet** : 4/5 sur tes 10 prompts de test ?

Si tu as fait l'exercice 01, tu as testé ton skill sur 10 prompts. Combien sur "OUI" déclenchent correctement ?
4/5 → tu maîtrises. 2/5 → ton frontmatter manque de mots-clés concrets.

Module 01 te donne le squelette. [LIEN]

---

## E3 — J+12 — Premier MCP
**Sujet** : Ton premier MCP en prod

Modules 03 + 04 te font construire un MCP Python production-grade et sa version TypeScript HTTP authentifiée.

Si tu choisis 1 service que tu utilises au quotidien (Stripe, Lemonsqueezy, GitHub, Linear, Notion), tu peux avoir un MVP fonctionnel en 1 weekend.

Lequel tu choisis ?

[CTA Voir module 03]

---

## E4 — J+25 — Distribution + monétisation
**Sujet** : Tu peux le vendre ?

Tu as construit. Tu utilises. Maintenant : peux-tu en faire un revenu ?

Module 06 (distribution) + 07 (monétisation) couvre 3 modèles testés :
- SaaS MCP HTTP
- Skill pack licenced
- Consulting custom MCPs

Identifie 1 produit, 1 cible, 1 prix avant la fin de la semaine.

[CTA Voir modules 06-07]

---

## E5 — J+45 — Vers F5 / F4 / F2
**Sujet** : Et maintenant ?

Tu as fini Builder Pro. Selon ton profil :
- F5 (Agency Toolkit) si tu veux scaler en agence
- F4 (Quant Macro) si finance/quant
- F2 (Solo Founder Stack) si tu veux ton propre SaaS

Le Discord builders reste ouvert. Show & tell mensuel : montre ton dernier skill ou MCP.

[SIGNATURE]
