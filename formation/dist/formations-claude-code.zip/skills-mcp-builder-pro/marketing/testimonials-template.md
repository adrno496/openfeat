# Testimonials — Skills & MCP Builder Pro

## Email type — J+60 post-complétion

**Sujet** : Tu as publié ?

Salut [PRENOM], 2 mois depuis Builder Pro. Pour aider d'autres devs à se décider :

1. Avant : qu'est-ce qui te bloquait pour passer côté builder ?
2. Maintenant : tu as publié quoi ? (URL si public, ou description si privé) Combien d'utilisateurs ?
3. Recommanderais à quel profil ?

Confirme aussi si je peux utiliser publiquement avec ton nom + lien.

[SIGNATURE]

## Format type

```
"J'ai publié mon premier MCP TypeScript HTTP en 1 weekend après Builder Pro.
12 utilisateurs payants en 2 mois. La formation a couvert exactement ce qui
me manquait : auth Bearer, rate limit, déploiement Fly, distribution npm.
Je recommande à tout dev senior qui veut industrialiser son usage Claude Code."

— [PRENOM] [NOM], [FONCTION] chez [PROJET]
[LIEN_PROFIL]
```

## Critères

- Personne réelle, profil vérifiable
- Produit identifiable (URL, GitHub) si possible
- Chiffres mesurables si applicables (utilisateurs, MRR, etc.)
- Consentement écrit explicite

## Si pas de témoignages

Placeholders `[TÉMOIGNAGE 1]` à `[TÉMOIGNAGE 3]` sur la landing.
