# Landing Page — Skills & MCP Builder Pro

Aucun prix.

---

## Section 1 — Hero

**Headline** :
Construis des skills et des MCP servers que ton équipe (ou tes clients) ne pourront plus quitter.

**Sous-headline** :
Du SKILL.md optimisé au MCP HTTP authentifié déployé en production. La couche avancée Claude Code, en français.

**CTA** : `Accéder à la formation →`

---

## Section 2 — Le problème

Tu utilises des MCPs publics. Ils ne couvrent pas ton besoin métier exact. Tu construits un skill basique, il ne se déclenche pas correctement. Tu lis la doc anglaise sur les MCP servers, tu te perds dans les transports, l'auth, le packaging.

Bref : tu sais qu'il y a un super-pouvoir Claude Code à débloquer, mais tu n'arrives pas à passer côté builder.

---

## Section 3 — La promesse

8 modules approfondis, en français :
- Anatomie SKILL.md (triggering 4-8/5)
- Skills composables (architecture multi-fichiers)
- MCP Python production-grade (Pydantic, structlog, packaging uv)
- MCP TypeScript HTTP authentifié (Express + SSE + auth Bearer + rate limit)
- Tests + CI + versionning sémantique
- Distribution privée / équipe / publique
- Monétisation (SaaS, pack, consulting)
- Maintenance long-terme

À la fin : tu construis et tu déploies un MCP en production en 1 weekend.

---

## Section 4 — Pour qui

- Devs avancés (Python ET TypeScript bases solides)
- Agences IA qui veulent un layer d'outils différenciants
- Équipes tech avec besoins spécifiques non couverts par les MCPs publics
- Tu as fait F1 ou tu maîtrises sub-agents/skills/MCP en pratique

---

## Section 5 — Le programme

01. Anatomie avancée SKILL.md
02. Skills composables (ressources externes)
03. MCP Python production-grade
04. MCP TypeScript HTTP avec auth
05. Tests, versionning, CI
06. Distribution
07. Monétisation
08. Maintenance long-terme
09. Conclusion + plan 60 jours

---

## Section 6 — Ce que tu obtiens

- 8 modules approfondis (~10h)
- 5 exercices avancés + solutions
- Templates fork-able : skill, MCP Python, MCP TypeScript, MCP HTTP, CI YAML
- Repos d'exemple complets dans `_deliverable/mcp-servers/` (Lemonsqueezy, Supabase, GitHub)
- Cheatsheet dense
- Communauté Discord builders (review entre pros)
- Mises à jour à vie

---

## Section 7 — Preuve sociale

[TÉMOIGNAGE 1 — dev senior qui a publié son premier MCP et qui en parle]

[TÉMOIGNAGE 2 — agence qui a différencié son offre client avec MCP custom]

[TÉMOIGNAGE 3 — solo dev qui monétise un skill pack]

---

## Section 8 — FAQ

(Cf. `resources/faq.md`)

---

## Section 9 — CTA final

**Titre** : Passe d'utilisateur à builder.

**Texte** : 8 modules, code testé, templates fork-able, communauté de pros qui montrent leur travail. Le passage de cap qui te transforme en référent Claude Code dans ton domaine.

**CTA** : `Accéder à la formation →`
