# Exercices — Skills & MCP Builder Pro

5 exercices ordonnés. À splitter en fichiers individuels au moment de la prod si besoin.

---

## Exercice 01 — Skill avec triggering optimisé (🟡, 1h)

**Énoncé**
Crée 1 skill projet avec :
- frontmatter optimisé : 4-8 mots-clés concrets, patterns de fichier si applicable
- body structuré (Quand t'appliquer, Méthode, Règles dures, Format de sortie, Cas où ne PAS appliquer)
- 1 ressource externe (`reference/` ou `examples/`)

Tester sur 10 prompts : 5 qui doivent trigger, 5 qui ne doivent pas.

**Critères de réussite** : 4/5 sur "OUI", 0/5 sur "NON".

**Auto-check** :
- [ ] Frontmatter optimisé
- [ ] Ressource externe créée
- [ ] Test triggering effectué et documenté

---

## Exercice 02 — MCP Python production-grade (🔴, 3h)

**Énoncé**
Construis un MCP Python pour un service que tu utilises (Stripe, Lemonsqueezy, GitHub, Notion, Linear).
- 3 tools (2 read, 1 write avec validation Pydantic stricte)
- Architecture clean (api.py, models.py, server.py, logging_config.py)
- Tests pytest sur les models
- Packaging pyproject.toml + install via `uv pip install -e .`
- Test E2E via MCP Inspector

**Critères** : tests passent, install marche, Inspector affiche les 3 tools, aucun secret hardcodé.

**Auto-check** :
- [ ] Architecture en 4+ fichiers
- [ ] Pydantic sur tous inputs
- [ ] 5 tests passent
- [ ] uv pip install -e . marche
- [ ] Inspector OK
- [ ] Aucun secret hardcoded

---

## Exercice 03 — MCP TypeScript HTTP authentifié (🔴, 4h)

**Énoncé**
Convertis ton MCP de l'ex 02 (ou nouveau) en TypeScript + transport HTTP.
- Express + SSE + auth Bearer + rate limit (60/min)
- Audit log JSON
- Validation Zod stricte
- Dockerfile minimal
- Déploiement sur Fly.io ou Railway (gratuit pour test)

**Critères** : URL HTTPS publique, auth fonctionnelle, rate limit testé, audit log se remplit.

**Auto-check** :
- [ ] Déployé en HTTPS public
- [ ] Auth Bearer (401 sans, 200 avec)
- [ ] Rate limit testé (61e requête → 429)
- [ ] Audit log accessible
- [ ] Aucun secret dans le code public

---

## Exercice 04 — CI/CD complet (🔴, 2h)

**Énoncé**
Sur ton MCP de l'ex 02 ou 03 :
- `.github/workflows/ci.yml` qui lance les tests sur push/PR
- 5+ tests unitaires + 2 tests "golden output"
- CHANGELOG.md initialisé
- Tag v1.0.0
- (Optionnel) release-please configuré

**Critères** : CI verte sur main, tag visible sur GitHub.

**Auto-check** :
- [ ] CI passe sur push
- [ ] CI passe sur PR
- [ ] CHANGELOG.md créé
- [ ] Tag v1.0.0 visible
- [ ] (Bonus) release auto via release-please

---

## Exercice 05 — Distribution + onboarding (🟡, 2h)

**Énoncé**
Pour ton MCP/skill :
- README utilisateur clair (1 ligne description, install 1 commande, config copy-paste, 3 exemples, sécurité, license)
- LICENSE (MIT recommandé)
- Test fresh install : sur une machine vierge ou un container Docker, ton README seul permet l'install ?
- (Optionnel) PR sur le registry MCP officiel

**Critères** : un dev tiers (ami / collègue) installe en < 10 min en suivant ton README.

**Auto-check** :
- [ ] README couvre install + config + 3 exemples + sécurité + license
- [ ] LICENSE présent
- [ ] Test fresh install validé
- [ ] (Bonus) PR registry soumise
