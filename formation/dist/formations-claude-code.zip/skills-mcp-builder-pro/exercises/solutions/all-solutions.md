# Solutions — Skills & MCP Builder Pro

Solutions consolidées des 5 exercices.

---

## Solution Ex 01 — Skill avec triggering optimisé

Cf. `_deliverable/skills/csp-auditor/SKILL.md` à la racine du dépôt — exemple complet et fonctionnel d'un skill avec :
- description optimisée (8 mots-clés, 1 pattern de fichier, 1 expression naturelle)
- body structuré (Quand t'appliquer, Méthode, Règles dures, Format de sortie, Cas où NE PAS appliquer)

Test triggering attendu :
- "Audit la CSP de ce site" → trigger ✓
- "Lis ce fichier csp.config" → trigger ✓
- "Vérifie le header Content-Security-Policy" → trigger ✓
- "Crée une fonction de validation" → ne trigger pas ✓
- "Décris ce projet" → ne trigger pas ✓

5/5 attendu sur ce skill bien calibré.

---

## Solution Ex 02 — MCP Python production-grade

Cf. `_deliverable/mcp-servers/lemonsqueezy-py/` à la racine du dépôt :
- `pyproject.toml` complet
- `src/mcp_lemonsqueezy/server.py` avec 3 tools (list_subscriptions, get_customer, monthly_revenue)
- Pydantic sur tous les inputs (`ListSubscriptionsInput`, `GetCustomerInput`)
- Gestion d'erreurs structurée (jamais de stack trace au client)

Tests à ajouter (`tests/test_models.py`) :

```python
import pytest
from mcp_lemonsqueezy.server import ListSubscriptionsInput, GetCustomerInput

def test_status_active_default():
    assert ListSubscriptionsInput().status == "active"

def test_status_invalid():
    with pytest.raises(ValueError):
        ListSubscriptionsInput(status="weird")

def test_limit_too_high():
    with pytest.raises(ValueError):
        ListSubscriptionsInput(limit=200)

def test_customer_id_alphanumeric():
    with pytest.raises(ValueError):
        GetCustomerInput(customer_id="bad/chars$here")

def test_customer_id_valid():
    assert GetCustomerInput(customer_id="cust_123abc").customer_id == "cust_123abc"
```

---

## Solution Ex 03 — MCP TypeScript HTTP

Squelette à partir du `_deliverable/mcp-servers/lemonsqueezy-ts/` (stdio) à convertir en HTTP :

```ts
// src/server-http.ts
import express from 'express'
import rateLimit from 'express-rate-limit'
import { Server } from '@modelcontextprotocol/sdk/server/index.js'
import { SSEServerTransport } from '@modelcontextprotocol/sdk/server/sse.js'

const TOKENS = new Map<string, { id: string }>()
// En prod, charger depuis DB ou OAuth provider
TOKENS.set('test_token', { id: 'test_user' })

const app = express()

app.use(rateLimit({
  windowMs: 60_000,
  max: 60,
  keyGenerator: (req) => req.headers.authorization?.replace('Bearer ', '') ?? req.ip
}))

app.use((req, res, next) => {
  const token = req.headers.authorization?.replace('Bearer ', '') ?? ''
  if (!TOKENS.has(token)) return res.status(401).json({ error: 'unauthorized' })
  next()
})

const mcp = new Server({ name: 'lemonsqueezy-http', version: '1.0.0' }, { capabilities: { tools: {} } })
// ... handlers tools/list, tools/call (réutiliser ceux du stdio) ...

app.get('/sse', async (_req, res) => {
  const transport = new SSEServerTransport('/messages', res)
  await mcp.connect(transport)
})

app.listen(3000, () => console.log('MCP HTTP on :3000'))
```

Dockerfile :
```dockerfile
FROM node:20-alpine
WORKDIR /app
COPY package*.json ./
RUN npm ci --omit=dev
COPY dist/ ./dist/
EXPOSE 3000
CMD ["node", "dist/server-http.js"]
```

Déploiement Fly.io :
```bash
fly launch --no-deploy
fly secrets set LEMONSQUEEZY_API_KEY=ls_...
fly deploy
```

Test :
```bash
curl -X GET https://your-app.fly.dev/sse \
  -H "Authorization: Bearer test_token"
# Doit ouvrir une connexion SSE
```

---

## Solution Ex 04 — CI complet

`.github/workflows/ci.yml` :

```yaml
name: CI
on:
  push:
    branches: [main]
  pull_request:

jobs:
  test:
    runs-on: ubuntu-latest
    strategy:
      matrix:
        python-version: ['3.11', '3.12']
    steps:
      - uses: actions/checkout@v4
      - uses: astral-sh/setup-uv@v3
      - run: uv venv
      - run: uv pip install -e ".[dev]"
      - run: uv run pytest -v
      - run: uv run mypy src/  # bonus type-check
```

Pour TS :
```yaml
jobs:
  test:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - uses: actions/setup-node@v4
        with: { node-version: '20' }
      - run: npm ci
      - run: npm run build
      - run: npm test
      - run: npx tsc --noEmit
```

CHANGELOG.md initial :
```markdown
# Changelog

## [1.0.0] - 2026-XX-XX

### Added
- Initial release
- Tool list_subscriptions
- Tool get_customer
- Tool monthly_revenue
```

Tag :
```bash
git tag v1.0.0
git push --tags
gh release create v1.0.0 --notes "First release"
```

---

## Solution Ex 05 — Distribution

README minimal qui convertit :

```markdown
# MCP Lemonsqueezy

MCP server stdio pour interagir avec Lemonsqueezy depuis Claude Code.

## Install

```json
{
  "mcpServers": {
    "lemonsqueezy": {
      "command": "uvx",
      "args": ["--from", "git+https://github.com/toi/mcp-lemonsqueezy", "mcp-lemonsqueezy"],
      "env": { "LEMONSQUEEZY_API_KEY": "ls_..." }
    }
  }
}
```

## Tools

- `list_subscriptions(status, limit)` — liste les abonnements
- `get_customer(customer_id)` — détail customer
- `monthly_revenue()` — calcule MRR

## Sécurité

- API key via env, jamais hardcoded
- Limit max 50 sur list_subscriptions
- Validation stricte des inputs
- Read-only (aucune mutation)

## License

MIT
```

Test fresh install (sur machine vierge ou container) :

```bash
docker run --rm -it -e LEMONSQUEEZY_API_KEY=ls_test python:3.11 bash -c "
  pip install uv && \
  uvx --from git+https://github.com/toi/mcp-lemonsqueezy mcp-lemonsqueezy --version
"
```

Si ça ressort la version sans erreur : install OK.
