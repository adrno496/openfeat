# Onboarding — Skills & MCP Builder Pro

## DM automatique

```
Salut [PRENOM] et bienvenue chez les builders de Builder Pro.

Niveau attendu : Python OU TypeScript solide, déjà fait F1, déjà construit au moins 1 skill basique.

3 étapes :
1. Lis #règles
2. Présente-toi (format imposé)
3. Engage-toi dans #shipping-this-week

Pour tes questions :
- #questions-anatomie pour modules 01-02
- #questions-mcp-py pour module 03
- #questions-mcp-ts-http pour module 04
- etc.

Pour montrer ton travail : #vos-skills, #vos-mcps, #en-cours-de-construction.

1 fois par mois : show & tell mensuel. 5 min chacun.

Pas de DM directs au créateur — tout passe par les canaux publics.

Build,
[SIGNATURE]
```

## Template "présente-toi"

```
Prénom: [PRENOM]
Stack principale: [Python / TS / autre]
Niveau Claude Code: [N mois d'usage, F1 fait, X skills construits]
MCP/skill en cours: [description courte]
Objectif Builder Pro: [1 ligne, ex: publier mon premier MCP HTTP en prod]

Hâte d'échanger.
```
