# Weekly Prompts — Skills & MCP Builder Pro

12 prompts pour entretenir l'activité.

## S1 — Triggering ratio
"Poste un de tes skills (anonymisé). Indique : nb mots-clés dans description, ratio triggering 5/5 sur tes prompts test."

## S2 — Stack Python vs TypeScript
"Pour MCP : tu as choisi Python ou TS ? Pourquoi ?"

## S3 — Premier déploiement HTTP
"Tu as un MCP HTTP en prod ? Si oui : quel host (Fly, Railway, autre), quel coût mensuel, quels users ?"

## S4 — Auth choisie
"Pour ton MCP HTTP : Bearer simple, OAuth, mTLS ? Pourquoi ?"

## S5 — Tests "golden output"
"Tu utilises golden output testing ? Combien de fixtures ? Combien de fois ils ont attrapé une régression ?"

## S6 — CHANGELOG discipline
"À quand remonte ta dernière update CHANGELOG ? Si c'est > 1 mois, c'est un signal."

## S7 — Premier paying user
"Pour ceux qui monétisent : combien de temps entre publish et premier paying user ? Comment trouvé ?"

## S8 — Maintenance routine
"Décris ton process de release type. Fréquence, étapes, automation ?"

## S9 — Issue tracker
"Combien d'issues ouvertes ? Plus vieille datant de quand ? À quand ton dernier batch fix ?"

## S10 — Sécurité audit
"Audit de sécu sur ton MCP : tokens stockés où, rate limit configuré, rotation prévue ?"

## S11 — Documentation
"Test fresh install : un dev tiers a installé en < 10 min uniquement avec ton README ?"

## S12 — Roadmap 60 jours
"Tes 3 priorités builder pour les 60 prochains jours."

## Notes facilitation

- Lundi matin
- Le créateur poste sa propre réponse en exemple
- 2-3 meilleures réponses mises en avant le vendredi
- Show & tell mensuel synchrone (visio)
