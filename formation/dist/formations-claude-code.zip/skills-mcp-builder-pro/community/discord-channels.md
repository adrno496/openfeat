# Structure Discord — Skills & MCP Builder Pro

Communauté builders. Niveau exigé. Show & tell entre pros.

## 👋 Bienvenue
- `#règles`
- `#présente-toi` (format imposé : projet, stack, MCP/skill en cours)
- `#annonces`

## 🛠 Show & tell
- `#vos-skills` — montre, demande review
- `#vos-mcps` — idem MCP
- `#en-cours-de-construction` — work-in-progress
- `#shipping-this-week` — engagement public

## 📚 Formation
- `#questions-anatomie` (modules 01-02)
- `#questions-mcp-py` (module 03)
- `#questions-mcp-ts-http` (module 04)
- `#questions-tests-ci` (module 05)
- `#questions-distribution` (module 06)
- `#questions-monetisation` (module 07)
- `#questions-maintenance` (module 08)

## 🌐 Pratique
- `#deployment-help` — Fly, Railway, Render
- `#auth-help` — Bearer, OAuth, sécurité
- `#registry-mcp` — préparation soumission registry public
- `#monetisation-feedback` — pricing, copywriting

## 🎯 Show monthly
1 fois par mois : ship retro publique. Chacun montre 5 min ce qu'il a publié.

## Règles
- Niveau attendu : tu sais déployer un Express en HTTPS, lire du Python ET TS
- Pas de DM spam
- Pas de partage du contenu de la formation
- Bienveillance + concision
- Code en blocs Discord ` ``` `
