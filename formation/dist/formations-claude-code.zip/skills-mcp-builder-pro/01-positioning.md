# Positioning — Skills & MCP Builder Pro

## USP

La seule formation FR qui te transforme de **utilisateur** en **builder** d'outillage Claude Code. Du skill optimisé au MCP HTTP authentifié.

## Cible

- Devs avancés (TypeScript ET Python)
- Agences IA qui veulent un layer d'outils différenciants
- Équipes tech avec des besoins spécifiques non couverts par les MCPs publics

## Pas la cible

- Devs qui n'ont jamais créé de skill ou de MCP → fais F1 d'abord
- Solo founders qui veulent juste shipper un SaaS → F2
- Devs qui pensent que tout est dans les MCPs publics → tu n'as pas vu les limites

## Promesse

À la fin :
- Tu construis un skill professionnel (frontmatter optimisé, ressources composées, tests)
- Tu construis un MCP en Python ET en TypeScript, stdio ET HTTP
- Tu maintiens en CI/CD avec versionning sémantique
- Tu distribues (privé/public) et tu monétises (3 modèles testés)
- Tu maintiens en production sur 6+ mois

## Anti-promesse

- On ne te promet pas X €/mois en monétisant tes MCPs (dépend de ton produit et de toi)
- On ne couvre pas en profondeur le SDK Anthropic au-delà du MCP (autre formation)
- On ne fait pas le sales/marketing à ta place

## Format

Très technique. Code testé. Templates fork-able. Repo public d'exemple.
