# Syllabus — Skills & MCP Builder Pro

8 modules. ~10h.

---

## M00 — Introduction
🟢 — 15 min — Pour qui, prérequis, philosophie "builder mindset".

## M01 — Anatomie avancée d'un SKILL.md
🟡 — 45 min — Frontmatter (description optimisée), structure du body, ressources composables, tests de triggering.

## M02 — Skills composables avec ressources externes
🔴 — 60 min — Architecture multi-fichiers, examples/, reference/, scripts inclus, patterns de re-use entre skills.

## M03 — MCP server Python production-grade
🔴 — 90 min — Architecture, tools/resources/prompts, gestion d'erreurs, validation Pydantic, tests, packaging avec uv.

## M04 — MCP server TypeScript + transport HTTP avec auth
🔴 — 90 min — TS + Zod, transport HTTP, OAuth/token, rate limiting, audit logs.

## M05 — Tests, versionning, CI pour skills/MCPs
🔴 — 60 min — Tests unitaires, golden-output testing, semver, release notes, CI GitHub Actions.

## M06 — Distribution : privée, équipe, publique
🟡 — 60 min — Skill packs en repo privé, MCP as a Service, listing public sur registry MCP.

## M07 — Monétisation
🟡 — 45 min — Modèles : SaaS MCP, license skill packs, services consulting. Pricing. Fiscalité.

## M08 — Maintenance long-terme
🟡 — 45 min — Versions Claude Code qui changent, breaking changes, dépréciation, support utilisateur.

## M09 — Conclusion + ouverture
🟢 — 15 min — Récap, plan post-formation, vers F5 si tu veux scale agence.

---

## Total

~10h structuré + 6-10h pratique selon profondeur d'implémentation.
