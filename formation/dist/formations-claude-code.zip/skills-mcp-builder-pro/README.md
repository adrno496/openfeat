# 🛠 Skills & MCP Builder Pro

**Construire des skills réutilisables et des MCP servers custom qui démultiplient ton équipe ou tes clients.**

Couche avancée, pour devs qui maîtrisent déjà Claude Code en utilisation et veulent passer du côté **builder** : créer, packager, distribuer, monétiser.

---

## Pour qui

- Devs avancés qui veulent industrialiser leur usage Claude Code
- Agences IA qui livrent des outils custom à leurs clients
- Équipes tech qui veulent leur propre layer de tools internes

---

## Ce que tu obtiens

- 8 modules approfondis (~10h)
- Skills production-grade (frontmatter optimisé, ressources composées, tests)
- MCP servers Python + TypeScript (stdio + HTTP avec auth)
- Stratégies de distribution (privé, équipe, public, monétisé)
- Templates fork-able (skill, MCP Python, MCP TypeScript)
- Communauté de builders

---

## Prérequis

- Avoir fait F1 (`claude-code-mastery-fr/`) ou maîtriser sub-agents/skills/MCP en pratique
- Bases Python ET TypeScript
- Comprendre le débogage de processus, les transports réseau (HTTPS, OAuth)
- Connaître Git, npm, pip / uv

Si tu ne sais pas ce qu'est un sub-agent ou un skill : passe d'abord par F1.

---

## Structure

Standard formation. Voir `00-syllabus.md`.

---

## Promesse

À la fin :
- Tu construis et tu maintiens des skills qui se déclenchent au bon moment, à 90 %+
- Tu construis et tu déploies des MCP servers stdio (pour toi) et HTTP (pour ton équipe / tes clients)
- Tu sais distribuer (privé, public) et monétiser (skill packs, MCP as a Service)
- Tu testes, tu versionnes, tu maintiens en prod
