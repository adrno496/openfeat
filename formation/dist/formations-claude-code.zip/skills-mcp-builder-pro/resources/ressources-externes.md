# Ressources externes — Skills & MCP Builder Pro

## Documentation officielle

- MCP Specification : `modelcontextprotocol.io`
- MCP TypeScript SDK : `github.com/modelcontextprotocol/typescript-sdk`
- MCP Python SDK : `github.com/modelcontextprotocol/python-sdk`
- Registry MCP : `github.com/modelcontextprotocol/servers`
- Anthropic / Claude Code docs : `docs.anthropic.com`

## Outils

- `uv` — gestionnaire Python moderne (`astral.sh/uv`)
- `release-please` — automation versionning (`github.com/googleapis/release-please`)
- MCP Inspector (`npx @modelcontextprotocol/inspector`)
- Lemonsqueezy (paiements MoR) : `lemonsqueezy.com`
- Fly.io / Railway / Render (hébergement HTTP)

## Hébergement

- **Fly.io** — gratuit pour test, scaling facile
- **Railway** — gratuit avec quota, GitHub auto-deploy
- **Render** — alternative à Railway
- **VPS Hetzner / OVH** — self-host à partir de 4 €/mois

## Lectures recommandées

- Articles Anthropic sur les "agentic workflows"
- Spécification Conventional Commits
- "API Design Patterns" de JJ Geewax (concepts utiles pour les MCPs)
- "Refactoring" de Martin Fowler (pour la maintenance)

## Inspiration : MCP servers publics à étudier

- `mcp-server-filesystem` (officiel) — exemple simple de read/write filesystem
- `mcp-server-github` (officiel) — interaction GitHub complète
- `mcp-server-postgres` — query DB
- Liste à jour : `github.com/modelcontextprotocol/servers`

## Communauté

- Discord officiel Anthropic Developers (canal MCP)
- Discord builders de cette formation (privé)
- Hacker News : recherche "MCP" pour discussions

## Pour aller plus loin

- F1 — Claude Code Mastery FR (référence complète)
- F2 — Solo Founder Stack (appliquer skills/MCPs à un produit complet)
- F4 — Quant Macro (niche finance)
- F5 — AI Agency Toolkit (workflow agence)
