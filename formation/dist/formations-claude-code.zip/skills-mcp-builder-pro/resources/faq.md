# FAQ — Skills & MCP Builder Pro

### Je connais un seul langage (Python OU TS), je peux suivre ?
Oui. Les modules Python (03) et TypeScript (04) sont indépendants. Choisis ton langage. Les principes sont les mêmes.

### Mon skill ne se déclenche jamais. Pourquoi ?
Ton `description` manque de mots-clés concrets. Vise 4-8 mots qui apparaîtraient naturellement dans la phrase de l'utilisateur. Vois `_deliverable/skills/csp-auditor/` pour exemple.

### Mon MCP plante dès le démarrage. Comment debug ?
1. Lance en standalone : `python server.py` ou `node dist/server.js`
2. Si erreur d'env : configure dans `.claude/settings.local.json`
3. Si erreur d'import : `pip install -e .` ou `npm install` raté
4. Sinon : MCP Inspector pour tester chaque tool

### J'ai besoin de skill ET de sub-agent ET de slash command, comment je décide ?
- **Skill** : auto-déclenché par contexte
- **Sub-agent** : tâche isolée, contexte propre
- **Slash command** : invocation explicite, dans la session courante

Tableau complet dans le module 02 de F1.

### MCP HTTP vs stdio, lequel choisir ?
- stdio : usage perso ou local. Setup trivial.
- HTTP : usage partagé (équipe, clients). Plus de complexité (auth, hosting).

Démarrer en stdio, passer à HTTP quand le besoin de partage apparaît.

### Combien je peux gagner en monétisant un MCP ?
Variable. Un MCP utile à 100 utilisateurs à 30 €/mois = 3000 €/mois récurrent. Un MCP custom freelance peut atteindre 5-15 k€ par projet. Un consulting senior, plus.

### Comment je trouve mes premiers utilisateurs ?
- Communauté MCP (Discord, GitHub registry)
- Communautés ciblées (Indie Hackers, Hacker News, Reddit, Discord par domaine)
- Démos vidéo courtes sur X/LinkedIn
- Article de blog qui résout un problème concret

### Mon MCP utilise une API tierce. Si elle change, je casse ?
Oui. Stratégie :
- Test contractuels qui appellent l'API (CI hebdomadaire)
- Surveiller annoncements de l'API (mailing list)
- Versionner ton MCP en parallèle de l'API tierce

### Faut-il connaître Docker pour déployer un MCP HTTP ?
Pas obligatoire avec Fly.io/Railway (ils détectent ton package.json/pyproject.toml). Mais Docker te donne plus de contrôle. Bon à apprendre quand même.

### Je peux faire payer un skill que j'ai construit en 2h ?
Oui, si la valeur générée pour l'utilisateur le justifie. Le temps de construction n'est pas le facteur de pricing. La valeur l'est.

### Garantie de remboursement ?
Cf. CGV.

### Communauté ?
Discord builders. Niveau avancé exigé.
