# Cheatsheet — Skills & MCP Builder Pro

## Anatomie SKILL.md optimal

```yaml
---
name: <kebab-case-stable>
description: <verbe d'action> <objet> <contexte>. Trigger quand l'utilisateur mentionne <X|Y|Z>, édite <patterns>.
---

# Nom humain

## Quand t'appliquer
[cas spécifiques]

## Méthode
1. ...

## Règles dures
- ...

## Format de sortie
[format exact attendu]

## Cas où NE PAS appliquer
- ...

## Références (optionnel)
Voir `reference/X.md`
```

## MCP Python — squelette minimal

```python
from mcp.server.fastmcp import FastMCP
from pydantic import BaseModel, Field

mcp = FastMCP("nom-serveur")

class MyInput(BaseModel):
    arg: str = Field(min_length=1, max_length=64)

@mcp.tool()
def my_tool(arg: str) -> str:
    """Description du tool."""
    parsed = MyInput(arg=arg)  # validation
    return "result"

if __name__ == "__main__":
    mcp.run(transport="stdio")
```

## MCP TypeScript stdio — squelette

```ts
import { Server } from '@modelcontextprotocol/sdk/server/index.js'
import { StdioServerTransport } from '@modelcontextprotocol/sdk/server/stdio.js'
import { z } from 'zod'

const Input = z.object({ arg: z.string().min(1).max(64) })

const server = new Server({ name: 'nom', version: '1.0.0' }, { capabilities: { tools: {} } })

server.setRequestHandler('tools/list', async () => ({
  tools: [{ name: 'my_tool', description: '...', inputSchema: { type: 'object', properties: { arg: { type: 'string' } }, required: ['arg'] } }]
}))

server.setRequestHandler('tools/call', async (req) => {
  const parsed = Input.parse(req.params.arguments)
  return { content: [{ type: 'text', text: 'result' }] }
})

await server.connect(new StdioServerTransport())
```

## MCP HTTP — auth + rate limit minimal

```ts
app.use(rateLimit({ windowMs: 60_000, max: 60 }))
app.use((req, res, next) => {
  const token = req.headers.authorization?.replace('Bearer ', '')
  if (!token || !TOKENS.has(token)) return res.status(401).json({ error: 'unauthorized' })
  next()
})
```

## Tests

```python
# Pydantic / models
def test_invalid():
    with pytest.raises(ValueError):
        MyInput(arg="")
```

```ts
// Zod
test('invalid input', () => {
  expect(() => Input.parse({ arg: '' })).toThrow()
})
```

## Versionning

- v1.0.0 → 1.0.1 : patch (bug fix)
- v1.0.0 → 1.1.0 : minor (nouvelle feature)
- v1.0.0 → 2.0.0 : major (breaking change)

Tag git : `git tag v1.2.0 && git push --tags`

## CHANGELOG.md format

```
## [1.2.0] - 2026-XX-XX

### BREAKING CHANGES
- ...

### Added
- ...

### Changed
- ...

### Fixed
- ...
```

## Distribution

- Privé : `~/.claude/`, dotfiles repo
- Équipe : repo Git avec `.claude/` commité + `setup-claude.sh`
- Public : GitHub + PyPI/npm + registry MCP

## Monétisation

- SaaS MCP HTTP : abonnement, multi-tenant
- Skill pack licenced : one-shot ou subscription annuel
- Consulting : custom MCP au TJM

## Maintenance

- Release toutes les 2-4 semaines
- Réponse issues sous 48h
- CHANGELOG à jour
- Sunset annoncé à T-3 mois minimum

## Anti-patterns

- description vague → trigger raté
- Body 300 lignes → c'est un sub-agent
- Stack trace exposé client → info leak
- secret hardcoded → impardonnable
- MCP HTTP sans auth en prod → drained API tierce
- Pas de CHANGELOG → tu ne sais plus ce qui change
