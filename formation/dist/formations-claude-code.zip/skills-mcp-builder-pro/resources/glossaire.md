# Glossaire — Skills & MCP Builder Pro

**Bearer token** — Token d'authentification placé en header HTTP `Authorization: Bearer <token>`.

**Breaking change** — Modification qui casse la compatibilité avec les versions antérieures. Incrémente le MAJOR (semver).

**CHANGELOG** — Fichier listant les changements par version. Format Keep a Changelog.

**CI (Continuous Integration)** — Pipeline automatique de tests sur chaque push/PR.

**Composable (skill)** — Skill avec ressources externes (`reference/`, `examples/`) plutôt que tout dans `SKILL.md`.

**Conventional Commits** — Format de commit `type(scope): description`. Permet l'automation (release-please).

**Dogfooding** — Utiliser son propre produit en interne avant/pendant la commercialisation.

**Frontmatter** — Section YAML en haut d'un `SKILL.md` ou agent `.md`. Contient `name`, `description`, etc.

**Golden output testing** — Tests qui valident qu'un output reste identique à un fichier de référence stocké.

**HTTP transport (MCP)** — Communication MCP via HTTPS, pour serveurs distants partagés.

**MCP Inspector** — Outil de debug pour tester un MCP server en standalone (`npx @modelcontextprotocol/inspector`).

**MoR (Merchant of Record)** — Service qui joue le rôle de vendeur officiel (ex: Lemonsqueezy). Gère TVA et conformité fiscale.

**Multi-tenant** — Architecture où un même serveur sert plusieurs clients/comptes isolés.

**Pydantic / Zod** — Bibliothèques de validation d'inputs (Python / TS).

**Rate limit** — Limitation du nombre de requêtes par fenêtre de temps.

**Registry MCP** — Index public de MCP servers à l'adresse modelcontextprotocol/servers (GitHub).

**SaaS MCP** — Modèle économique où le MCP server est hébergé et vendu en abonnement.

**Semver (Semantic Versioning)** — MAJOR.MINOR.PATCH.

**SSE (Server-Sent Events)** — Transport HTTP unidirectionnel utilisé par MCP HTTP.

**Stdio transport (MCP)** — Communication MCP via stdin/stdout, pour serveurs locaux.

**Sunset** — Processus de mise en fin de vie d'un produit/service avec annonce préalable.

**Triggering (skill)** — Mécanisme par lequel Claude Code décide d'auto-charger un skill selon le contexte (basé sur `description`).

**uv** — Gestionnaire de paquets Python moderne, remplace pip/Poetry. `pip install uv`.

**uvx** — Lance un package Python directement depuis Git/PyPI sans install préalable.
