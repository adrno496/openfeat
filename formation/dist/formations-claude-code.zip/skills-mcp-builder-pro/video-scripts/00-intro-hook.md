# Script vidéo — Intro hook (≤ 90 sec)

## Plan

### 0:00 — 0:20 — Hook
"Tu utilises Claude Code. Tu utilises peut-être déjà des skills publics. Tu rêves de construire ton propre MCP custom. Mais tu sais pas par où commencer côté builder."

### 0:20 — 0:45 — Solution
"Skills MCP Builder Pro te transforme d'utilisateur en builder. SKILL.md optimisé pour le triggering, MCP Python production-grade, MCP TypeScript HTTP authentifié, distribution, monétisation, maintenance."

### 0:45 — 1:10 — Différenciation
"Pas un cours d'intro. La couche avancée. Code testé. Templates fork-able. Communauté de builders qui montrent leur travail."

### 1:10 — 1:25 — Cible
"Pour devs avancés (Python ET TS), agences IA, équipes tech ambitieuses. Si tu n'as pas fait F1 avant, vise plutôt F1."

### 1:25 — 1:30 — CTA
"[LIEN]"

## Notes tournage
- Plan poitrine, regard caméra
- B-roll : screencast d'un MCP Inspector + déploiement Fly.io
- Pas de musique
