# Scripts vidéo — Skills & MCP Builder Pro (consolidé)

Splitter en fichiers individuels pour la prod si besoin.

---

## 00 — Intro hook (≤ 90 sec)

- "Tu utilises déjà Claude Code. Tu fais des skills basiques. Tu rêves de construire des MCPs custom. Mais tu sais pas par où commencer côté builder."
- "Skills MCP Builder Pro te transforme d'utilisateur en builder. Du SKILL.md optimisé au MCP HTTP authentifié déployé en production."
- "8 modules, 10h de contenu, code testé, templates fork-able."
- CTA.

## 01 — Anatomie SKILL.md (6-8 min)
- Frontmatter optimisé (description, mots-clés)
- Body structuré (5 sections)
- Tests de triggering
- Démo avant/après sur un vrai skill

## 02 — Skills composables (6-8 min)
- Architecture multi-fichiers
- reference/, examples/, scripts/
- Re-use entre skills
- Versionning custom

## 03 — MCP Python production (12-15 min)
- Architecture (api.py, models.py, server.py, logging_config.py)
- Pydantic strict
- Gestion erreurs structurée
- Packaging uv
- Démo install via uvx

## 04 — MCP TS + HTTP (12-15 min)
- Express + SSE
- Auth Bearer
- Rate limit
- Audit log
- Déploiement Fly.io live demo

## 05 — Tests + Versionning + CI (8-10 min)
- pytest / vitest
- Golden output
- Semver + CHANGELOG
- GitHub Actions
- (Bonus) release-please

## 06 — Distribution (8-10 min)
- Privé, équipe, public
- Repo + LICENSE + README
- Registry MCP
- Test fresh install

## 07 — Monétisation (5-6 min)
- 3 modèles : SaaS / pack / consulting
- Pricing
- Fiscalité FR

## 08 — Maintenance (6-8 min)
- Versions Claude Code
- API tierces
- Support utilisateur
- Métriques SaaS
- Sunset

## 09 — Conclusion (3-4 min)
- Récap, plan 60 jours, vers F5/F4/F2

## Notes générales

- Beaucoup de démos terminal + VSCode side-by-side
- Annoter à l'écran les noms de fichiers / endpoints
- Pas de musique pendant les démos techniques
- Sous-titrer FR + EN si possible
