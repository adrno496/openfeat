# FUNNEL-MAP.md

Schéma textuel du funnel des 6 formations.

---

## Vue d'ensemble

```
                          [TRAFIC ENTRANT]
                          (X, LinkedIn, YouTube, SEO)
                                  |
                                  v
                       +----------------------+
                       |  Lead magnet gratuit |
                       |  "Cheatsheet Claude  |
                       |   Code FR" (PDF)     |
                       +----------+-----------+
                                  |
                                  v
                       +----------------------+
                       |  Email welcome (J0)  |
                       +----------+-----------+
                                  |
                                  v
        +-------------------------+--------------------------+
        |                                                    |
        v                                                    v
   [F6 vibe-coding-workflow]                          [Newsletter]
   (produit d'entrée, ticket bas)                     (nurture long-terme)
        |
        | Email J+7 : upsell soft
        v
   [F1 claude-code-mastery-fr]
   (cœur de gamme, référence)
        |
        | Segmenter : profil founder ? freelance ? avancé ? niche finance ?
        |
        +----+--------------+--------------+--------------+
        |    |              |              |              |
        v    v              v              v              v
     [F2]  [F5]          [F3]           [F4]         [Newsletter]
     solo  agency        skills/MCP     quant        (continue)
     founder toolkit     pro            macro
     stack
        |    |              |              |
        +----+              +--------------+
        |                          |
        v                          v
   Bundle Solo Founder        Bundle Quant Lab
   (F6+F1+F2)                 (F1+F3+F4)

```

---

## Logique des paliers

### Palier 0 — Lead magnet
Cheatsheet PDF "Claude Code en français" (extrait de la cheatsheet F1). Capture email, segmente par profil au formulaire (founder / freelance / dev en boîte / quant).

### Palier 1 — F6 (entrée)
Format court (≈ 2h de contenu). Ticket bas. Objectif : prouver la valeur, créer la confiance, rentabiliser le coût d'acquisition.

### Palier 2 — F1 (cœur de gamme)
La référence. Vendue à tous les profils. Format moyen (≈ 8–12h). Objectif : devenir LE produit signature.

### Palier 3 — F2 / F3 / F5 / F4 (spécialisations)
Choix selon profil :
- **F2** si profil "founder/indie hacker" (le plus large)
- **F5** si profil "freelance/agence" (deuxième plus large)
- **F3** si profil "dev avancé / tech lead" (volume plus faible mais LTV élevée)
- **F4** si profil "finance/quant" (volume faible mais LTV très élevée et upsell récurrent)

### Palier 4 — Bundles
Groupages logiques (cf. `BUNDLE-STRATEGY.md`).

---

## Métriques à tracker

- Taux de conversion lead magnet → F6
- Taux de conversion F6 → F1
- Taux de conversion F1 → spécialisation (F2/F3/F5/F4)
- LTV par segment (founder, freelance, dev, quant)
- Taux de complétion par formation (proxy de qualité contenu)
- NPS à J+30 après achat

---

## Cadence email type (à raffiner selon résultats)

- J0 : welcome + livraison lead magnet
- J+1 : valeur pure (article ou snippet utile)
- J+3 : pitch F6 (storytelling)
- J+7 : pitch F6 (preuve sociale)
- J+10 : pitch F6 (objection killer)
- J+14 : reset si pas converti, retour valeur pure
- Une fois F6 acheté : séquence onboarding F6 puis upsell F1 à J+21

Détail des emails dans chaque `marketing/email-sequence.md` par formation.
