# Syllabus — Solo Founder Stack

9 modules. ~8h. Étalés sur 30 jours de ship.

---

## Module 00 — Introduction
🟢 — 15 min — Pourquoi cette stack, ce qu'on va construire, philosophie "ship early".

## Module 01 — Architecture Vanilla JS + Capacitor + Supabase
🟡 — 60 min — Le stack expliqué. Pourquoi pas React. Capacitor pour le mobile. Supabase pour le backend. Coûts réels.

## Module 02 — `CLAUDE.md` production
🟡 — 45 min — Adapter ton `CLAUDE.md` pour shipper vite ET en sécurité. Anti-hallucinations sur la stack.

## Module 03 — Setup Supabase : auth, RLS, schemas
🟡 — 75 min — Setup propre dès le départ. Tables users, profiles, subscriptions. RLS partout. RPC pour les flags premium.

## Module 04 — Frontend Vanilla JS + ES Modules
🟡 — 60 min — Architecture sans bundler. Routing, state, fetch. Composants natifs. Pourquoi ça suffit.

## Module 05 — Mobile avec Capacitor
🟡 — 60 min — Wrapper ton web en app native. Build Android. Permissions. Plugins essentiels.

## Module 06 — Paiements : Lemonsqueezy (web) + RevenueCat (mobile)
🟡 — 75 min — Monétisation dès le J0. Webhooks. Sync subscriptions vers Supabase. Le piège du `is_premium` côté client.

## Module 07 — Déploiement : Vercel + Play Store
🟡 — 60 min — Déploiement web continu (Vercel + Git). Soumission Play Store (manifest, signing, captures, listing).

## Module 08 — Audit sécurité : CSP, XSS, RLS, secrets
🔴 — 60 min — Avant de lancer en public, l'audit minimum. Headers de sécurité, sanitisation, audit RLS, no secrets in client.

## Module 09 — Itération rapide avec Claude Code
🟡 — 45 min — Workflow ship-iterate. Issues GitHub + Claude Code. Petits PR. Rollback facile.

## Module 10 — Conclusion + plan post-ship
🟢 — 15 min — Récap, plan post-launch (rétention, support, croissance).

---

## Total

≈ 8h de contenu. Étalées sur 30 jours, à raison de 30-60 min/jour de contenu + 1-2h/jour de pratique.
