# Testimonials Template — Solo Founder Stack

## Email type — J+45 post-complétion

**Sujet** : Tu as shippé ton SaaS ?

Salut [PRENOM], tu as fini Solo Founder Stack il y a 1.5 mois. Pour aider d'autres founders à se décider, j'aimerais ton retour.

3 questions :

1. **Avant la formation** : qu'est-ce qui te bloquait le plus à shipper ?
2. **Tu as shippé ?** Si oui, quel produit, quel stack, quels chiffres concrets (users, MRR, coût d'infra) ?
3. **À qui tu recommanderais** Solo Founder Stack en une phrase ?

Confirme aussi si je peux utiliser ta réponse publiquement avec ton nom + lien.

[SIGNATURE]

---

## Format de témoignage exploitable (founder-style)

Pour Solo Founder Stack, un bon témoignage met en avant :
- **Produit live** (avec son URL/store)
- **Chiffres concrets** (users, MRR, temps de ship, coût d'infra)
- **Profil** (solo / co-founder, premier SaaS ou pas)

### Exemple type

```
"J'ai shippé [NOM_PRODUIT] sur le Play Store en 32 jours en suivant
Solo Founder Stack. Vanilla JS + Capacitor + Supabase + RevenueCat.
Coût mensuel actuel : 28 €. 47 utilisateurs payants au M+2.
Ce que j'ai gagné : pas perdu 6 mois sur Next + AWS comme mes 2 projets précédents."

— [PRENOM] [NOM], solo founder de [PRODUIT]
[URL_PRODUIT] | [LIEN_LINKEDIN_OU_X]
```

---

## Critères de publication

- Personne réelle
- Produit identifiable et accessible
- Chiffres mesurables (vérifiables si possible)
- Consentement écrit explicite

---

## Si pas encore de témoignages

Placeholders :
```
[TÉMOIGNAGE 1 — founder qui a shippé en 30 jours]
[TÉMOIGNAGE 2 — solo dev qui a abandonné Next]
[TÉMOIGNAGE 3 — focus économies infra]
```

Mieux que d'inventer.

---

## Cas particulier : utiliser TES propres résultats

Si tu as toi-même des produits live, tu peux légitimement citer tes propres chiffres mesurés :

```
"J'ai shippé [NOM_PRODUIT] en [X] jours avec ce stack. [N] mois plus tard :
[X] users actifs, infra à [Y] €/mois, NPS [Z]. Process documenté dans
Solo Founder Stack."
```

C'est de la preuve sociale légitime tant que les chiffres sont **réels et vérifiables**.
