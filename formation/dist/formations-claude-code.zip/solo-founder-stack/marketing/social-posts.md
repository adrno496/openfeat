# Social Posts — Solo Founder Stack

10 posts. Ton: pragmatique, ROI-driven, anecdotes terrain.

---

## Post 1 — X
```
Stack solo founder, testée :
Vanilla JS + Capacitor + Supabase + Vercel + Lemonsqueezy + RevenueCat.

Coût mensuel < 30 € pour les 1000 premiers users.
Auth, paiements web et mobile, deploy continu.

Solo Founder Stack te montre comment shipper un SaaS avec ce stack en 30 jours.
[LIEN]
```

---

## Post 2 — LinkedIn
```
Tu codes ton SaaS depuis 4 mois. Toujours pas live.

Le problème n'est presque jamais ton idée.
Le problème est presque toujours ton stack.

Next + AWS + Stripe direct + RN, ça démarre lentement et ça coûte cher.

Vanilla JS + Capacitor + Supabase + Vercel + Lemonsqueezy + RevenueCat :
- Auth en 30 min
- Paiements web + mobile en 1 journée
- Coût < 30 €/mois pour 1000 users
- 1 codebase pour web + mobile

Solo Founder Stack documente tout. 30 jours pour ship.

[LIEN]
```

---

## Post 3 — X (technique)
```
Le piège #1 sur Supabase :

select('*')

Et tu te retrouves à exposer is_premium, role, internal_notes côté client.

Toujours :
select('id, email, display_name')

Colonnes explicites. Toujours. Sans exception.
```

---

## Post 4 — LinkedIn (anti-React)
```
Pourquoi je n'utilise pas React pour mes SaaS solo :

1. Bundle size : 200-500ko vs ~50ko Vanilla
2. Breaking changes (React 18 → 19 → 20) à gérer
3. Toolchain à maintenir (Vite, bundler, TS config)
4. Compétences moins durables (DOM API, fetch, ES Modules : ne bougent pas)
5. Démarrage instantané sans npm install

Pour 80% des SaaS solo : Vanilla suffit.

Pour 20% (UI très complexe, équipe de 5+) : framework justifié.

Faut savoir où on est avant de choisir.
```

---

## Post 5 — X
```
Règle d'or paiements SaaS solo :

Web → Lemonsqueezy (Merchant of Record, gère TVA UE)
Mobile → RevenueCat (obligatoire pour les abonnements stores)

Pas Stripe direct si tu veux du temps pour coder ton produit.
```

---

## Post 6 — LinkedIn (security)
```
3 trucs à NE JAMAIS faire dans un SaaS Supabase :

1. select('*') → tu exposes des colonnes que tu ne veux pas
2. mutation is_premium côté client → ton produit est gratuit en 30 sec
3. service_key côté client → tout ton DB est compromis

Tous documentés en détail dans Solo Founder Stack module 03 + module 08.

[LIEN]
```

---

## Post 7 — X
```
Capacitor : ton site web devient une app native en 1 commande.

npx cap add android

Tu réutilises ton frontend Vanilla. Tu n'apprends ni Swift ni Kotlin.
Tu publies sur Play Store (25€ une fois).

Pour 95% des SaaS solo : suffisant.
```

---

## Post 8 — LinkedIn (process)
```
Workflow d'itération sur un SaaS post-launch :

Issue → branche → Claude Code → PR → preview Vercel → merge → live.

Cycle attendu : < 1h pour un fix.

Si tu mets 3h sur chaque fix, c'est que tu n'as pas le bon workflow.
Solo Founder Stack module 09 + slash commands custom (cf. F1 module 05).

[LIEN]
```

---

## Post 9 — X
```
Coût mensuel infra pour un SaaS solo founder à 1000 users :

Supabase Pro : 25 $
Vercel Hobby : 0
Lemonsqueezy : variable (5% du CA)
RevenueCat : 0 (jusqu'à 10k MTR)
Domaine : ~1 €
Sentry Free : 0
Analytics privacy-first : 0-9 €

Total fixe : ~25-50 €/mois.
Pas 200, pas 500, pas 2000.
```

---

## Post 10 — LinkedIn (CTA)
```
Tu as l'idée. T'as 30 jours.

Solo Founder Stack te donne le process, le stack, le code testé.
9 modules, 5 exercices, repo template à fork.

Pas de bullshit. Pas de hype framework.

[LIEN]
```
