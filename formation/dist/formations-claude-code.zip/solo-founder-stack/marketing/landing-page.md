# Landing Page — Solo Founder Stack

Aucun prix dans ce fichier.

---

## Section 1 — Hero

**Headline** :
Ship un SaaS production-ready en 30 jours. Sans framework lourd, sans 50 k$ d'infra.

**Sous-headline** :
Stack léger pour solo founder : Vanilla JS + Capacitor + Supabase + Vercel + Lemonsqueezy + RevenueCat.

**CTA** : `Accéder à la formation →`

---

## Section 2 — Le problème

Tu as une idée de SaaS. Tu te lances avec Next + AWS + Stripe direct + un mobile framework cher. 3 mois plus tard, t'as toujours pas un user payant. Et ton infra te coûte 200 €/mois.

L'erreur n'est pas l'idée. L'erreur est le stack.

---

## Section 3 — La promesse

9 modules, 30 jours, un SaaS live :
- Web sur Vercel (déploiement continu)
- Mobile sur Play Store (Capacitor)
- Backend Supabase (auth + RLS + RPC sécurisée)
- Paiements web Lemonsqueezy + mobile RevenueCat
- Audit sécurité complet (CSP, XSS, RLS, secrets)
- Coût mensuel < 30 € pour 1000 users

---

## Section 4 — Pour qui

- Indie hackers, devs solo, founders en bootstrapping
- Niveau dev intermédiaire (JS solide, bases SQL)
- Tu veux une stack durable, pas la mode du moment

**Pas pour toi** :
- Si tu adores ton React/Next/Nuxt et que tu refuses d'en sortir
- Si tu démarres comme dev (vise F6 d'abord)

---

## Section 5 — Le programme

01. Architecture Vanilla JS + Capacitor + Supabase
02. `CLAUDE.md` production
03. Setup Supabase : auth, RLS, RPC sécurisée
04. Frontend Vanilla JS + ES Modules
05. Mobile avec Capacitor
06. Paiements : Lemonsqueezy + RevenueCat
07. Déploiement : Vercel + Play Store
08. Audit sécurité : CSP, XSS, RLS, secrets
09. Itération rapide avec Claude Code
10. Conclusion + plan post-ship

---

## Section 6 — Ce que tu obtiens

- 9 modules + intro + conclusion (~8h)
- 5 exercices avec solutions
- Repo template `solo-founder-stack-starter` à fork
- Templates : `CLAUDE.md`, vercel.json, migrations SQL, Edge Functions
- Cheatsheet imprimable
- Communauté Discord de founders qui shippent
- Mises à jour à vie

---

## Section 7 — Preuve sociale

[TÉMOIGNAGE 1 — founder qui a shippé son SaaS en 30 jours avec ce stack]

[TÉMOIGNAGE 2 — solo dev qui a abandonné Next pour Vanilla et a 3x sa vélocité]

[TÉMOIGNAGE 3 — focus sur les économies d'infra mensuelle]

---

## Section 8 — FAQ

(8-10 vraies objections — voir resources/faq.md)

**Pourquoi pas Next.js ?**
Pour un SaaS solo founder, le poids du framework dépasse le bénéfice. Vanilla démarre plus vite, se maintient plus simplement.

**Lemonsqueezy 5 % c'est cher ?**
Comparé à Stripe oui, mais il gère TVA UE, OSS, factures. Tu économises un comptable spécialisé international.

**Capacitor vs React Native ?**
Capacitor : tu réutilises ton frontend web. React Native : 2 codebases ou tout en RN. Pour solo founder qui ship d'abord en web : Capacitor.

**Combien de temps ?**
8h de contenu. 30 jours de pratique.

**Et si je veux iOS ?**
Capacitor iOS marche aussi. Plus de friction (compte Apple, MacBook). Cette formation focus Android pour démarrer.

**Repo template fourni ?**
Oui, fork-able.

**Garantie de remboursement ?**
Cf. CGV.

---

## Section 9 — CTA final

**Titre** : 30 jours pour ship un SaaS qui rapporte.

**Texte** : Stack léger. Coût d'infra dérisoire. Process testé sur 5 produits live. Communauté de founders qui ne se racontent pas d'histoires.

**CTA** : `Accéder à la formation →`
