# Email Sequence — Solo Founder Stack

7 emails sur 30 jours. Welcome + jalons hebdo + post-launch.

---

## E1 — J0 — Bienvenue + accès

**Sujet** : Ton accès à Solo Founder Stack

Salut [PRENOM], accès ici : [LIEN]. Discord founders : [LIEN_DISCORD].
Module 00 puis 01 aujourd'hui (1h). On démarre.
[SIGNATURE]

---

## E2 — J3 — Repo créé, hello world live ?

**Sujet** : J+3 — ton hello world est live ?

Si tu as suivi : modules 00-01-02 faits, repo créé, "Hello [TON_PROJET]" sur tonsite.fr via Vercel. Si pas encore : reprends module 01.
Le module 03 (Supabase) prend ~2h. Bloque le créneau cette semaine.

---

## E3 — J7 — Auth Supabase

**Sujet** : J+7 — auth Supabase fonctionnelle ?

Tu devrais avoir : tables profiles + subscriptions, RLS, signup/login fonctionnels. Test critique : tente la mutation `is_premium` côté client. Ça doit refuser.
Si oui, tu es dans les temps. Module 04-05 cette semaine (frontend + mobile).

---

## E4 — J14 — Paiements

**Sujet** : J+14 — first dollar is the hardest

Cette semaine : module 06 (paiements). Test E2E : achat avec carte de test, premium activé en DB, vérification de signature.
À J+14, ton SaaS reçoit déjà de l'argent (test). C'est un cap mental énorme.

---

## E5 — J21 — Mobile + sécurité

**Sujet** : J+21 — soumission Play Store interne

Modules 07-08 cette semaine. Soumission interne Play Store + audit sécurité complet. Si tu vises le launch public à J30, c'est maintenant que tu serres les boulons.

---

## E6 — J28 — Pré-launch

**Sujet** : J+28 — checklist pré-launch

Vérifie les 10 points du module 08 (audit sécu). Si 1 case non cochée, tu attends. Mieux vaut launch à J+35 sécurisé qu'à J+30 cassé.
Module 09 (itération) à appliquer dès le J30.

---

## E7 — J35 — Post-launch

**Sujet** : Premier user ?

Comment ça se passe ? Réponds-moi avec :
1. Tu as combien d'inscrits ?
2. Combien de payants ?
3. Quel est ton biggest blocker actuel ?

Je lis tout. Discord pour échanger avec les autres founders.

---

## Notes

- Chaque email pousse à pratiquer, pas à consommer
- Pas plus d'1 CTA par email
- Pas de hype ("incroyable", "secret", "10x")
- Ton tutoyé, direct, "compagnon de route"
