# Module 06 — Paiements : Lemonsqueezy (web) + RevenueCat (mobile)

**Niveau** : 🟡 — **Durée** : 60 min lecture + 30 min pratique

## Théorie

Pour un SaaS web + mobile en 2026 :
- **Web** : Lemonsqueezy (Merchant of Record, gère TVA UE, OSS, conformité)
- **Mobile** : RevenueCat + Google Play / App Store (obligatoire pour les abonnements consommables sur app stores)

Tu **dois** utiliser les paiements natifs du store sur mobile (sinon Apple/Google te suspend). RevenueCat simplifie ça massivement.

## Architecture cible

```
Web user achete           Lemonsqueezy webhook
       ->                       ->
   Lemonsqueezy             Edge Function Supabase
                                 ->
                            UPSERT subscription
                                 ->
                            RPC set_premium_status
                                 ->
                            profiles.is_premium = true

Mobile user achete         RevenueCat webhook
       ->                       ->
   Google Play / App Store  Edge Function Supabase
       ->                       ->
   RevenueCat               UPSERT subscription
                                 ->
                            RPC set_premium_status
                                 ->
                            profiles.is_premium = true
```

Le client ne touche **jamais** `is_premium`. Tout passe par les webhooks.

## Setup Lemonsqueezy

1. Créer un compte sur lemonsqueezy.com
2. Créer une "Store"
3. Créer un produit (subscription) — par exemple "Premium Monthly"
4. Récupérer l'API key et le webhook signing secret (settings)
5. Configurer le webhook : `https://<ton-projet>.supabase.co/functions/v1/lemonsqueezy-webhook`

## Côté frontend web

```js
// src/services/checkout.js
export async function startWebCheckout(userId, productId) {
  // Créer un checkout link via API ou utiliser un lien direct
  const checkoutUrl = `https://tonshop.lemonsqueezy.com/buy/${productId}?checkout[email]=${encodeURIComponent(userEmail)}&checkout[custom][user_id]=${userId}`
  window.location.href = checkoutUrl
}
```

`checkout[custom][user_id]` est crucial : c'est ce qui permettra au webhook de retrouver ton user.

## Edge Function Supabase pour le webhook Lemonsqueezy

```ts
// supabase/functions/lemonsqueezy-webhook/index.ts
import { serve } from 'https://deno.land/std/http/server.ts'
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2'

const SUPABASE_URL = Deno.env.get('SUPABASE_URL')!
const SUPABASE_SERVICE_KEY = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!
const LEMON_SECRET = Deno.env.get('LEMONSQUEEZY_WEBHOOK_SECRET')!

const supabase = createClient(SUPABASE_URL, SUPABASE_SERVICE_KEY)

async function verifySignature(rawBody: string, signature: string): Promise<boolean> {
  const encoder = new TextEncoder()
  const key = await crypto.subtle.importKey(
    'raw',
    encoder.encode(LEMON_SECRET),
    { name: 'HMAC', hash: 'SHA-256' },
    false,
    ['sign']
  )
  const sig = await crypto.subtle.sign('HMAC', key, encoder.encode(rawBody))
  const sigHex = Array.from(new Uint8Array(sig))
    .map((b) => b.toString(16).padStart(2, '0'))
    .join('')
  return sigHex === signature
}

serve(async (req) => {
  const rawBody = await req.text()
  const signature = req.headers.get('X-Signature') ?? ''

  if (!await verifySignature(rawBody, signature)) {
    return new Response('Invalid signature', { status: 401 })
  }

  const payload = JSON.parse(rawBody)
  const eventType = payload.meta.event_name
  const subscription = payload.data
  const userId = payload.meta.custom_data?.user_id

  if (!userId) {
    return new Response('Missing user_id', { status: 400 })
  }

  if (eventType === 'subscription_created' || eventType === 'subscription_updated') {
    await supabase.from('subscriptions').upsert({
      user_id: userId,
      provider: 'lemonsqueezy',
      external_id: String(subscription.id),
      status: subscription.attributes.status,
      product_name: subscription.attributes.product_name,
      current_period_end: subscription.attributes.renews_at
    }, { onConflict: 'provider,external_id' })

    // Si actif, set premium = true
    if (subscription.attributes.status === 'active') {
      await supabase.rpc('set_premium_status', {
        target_user_id: userId,
        new_status: true
      })
    }
  }

  if (eventType === 'subscription_cancelled' || eventType === 'subscription_expired') {
    await supabase
      .from('subscriptions')
      .update({ status: subscription.attributes.status })
      .eq('provider', 'lemonsqueezy')
      .eq('external_id', String(subscription.id))

    await supabase.rpc('set_premium_status', {
      target_user_id: userId,
      new_status: false
    })
  }

  return new Response('OK', { status: 200 })
})
```

Déployer :
```bash
npx supabase functions deploy lemonsqueezy-webhook --no-verify-jwt
```

`--no-verify-jwt` car c'est un webhook public (signed par Lemonsqueezy, pas par auth Supabase).

## Setup RevenueCat (mobile)

1. Créer compte revenuecat.com
2. Créer un projet, lier ton app Android (et iOS si applicable)
3. Configurer les produits (matchent tes IAP Google Play)
4. Récupérer la public SDK key (côté client)
5. Configurer le webhook → `https://<projet>.supabase.co/functions/v1/revenuecat-webhook`

## Côté mobile

```bash
npm install @revenuecat/purchases-capacitor
```

```js
// src/services/purchases.js
import { Purchases } from '@revenuecat/purchases-capacitor'

const REVENUECAT_API_KEY = '...'

export async function initPurchases(userId) {
  await Purchases.configure({ apiKey: REVENUECAT_API_KEY, appUserID: userId })
}

export async function getOfferings() {
  const { offerings } = await Purchases.getOfferings()
  return offerings.current
}

export async function purchase(packageObj) {
  const { customerInfo } = await Purchases.purchasePackage({ aPackage: packageObj })
  return customerInfo
}
```

`appUserID = userId Supabase`. Crucial pour matcher le webhook.

## Edge Function RevenueCat webhook

Similaire à Lemonsqueezy mais avec format RevenueCat.

```ts
// supabase/functions/revenuecat-webhook/index.ts
// (vérification d'auth via header Authorization avec un shared secret RevenueCat)

const event = payload.event
const userId = event.app_user_id  // c'est ton userId Supabase

if (event.type === 'INITIAL_PURCHASE' || event.type === 'RENEWAL') {
  await supabase.from('subscriptions').upsert({...})
  await supabase.rpc('set_premium_status', { target_user_id: userId, new_status: true })
}

if (event.type === 'CANCELLATION' || event.type === 'EXPIRATION') {
  await supabase.rpc('set_premium_status', { target_user_id: userId, new_status: false })
}
```

## Côté client : afficher l'état premium

```js
// Vue dashboard
import { getCurrentProfile } from '../services/auth.js'

const { profile } = await getCurrentProfile()

if (profile.is_premium) {
  showPremiumFeatures()
} else {
  showUpgradeCTA()
}
```

`is_premium` lu depuis `profiles`. Toujours synced via webhooks. Jamais muté côté client.

## Anti-patterns CRITIQUES

### Faire confiance au client pour `is_premium`
Tu te fais voler ton produit en 30 secondes. Toujours côté serveur.

### Stripe direct au lieu de Lemonsqueezy
Stripe direct = tu gères toi-même TVA UE, OSS, factures. Énorme charge. Lemonsqueezy = tu signes en MoR (Merchant of Record), Lemonsqueezy gère tout.

### Faire ses propres paiements mobile
Apple/Google bannissent les apps qui contournent leur in-app purchase pour des contenus consommables. Toujours RevenueCat.

### Webhook sans vérification de signature
N'importe qui peut t'envoyer un faux webhook et te faire upgrader des users. Toujours vérifier la signature.

## Démo

Test E2E web :
1. Lance edge function Supabase localement (`supabase functions serve lemonsqueezy-webhook`)
2. Use ngrok pour exposer en HTTPS
3. Configure webhook Lemonsqueezy vers ton URL ngrok
4. Achète depuis ton site (mode test Lemonsqueezy)
5. Vérifie : `subscriptions` row inserted, `profiles.is_premium = true`

## Exercice

1. Configure Lemonsqueezy avec un produit subscription test
2. Code et déploie l'Edge Function `lemonsqueezy-webhook`
3. Test E2E : achat → webhook → DB updated → UI show premium
4. (Optionnel mobile) Setup RevenueCat avec produit test, même flow

## Check de validation

Tu as :
- Webhook Lemonsqueezy déployé avec vérification signature
- Test E2E qui passe : achat → premium activé
- `is_premium` ne peut pas être muté côté client
- Subscriptions correctement upsertées (pas de doublons)

## Piège classique

Oublier de mettre `--no-verify-jwt` au déploiement de l'edge function webhook. Le webhook arrive sans JWT user, donc Supabase le rejette en 401, et tu ne comprends pas pourquoi rien ne marche.
