# Module 10 — Conclusion et plan post-ship

**Niveau** : 🟢 — **Durée** : 15 min lecture

## Récap

Tu as construit (ou tu as la méthode pour construire) :
- App web Vanilla JS sur Vercel
- App mobile Capacitor sur Play Store
- Backend Supabase avec auth + RLS + RPC sécurisée
- Paiements web (Lemonsqueezy) + mobile (RevenueCat)
- Audit sécurité complet (CSP, XSS, RLS, secrets)
- Workflow d'itération rapide

Coût mensuel : < 30 € pour les 1000 premiers users.

## Plan J+30 à J+90

### J+30 à J+45 — Conversion
Tu as quelques users. Mesure le funnel :
- Visites → signup : ratio acceptable ?
- Signup → premier login J+1 : retention ?
- Premier login → première feature payante : intent ?
- Intent → paiement : friction ?

Bouge le levier le plus pourri. Pas tous en même temps.

### J+45 à J+60 — Rétention
Première rétention à mesurer : J+7 et J+30.
- D7 < 30 % → ton produit n'a pas trouvé son utilisateur idéal
- D7 30-50 % → tu as quelque chose, optimise
- D7 > 50 % → tu as un produit, scale

### J+60 à J+90 — Croissance
Une fois conversion + rétention OK :
- Mécanismes de growth (referral, partage social, content marketing)
- SEO si pertinent
- Partenariats / affiliation

## Anti-patterns post-ship

### Coder de nouvelles features avant que les actuelles ne convertissent
Tu construis un produit "complet" sans utilisateurs. Erreur classique.

### Comparer ses chiffres à ceux des autres SaaS
Chacun a son contexte. Compare-toi à toi-même semaine après semaine.

### Refondre l'archi parce que "ça grossit"
Vanilla + Supabase tient à 10 000 users actifs. Avant ce seuil, ne change rien.

### Hire trop tôt
Hiring divise ta vélocité avant de la multiplier. Garde-toi solo le plus longtemps possible avec Claude Code.

## Vers où aller ensuite

### Si tu veux construire la machine de scaling
F5 — `ai-agency-toolkit/` — workflow client, refactor à grande échelle.

### Si tu veux ajouter des super-pouvoirs custom
F3 — `skills-mcp-builder-pro/` — créer des MCP servers pour ton SaaS et ceux de tes clients.

### Si tu veux la finance/quant
F4 — `claude-code-quant-macro/` — automatiser la macro et les backtests.

### Si tu veux maîtriser tout Claude Code
F1 — `claude-code-mastery-fr/` — la référence (à faire en parallèle si pas encore fait).

## Final

Ship c'est 30 jours. Faire grandir, c'est 3 ans.

L'avantage du solo founder : tu décides chaque jour. Pas de réunion, pas de roadmap signée par un comité.

L'inconvénient : tu décides chaque jour. Si tu n'es pas honnête avec toi-même sur ce qui marche, tu te mens 3 ans.

Reviens toutes les semaines à la question : qu'est-ce que **les users** disent ? Pas qu'est-ce que tu **penses** que les users disent.

Bon ship.
