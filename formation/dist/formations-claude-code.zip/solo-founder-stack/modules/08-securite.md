# Module 08 — Audit sécurité : CSP, XSS, RLS, secrets

**Niveau** : 🔴 — **Durée** : 45 min lecture + 30 min pratique

## Théorie

Avant le J30, audit sécurité minimum sur 5 axes :
1. CSP en prod (pas de unsafe-inline ni unsafe-eval)
2. XSS prévenue côté client (échappement systématique)
3. RLS Supabase auditée
4. Secrets isolés (rien côté client, rien dans repo)
5. Webhook signatures vérifiées

Une faille sur un de ces 5 = ton SaaS peut être détourné en quelques heures.

## CSP en prod

Dans `vercel.json` (déjà vu module 07) :

```json
"Content-Security-Policy": "default-src 'self'; script-src 'self' https://esm.sh; style-src 'self' 'unsafe-inline'; connect-src 'self' https://*.supabase.co; img-src 'self' data: https:; frame-ancestors 'none';"
```

**Audit** :
- `default-src 'self'` → blocs par défaut tout sauf ton domaine
- `script-src` ne contient PAS `'unsafe-inline'` ni `'unsafe-eval'` → XSS via `<script>` injecté impossible
- `style-src` peut contenir `'unsafe-inline'` (souvent nécessaire pour les libs)
- `connect-src` : seulement Supabase
- `frame-ancestors 'none'` : protège contre clickjacking

**Tester** : `curl -I https://tonsite.fr` → vérifier le header. Ou ouvrir DevTools → Network → Headers.

**CSP report-only** pour itérer sans casser :
```
Content-Security-Policy-Report-Only: ...; report-uri /csp-report
```
Tu logges les violations, tu corriges, puis tu actives en mode strict.

## XSS prévention

### Toujours échapper avant innerHTML
```js
// MAUVAIS
element.innerHTML = `<p>${userInput}</p>`

// BON (option 1) : textContent
element.textContent = userInput

// BON (option 2) : escapeHtml + innerHTML
import { escapeHtml } from './utils/escape.js'
element.innerHTML = `<p>${escapeHtml(userInput)}</p>`
```

### Pas d'inline event handlers
```html
<!-- MAUVAIS -->
<button onclick="doSomething(${userId})">Click</button>

<!-- BON -->
<button data-action="do-something" data-user-id="${userId}">Click</button>
<script>
document.addEventListener('click', (e) => {
  if (e.target.dataset.action === 'do-something') {
    doSomething(e.target.dataset.userId)
  }
})
</script>
```

### URLs externes : valider le scheme
```js
function safeOpenUrl(url) {
  try {
    const u = new URL(url)
    if (u.protocol !== 'https:' && u.protocol !== 'http:') return false
    window.open(u.toString(), '_blank', 'noopener,noreferrer')
    return true
  } catch {
    return false
  }
}
```

Sans validation, un `javascript:alert('xss')` peut s'exécuter.

## Audit RLS

Pour chaque table publique, vérifier :
1. RLS activé : `SELECT relname, relrowsecurity FROM pg_class WHERE relrowsecurity = false AND relkind = 'r' AND relnamespace = (SELECT oid FROM pg_namespace WHERE nspname = 'public');`
2. Au moins une policy SELECT (sinon table inaccessible)
3. Aucune policy avec `USING (true)` non-conditionné
4. Les flags critiques (`is_premium`, `role`, `is_admin`) ne sont pas updatable côté client

### Script d'audit

```sql
-- Tables publiques sans RLS
select schemaname, tablename
from pg_tables
where schemaname = 'public'
and tablename not in (
  select c.relname
  from pg_class c
  where c.relrowsecurity = true
);

-- Policies trop permissives
select schemaname, tablename, policyname, cmd, qual, with_check
from pg_policies
where schemaname = 'public'
and (qual like '%true%' or with_check like '%true%');
```

Toute policy retournée doit être justifiée.

## Secrets

### Côté client (jamais)
- Pas de service_key Supabase
- Pas de webhook signing secret
- Pas de clé API tierce avec scope écriture

### Côté Edge Function (oui)
Variables d'env Supabase Functions :
```bash
npx supabase secrets set SUPABASE_SERVICE_ROLE_KEY=...
npx supabase secrets set LEMONSQUEEZY_WEBHOOK_SECRET=...
npx supabase secrets set REVENUECAT_WEBHOOK_AUTH=...
```

### Audit du repo

```bash
# Chercher secrets en clair dans le repo
git log -p | grep -iE 'sk_live_|service_role|api_key|password' | head

# Tools utiles
brew install gitleaks
gitleaks detect --source . -v
```

### `.gitignore` minimum

```
.env
.env.*
!.env.example
.claude/settings.local.json
android/release.keystore
android/local.properties
node_modules/
```

## Webhook signatures

Déjà couvert au module 06. Récap :
- Lemonsqueezy : header `X-Signature` (HMAC SHA-256 du body avec secret partagé)
- RevenueCat : header `Authorization` avec un token shared

Toujours vérifier AVANT toute logique métier.

```ts
if (!await verifySignature(rawBody, signature)) {
  return new Response('Invalid signature', { status: 401 })
}
// puis ensuite la logique
```

## Audit final pré-launch (checklist)

Avant ton premier user payant :

- [ ] CSP active en prod, sans unsafe-eval
- [ ] Tous les inputs utilisateur échappés ou avec textContent
- [ ] Aucun innerHTML avec données externes non sanitisées
- [ ] RLS activé sur toutes les tables publiques
- [ ] Aucune policy `USING (true)` injustifiée
- [ ] `is_premium` non updatable côté client (testé)
- [ ] Variables client : aucun secret
- [ ] Variables Edge Functions : secrets configurés
- [ ] Webhook signatures vérifiées
- [ ] HTTPS partout (Vercel le fait, vérifier sur tonsite)
- [ ] `.gitignore` correct
- [ ] `gitleaks` clean sur le repo
- [ ] Captcha anti-spam sur signup (sinon ton DB se remplit de bots)

## Démo : test "is_premium côté client bloqué"

```js
// Dans la console du navigateur, sur ton app en prod
const { data, error } = await supabase
  .from('profiles')
  .update({ is_premium: true })
  .eq('id', currentUser.id)

console.log(error)  // Doit avoir une erreur RLS ("new row violates check constraint")
console.log(data)   // Doit être null/empty
```

Si la mise à jour passe, ta RLS est mal configurée.

## Exercice

1. Active CSP en prod (vercel.json)
2. Audit XSS : grep tous les `innerHTML` du projet, vérifie échappement
3. Run le script SQL d'audit RLS, corrige les anomalies
4. `gitleaks detect` sur le repo
5. Test E2E : tente de muter `is_premium` depuis la console, vérifie que ça bloque

## Check de validation

7 checks de la checklist au moins.

## Piège classique

"Je sécuriserai après le J30, là je veux ship". Une fois en prod avec users, tu ne pourras plus jamais te permettre de retravailler la sécurité tranquillement. Fais-le AVANT le launch public.
