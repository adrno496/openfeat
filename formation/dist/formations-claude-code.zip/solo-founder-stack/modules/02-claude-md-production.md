# Module 02 — `CLAUDE.md` production

**Niveau** : 🟡 — **Durée** : 30 min lecture + 15 min pratique

## Théorie

Un `CLAUDE.md` "ship vite + sécurité" diffère d'un `CLAUDE.md` "exploration de poc". Pour un SaaS qui va recevoir de l'argent réel, il faut des règles dures.

## Le squelette type pour un SaaS Vanilla + Supabase

```markdown
# CLAUDE.md

## Stack
- Frontend : Vanilla JS (ES Modules natifs, pas de bundler)
- Mobile : Capacitor 6
- Backend : Supabase (Postgres + Auth + Storage + Edge Functions)
- Paiements : Lemonsqueezy (web) + RevenueCat (mobile)
- Hébergement web : Vercel
- Hébergement mobile : Play Store (Android)

## Conventions code
- Indentation 2 espaces, quotes simples, sans point-virgule
- ES Modules natifs, pas de require, pas de bundler
- Pas de framework JS (React, Vue, etc.) ajouté
- Tests : Vitest pour utils, Playwright pour e2e
- HTML strict (pas de inline-styles, pas de inline-handlers)

## Règles métier non-négociables
- is_premium muté UNIQUEMENT via RPC `set_premium_status` côté serveur
- Toute table publique a RLS activé
- Aucun select('*') sur Supabase, toujours colonnes explicites
- Les abonnements mobile passent par RevenueCat → webhook → Supabase
- Les abonnements web passent par Lemonsqueezy → webhook → Supabase
- Pas de modification directe de subscription côté client

## Sécurité
- CSP strict en prod (ni unsafe-inline ni unsafe-eval)
- Sanitize tout input utilisateur avant insert DB
- innerHTML interdit avec données utilisateur, utiliser textContent
- Variables d'env client (`PUBLIC_*` ou équivalent) ne contiennent pas de secret
- Service key Supabase utilisée seulement côté serveur (Edge Function)

## Trucs à ne pas faire
- Pas de require, pas de bundler, pas de framework JS
- Pas de select('*') Supabase
- Pas de mutation is_premium côté client
- Pas de innerHTML avec input utilisateur
- Pas de secret en variable d'env client
- Pas de TODO commenté en prod, créer une issue

## Commandes utiles
- `npm run dev` — serveur local (npx serve public/)
- `npm run build` — build prod (copie + minif si besoin)
- `npm run cap:android` — build Android via Capacitor
- `npx supabase db reset` — reset DB locale
- `npx supabase migration new <nom>` — nouvelle migration
- `npx supabase functions deploy <fn>` — déployer edge function
```

## Pourquoi cette structure

- **Stack** : Claude Code sait dans quel monde on est
- **Conventions code** : standards techniques
- **Règles métier non-négociables** : ce qui touche à l'argent (le plus critique)
- **Sécurité** : ce qui peut planter ton SaaS si oublié
- **Trucs à ne pas faire** : raccourcis dangereux à empêcher
- **Commandes utiles** : Claude Code peut les suggérer plutôt que réinventer

## Anti-patterns spécifiques au "ship rapide"

### "On verra plus tard pour la sécurité"
Non. Tu ajoutes maintenant ou jamais. Ajoute dans `CLAUDE.md` les règles dures dès le J0.

### "Claude Code va proposer le bon frontend, je verrai"
Si tu ne dis pas explicitement "Vanilla JS, pas de framework", il va proposer du React 9 fois sur 10 (vu la fréquence dans les datasets). Sois explicite.

### Oublier la dimension mobile
Si tu vas sur Capacitor, mentionne-le dès le `CLAUDE.md`. Sinon Claude Code va proposer des features web qui cassent en mobile (target="_blank" qui ouvre rien, popups bloqués, etc.).

## Démo

Avant (ce que tu aurais probablement) :
```markdown
# Mon SaaS
Stack moderne. Code propre. Tests obligatoires.
```

Après (ce que tu dois avoir) :
```markdown
# CLAUDE.md
[80 lignes structurées comme ci-dessus]
```

Différence à l'usage : plus de propositions de "rajoutons axios", plus de `select('*')` accidentel, plus de mutations `is_premium` côté client.

## Exercice

1. Crée le `CLAUDE.md` complet pour TON projet en suivant le squelette
2. Adapte les sections "Règles métier" à ton domaine
3. Test : demande à Claude Code "Crée la fonction de paiement" — vérifie qu'il propose une architecture conforme

## Check de validation

Tu as un `CLAUDE.md` qui :
- Mentionne tous les composants de ta stack
- Liste au moins 3 règles métier non-négociables
- A une section sécurité avec au moins 5 règles
- Fait moins de 100 lignes au total

## Piège classique

Mettre un `CLAUDE.md` parfait à J0 puis ne plus le toucher. Ton produit évolue, ton `CLAUDE.md` aussi. Audit toutes les 2 semaines.
