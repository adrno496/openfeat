# Module 00 — Introduction

**Niveau** : 🟢 — **Durée** : 15 min lecture

## Pourquoi cette stack

Cette stack a fait ses preuves sur plusieurs SaaS solo founders : Vanilla JS + Capacitor + Supabase + Vercel + Lemonsqueezy + RevenueCat.

Pas par contrarianisme. Pour 5 raisons :
1. **Vitesse de boot d'un projet** : 0 install de framework, ouvert dans le browser
2. **Pas de breaking change** : ES Modules natifs, ça ne bouge pas
3. **Compétences transférables** : ce que tu apprends marche en 2030 comme en 2026
4. **Coût infra** : Supabase Free tier + Vercel Hobby = $0 jusqu'à plusieurs centaines d'users
5. **Mobile sans Apprendre Swift/Kotlin** : Capacitor wrappe ton web en natif

## Ce qu'on va shipper ensemble

Cette formation suit un projet fictif : un SaaS de gestion de quotes (citations) pour entrepreneurs. Auth, abonnement premium, app mobile, paiements web et mobile.

Chaque module ajoute une brique. À la fin : produit complet, déployé, vendable.

Tu peux suivre avec ce projet ou avec ton propre projet. La structure marche pareil.

## Philosophie "ship early"

- **J0** : repo créé, hello world déployé sur Vercel
- **J3** : auth Supabase fonctionne
- **J7** : 1ère feature métier live
- **J14** : paiement web fonctionnel
- **J21** : version mobile sur Play Store (interne en bêta)
- **J30** : 1er user payant ou en bêta payante

L'objectif n'est PAS de ship parfait. L'objectif est de ship.

## Engagement

30 minutes à 2 heures par jour pendant 30 jours. Si tu ne peux pas tenir ce rythme, attends d'avoir le temps. Cette formation n'est pas pour les "je verrai quand j'aurai 5 minutes".

## Communauté

Discord de founders qui shippent. Pas de discussions sur les frameworks à la mode, les architectures parfaites, ou les théories. Tu shippe ou tu ne shippes pas.

## Tech requise

- Compte Anthropic (Pro ou Max)
- Node 18+ et Git
- Compte Supabase (gratuit)
- Compte Vercel (gratuit)
- Compte Lemonsqueezy (gratuit, fee à la transaction)
- Compte Google Play Console (~25 $ une fois) si tu veux mobile

## Démarrage

`modules/01-architecture.md`. Tu vas comprendre pourquoi cette stack avant de l'écrire.
