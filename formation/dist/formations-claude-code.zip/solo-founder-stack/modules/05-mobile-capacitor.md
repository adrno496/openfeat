# Module 05 — Mobile avec Capacitor

**Niveau** : 🟡 — **Durée** : 45 min lecture + 30 min pratique

## Théorie

Capacitor wrappe ton site web dans une app native. Tu prends ton dossier `public/`, tu le packages avec Capacitor, tu obtiens un `.apk` Android (ou `.ipa` iOS).

Avantages :
- Tu réutilises ton frontend Vanilla
- Tu n'apprends ni Swift ni Kotlin
- Tu gardes une seule codebase (web + mobile)

Limites :
- Performance UI native légèrement inférieure à du Swift/Kotlin pur
- Animations natives moins fluides que React Native
- Suffisant pour 95 % des apps SaaS / utilitaires

## Setup

```bash
npm install -D @capacitor/cli
npm install @capacitor/core @capacitor/android
npx cap init "Mon SaaS" "com.tonentreprise.monsaas" --web-dir=public
npx cap add android
```

`com.tonentreprise.monsaas` est ton **bundle ID**. Ne change jamais après publication Play Store, c'est l'identifiant unique.

## `capacitor.config.ts`

```ts
import type { CapacitorConfig } from '@capacitor/cli'

const config: CapacitorConfig = {
  appId: 'com.tonentreprise.monsaas',
  appName: 'Mon SaaS',
  webDir: 'public',
  android: {
    buildOptions: {
      keystorePath: 'release.keystore',
      keystoreAlias: 'release-key',
      releaseType: 'AAB'
    }
  },
  server: {
    androidScheme: 'https'  // important pour cookies/storage
  }
}

export default config
```

## Build & test Android

```bash
# Sync : copier ton public/ dans le projet Android
npx cap sync android

# Ouvrir Android Studio
npx cap open android

# Build → Run → APK installé sur émulateur ou device USB
```

## Plugins essentiels

### Browser (ouvrir un lien externe proprement)
```bash
npm install @capacitor/browser
```
```js
import { Browser } from '@capacitor/browser'
await Browser.open({ url: 'https://example.com' })
```

Pourquoi : `<a href="..." target="_blank">` ne marche pas en native. Toujours utiliser le plugin Browser.

### Preferences (stockage clé-valeur)
```bash
npm install @capacitor/preferences
```
```js
import { Preferences } from '@capacitor/preferences'
await Preferences.set({ key: 'theme', value: 'dark' })
const { value } = await Preferences.get({ key: 'theme' })
```

Préfère ça à `localStorage` en mobile (plus fiable, persistant à travers updates).

### App (états de l'app, deep linking)
```bash
npm install @capacitor/app
```
```js
import { App } from '@capacitor/app'
App.addListener('appStateChange', ({ isActive }) => {
  if (isActive) refreshData()
})
```

## Permissions Android

Dans `android/app/src/main/AndroidManifest.xml`, ne demande **que** ce dont tu as besoin :

```xml
<uses-permission android:name="android.permission.INTERNET"/>
<!-- internet seulement, sauf besoin spécifique -->
```

Chaque permission demandée = friction à l'install. Si ton app ne fait pas du push, ne demande pas POST_NOTIFICATIONS. Si pas de caméra, ne demande pas CAMERA.

## Différences web vs mobile à gérer

### Cookies tiers / sessions
Sur Android, certains schemes posent problème. Avec `androidScheme: 'https'` ça simplifie.

### Liens externes
Pas de `target="_blank"`. Plugin Browser obligatoire.

### Géolocalisation
Plugin `@capacitor/geolocation` + permission Android.

### Push notifications
Plugin `@capacitor/push-notifications` + Firebase Cloud Messaging. Lourd à setup, ne fais qu'au moment où tu en as VRAIMENT besoin.

### Statusbar
Plugin `@capacitor/status-bar` pour cohérence visuelle.

## Build de release Android

```bash
# Générer la keystore (une seule fois, à backuper précieusement)
keytool -genkey -v -keystore release.keystore -alias release-key \
  -keyalg RSA -keysize 2048 -validity 10000

# Build le bundle (.aab) pour Play Store
npx cap sync android
cd android
./gradlew bundleRelease
```

Le `.aab` se trouve dans `android/app/build/outputs/bundle/release/`.

⚠️ **La keystore doit être sauvegardée**. Si tu la perds, tu ne peux plus mettre à jour ton app sur le Play Store, jamais. Stockage chiffré + backup secondaire.

## Démo

Setup complet, première app installable :

```bash
mkdir mon-saas && cd mon-saas
mkdir public
echo '<!doctype html><html><body><h1>Hello mobile</h1></body></html>' > public/index.html
npm init -y
npm install -D @capacitor/cli
npm install @capacitor/core @capacitor/android
npx cap init "Hello" "com.test.hello" --web-dir=public
npx cap add android
npx cap sync android
npx cap open android  # Lance Android Studio, build, install
```

10 minutes, app native installée sur émulateur.

## Exercice

1. Capacitor setup sur ton projet Vanilla
2. Build Android, install sur émulateur ou device
3. Ajoute le plugin Browser pour les liens externes
4. Génère ta keystore de release et stocke-la (1Password, vault, etc.)
5. Build une AAB de test

## Check de validation

Tu as :
- App native qui tourne ton site web
- Plugin Browser fonctionnel pour les liens externes
- AndroidManifest minimal (pas de permissions inutiles)
- Keystore générée et sauvegardée

Pas encore de soumission Play Store — c'est dans le module 07.

## Piège classique

Demander 10 permissions Android "au cas où". Ça baisse ton taux d'install. Demande au strict minimum.
