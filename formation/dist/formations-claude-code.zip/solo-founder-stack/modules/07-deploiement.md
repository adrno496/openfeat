# Module 07 — Déploiement : Vercel + Play Store

**Niveau** : 🟡 — **Durée** : 45 min lecture + 30 min pratique

## Théorie

Deux pipelines de déploiement :
- **Web** : Git push → Vercel build → live (continu)
- **Mobile** : Build local → upload Play Console → review (1-3 jours)

## Vercel pour le web

### Setup

1. Créer compte vercel.com (gratuit)
2. Connecter le repo GitHub
3. Vercel détecte automatiquement le projet
4. **Build Command** : laisse vide (Vanilla, pas de build)
5. **Output Directory** : `public`
6. **Install Command** : `npm install` (si tu as Capacitor en dépendance)

### `vercel.json`

```json
{
  "headers": [
    {
      "source": "/(.*)",
      "headers": [
        { "key": "X-Frame-Options", "value": "DENY" },
        { "key": "X-Content-Type-Options", "value": "nosniff" },
        { "key": "Referrer-Policy", "value": "strict-origin-when-cross-origin" },
        { "key": "Permissions-Policy", "value": "geolocation=(), microphone=()" },
        {
          "key": "Content-Security-Policy",
          "value": "default-src 'self'; script-src 'self' https://esm.sh; style-src 'self' 'unsafe-inline'; connect-src 'self' https://*.supabase.co; img-src 'self' data: https:; frame-ancestors 'none';"
        }
      ]
    }
  ],
  "rewrites": [
    { "source": "/((?!api).*)", "destination": "/index.html" }
  ]
}
```

`rewrites` : SPA routing. Toute URL non-API sert `index.html` qui charge le router client.

### Variables d'env Vercel

Project Settings → Environment Variables :
```
VITE_SUPABASE_URL=https://xxx.supabase.co
VITE_SUPABASE_ANON_KEY=eyJ...
```

⚠️ **Anon key seulement**, jamais service key. Si tu mets service key dans une env var "client", elle est dans le bundle servi.

### Domaine custom

Project → Domains → Add → `tonsite.fr`. Vercel génère un certificat SSL automatique.

### Déploiement

```bash
git push origin main
```

Vercel build et deploy en 30 secondes. Preview URL automatique pour chaque PR.

## Play Store pour Android

### Préparation

1. **Compte Google Play Console** : 25 € une fois
2. **App créée** : "Mon SaaS" → bundle ID `com.tonentreprise.monsaas`
3. **Listing** : description, captures, icône, vidéo (optionnel)
4. **Politique de confidentialité** : URL accessible publiquement (RGPD oblige)
5. **Classification** : test de classification (5 questions)
6. **Cible audience** : 18+ généralement (sauf si app enfant)
7. **Prix** : gratuit ou payant (modifiable plus tard)

### Soumission

```bash
# Build de release
cd android
./gradlew bundleRelease

# Le AAB est dans:
# android/app/build/outputs/bundle/release/app-release.aab
```

Play Console → Production → Create new release → Upload `.aab` → Add release notes → Save → Review release → Start rollout.

### Première soumission : 1 à 3 jours de review

Pour les soumissions suivantes : généralement 24-48h.

### Bonnes pratiques

- **Versionning** : incrémente `versionCode` et `versionName` dans `android/app/build.gradle` à chaque release
- **Internal testing** d'abord (tu peux tester avec un compte Google ajouté à la liste de testeurs)
- **Closed testing** ensuite (10-100 users)
- **Production** quand ton app est stable

### Captures d'écran

- Téléphone : 2-8 captures (format 16:9 ou 9:16)
- Tablette 7" : optionnel mais recommandé
- Tablette 10" : optionnel

Préparer screens en avance avec un device propre, pas de notification, état "réussi" de l'app.

## Pipeline d'itération

### Web

```bash
git checkout -b feat/quotes-favorites
# coder avec Claude Code
git commit -m "feat(quotes): add favorites"
git push origin feat/quotes-favorites
# PR → Vercel preview URL automatique
# Merge → live en 30 sec
```

### Mobile

```bash
# Sur main, après merge web
npx cap sync android
cd android
# Update versionCode dans build.gradle
./gradlew bundleRelease
# Upload AAB sur Play Console → review → live
```

Mobile = release moins fréquente que web. Compte 1 release mobile pour 5-10 releases web.

## Démo

E2E déploiement :
1. Push code sur GitHub
2. Vercel build + déploie sur tonsite.fr
3. `npx cap sync android` après modif
4. `./gradlew bundleRelease`
5. Upload AAB sur Play Console (test interne)

## Exercice

1. Connecte ton repo à Vercel
2. Configure les env vars (anon key, pas service key)
3. Déploie une preview, vérifie que l'app marche
4. Ajoute un domaine custom (facultatif)
5. Si mobile : crée le listing Play Console et fais une soumission interne

## Check de validation

Web :
- Site live sur Vercel
- HTTPS automatique
- Headers de sécurité présents (X-Frame-Options, CSP, etc.)
- Variables d'env configurées sans secrets

Mobile :
- Listing Play Console rempli
- AAB uploadé en test interne
- Tester invité a pu télécharger via lien interne

## Piège classique

Oublier que la **première publication Play Store** prend 1-3 jours. Si ton "ship le J30" inclut le mobile, soumets en interne au J20 au plus tard.
