# Module 04 — Frontend Vanilla JS + ES Modules

**Niveau** : 🟡 — **Durée** : 45 min lecture + 20 min pratique

## Théorie

Frontend Vanilla JS avec ES Modules natifs = pas de bundler, pas de transpiler, pas de framework. Le browser charge tes modules directement.

3 briques essentielles à construire :
1. **Routing** (passer d'une "page" à une autre sans recharger)
2. **State** (le minimum pour gérer la session, le profil, etc.)
3. **Components** (réutilisabilité sans React)

## Routing minimal

```js
// src/routes/router.js
const routes = new Map()

export function registerRoute(path, handler) {
  routes.set(path, handler)
}

export function navigate(path) {
  history.pushState({}, '', path)
  render()
}

function render() {
  const path = location.pathname
  const handler = routes.get(path) ?? routes.get('*')
  const app = document.getElementById('app')
  app.innerHTML = ''
  if (handler) handler(app)
}

window.addEventListener('popstate', render)
window.addEventListener('DOMContentLoaded', render)

// Intercepter les clics sur <a>
document.addEventListener('click', (e) => {
  const link = e.target.closest('a[data-link]')
  if (!link) return
  e.preventDefault()
  navigate(link.getAttribute('href'))
})
```

```js
// src/routes/index.js
import { registerRoute } from './router.js'
import { renderHome } from '../views/home.js'
import { renderLogin } from '../views/login.js'
import { renderDashboard } from '../views/dashboard.js'

registerRoute('/', renderHome)
registerRoute('/login', renderLogin)
registerRoute('/dashboard', renderDashboard)
registerRoute('*', (app) => {
  app.innerHTML = '<h1>404</h1><a href="/" data-link>Retour</a>'
})
```

## State minimal (sans framework)

```js
// src/store.js
const state = {
  session: null,
  profile: null
}

const listeners = new Set()

export function getState() {
  return state
}

export function setState(patch) {
  Object.assign(state, patch)
  listeners.forEach((fn) => fn(state))
}

export function subscribe(fn) {
  listeners.add(fn)
  return () => listeners.delete(fn)
}
```

Pas de Redux, pas de Pinia. C'est un objet, des listeners. Suffisant pour 95 % des SaaS solo founder.

## Components avec template strings

```js
// src/views/home.js
import { getState } from '../store.js'

export function renderHome(app) {
  const { profile } = getState()
  app.innerHTML = `
    <main>
      <h1>Bienvenue ${profile?.display_name ?? ''}</h1>
      <p>Ton SaaS de gestion de quotes.</p>
      ${profile
        ? `<a href="/dashboard" data-link>Aller au dashboard</a>`
        : `<a href="/login" data-link>Se connecter</a>`
      }
    </main>
  `
}
```

⚠️ **Si tu injectes du contenu utilisateur**, échappe-le. `profile.display_name` peut contenir un `<script>`. Toujours `escapeHtml()` sur les valeurs externes.

```js
// src/utils/escape.js
export function escapeHtml(str) {
  return String(str)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#39;')
}
```

Et ensuite :
```js
<h1>Bienvenue ${escapeHtml(profile?.display_name ?? '')}</h1>
```

## Fetch avec gestion d'erreur

```js
// src/utils/fetch.js
export async function apiFetch(url, options = {}) {
  const res = await fetch(url, {
    ...options,
    headers: { 'Content-Type': 'application/json', ...options.headers }
  })
  if (!res.ok) {
    const text = await res.text()
    throw new Error(`HTTP ${res.status}: ${text}`)
  }
  return res.json()
}
```

## Web Components (optionnel mais utile)

Pour des UI réutilisables :
```js
// src/components/quote-card.js
class QuoteCard extends HTMLElement {
  connectedCallback() {
    const text = this.getAttribute('text') ?? ''
    const author = this.getAttribute('author') ?? ''
    this.innerHTML = `
      <article class="quote-card">
        <p class="quote-text">${text}</p>
        <p class="quote-author">— ${author}</p>
      </article>
    `
  }
}

customElements.define('quote-card', QuoteCard)
```

Usage : `<quote-card text="..." author="..."></quote-card>`. Natif, sans React.

## Servir en local

```bash
npx serve public/
# ou
python3 -m http.server 8000 --directory public/
```

## CSP : préparer dès le départ

Dans ton `index.html` (mode dev) :
```html
<meta http-equiv="Content-Security-Policy" content="
  default-src 'self';
  script-src 'self' https://esm.sh;
  style-src 'self' 'unsafe-inline';
  connect-src 'self' https://*.supabase.co;
  img-src 'self' data: https:;
">
```

En prod : header HTTP, plus strict (cf. module 08).

## Anti-patterns

### `innerHTML` avec données utilisateur sans échappement → XSS garanti
### Charger 30 librairies via CDN sans CSP → catastrophe sécu
### Mettre `localStorage.setItem('is_premium', 'true')` pour "tester" → tu peux y croire en dev, ça ne fait rien à la DB

## Démo

```bash
mkdir mon-saas && cd mon-saas
mkdir public src
# index.html, app.js minimaux
npx serve public/
# Visiter http://localhost:3000
```

Créer router + store + 2 vues (home, login). Vérifier la nav SPA.

## Exercice

1. Construis le squelette : router + store + 3 vues (home, login, dashboard)
2. Ajoute auth via le `auth.js` du module 03
3. Vérifie : login → redirect dashboard, logout → retour home
4. Ajoute CSP minimale au `index.html`

## Check de validation

Tu as :
- SPA fonctionnelle avec routing client
- Store partagé qui notifie les composants
- Gestion d'erreur sur les fetch
- Échappement HTML sur les données utilisateur
- CSP de base activée

## Piège classique

Vouloir reconstruire React from scratch. Pas le but. Tu construis ce dont tu as besoin, rien de plus.
