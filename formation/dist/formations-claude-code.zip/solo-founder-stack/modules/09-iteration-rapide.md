# Module 09 — Itération rapide avec Claude Code

**Niveau** : 🟡 — **Durée** : 30 min lecture + 15 min pratique

## Théorie

Une fois live, l'objectif change : **ship fast, observe, itère**.

Le workflow type :
1. Issue GitHub clair (1 problème = 1 issue)
2. Branche feature/ ou fix/
3. Code avec Claude Code (utilise les modules de F1)
4. PR avec preview Vercel automatique
5. Merge → live en 30 sec
6. Observer (analytics, logs, retours users)

## L'erreur classique : commits trop gros

Si ton PR contient 15 fichiers et 800 lignes, tu vas :
- mettre 30 min à le reviewer toi-même
- prendre des risques de régression
- ne pas pouvoir rollback proprement

**Règle** : 1 PR = 1 changement logique. < 200 lignes idéalement.

## Workflow type d'une journée d'itération

```
9h00  - lire les feedbacks users (Discord, support email)
9h15  - identifier 3 priorités
9h30  - issue 1 : ouverte sur GitHub
9h35  - branche fix/quote-display-bug
        coder avec Claude Code (~30 min)
        commit conventionnel
        push + PR
        preview Vercel : OK
        merge → live
10h05 - issue 2 : feat/export-quotes
        idem (~45 min)
10h55 - retour aux users : "fix déployé pour @user1, feature @user2 dans 1h"
```

3 issues réglées avant midi.

## Issues GitHub : template léger

```markdown
## Problème
[1-2 phrases]

## Reproduction
1. ...
2. ...

## Comportement attendu
[1 phrase]

## Comportement observé
[1 phrase + capture si possible]

## Hypothèse
[optionnelle]
```

Cinq points qui correspondent au protocole de debug Claude Code (cf. F6 module 05).

## Slash commands utiles pour ce workflow

(Tu connais déjà les slash commands depuis F1 module 05.)

### `/from-issue`
```markdown
---
name: from-issue
description: Démarre l'implémentation depuis une issue GitHub
---

Issue : $ARGUMENTS

1. Lis l'issue (avec `gh issue view`)
2. Crée une branche fix/<num> ou feat/<num>
3. Décris le scope avant de coder (3 fichiers max à modifier)
4. Attends ma validation pour passer à l'exécution
```

### `/ship`
```markdown
---
name: ship
description: Workflow complet pour shipper une PR
---

1. `git diff main` : résumer le changement
2. Run lint, tests
3. Génère un commit message conventionnel
4. Pousse la branche
5. Crée la PR avec gh CLI
6. Vérifie que la preview Vercel build sans erreur
```

## Rollback facile

Si une release casse en prod :

```bash
# Vercel : rollback en 1 clic depuis le dashboard (sélectionner ancien deploy → Promote)

# Code : revert le commit
git revert <hash>
git push

# Mobile : push une nouvelle version qui réintroduit l'ancien comportement, ou utilise Play Console "Halt rollout"
```

Le rollback doit être **possible en moins de 5 minutes**. Si non, ton process a un problème.

## Observabilité minimum

Avant le J30, mets en place :

### Logs côté serveur (Edge Functions)
```ts
console.log(JSON.stringify({ level: 'info', event: 'subscription_created', userId }))
```
Visibles dans Supabase Dashboard → Functions → Logs.

### Analytics côté client
- **Plausible** ou **Umami** (privacy-first, pas de bandeau cookies)
- Track events clés : signup, first_login, subscription_started, premium_feature_used

### Sentry (erreurs)
```js
import * as Sentry from 'https://esm.sh/@sentry/browser'
Sentry.init({ dsn: '...' })
```
Tu sais quand ton site plante avant que les users ne te le disent.

## Le piège de la sur-itération

Itérer 30 fois par semaine, c'est bien. Itérer 30 fois sans direction, c'est s'épuiser.

Une fois par semaine, prends 30 min :
- Review des analytics (qu'est-ce que les users font ?)
- Review des feedbacks (que demandent-ils ?)
- Choix des 3 priorités de la semaine
- Stop tout le reste

## Démo

Workflow complet sur un fix :

```bash
# 1. Issue ouverte
gh issue view 42

# 2. Branche
git checkout -b fix/42-export-csv

# 3. Claude Code
claude
> /from-issue 42

# 4. Code (Claude Code propose, tu acceptes)
# 5. Tests passent
# 6. Commit + push
git add -A && git commit -m "fix(export): handle empty quotes list"
git push origin fix/42-export-csv

# 7. PR
gh pr create --fill

# 8. Preview Vercel : check
# 9. Merge
gh pr merge --squash

# 10. Live ~30 sec plus tard
```

## Exercice

1. Configure 2 slash commands : `/from-issue` et `/ship`
2. Setup analytics (Plausible, Umami, ou similaire)
3. Setup Sentry (gratuit jusqu'à 5k events/mois)
4. Sur ton repo, ouvre 3 issues, traite-les avec le workflow ci-dessus
5. Mesure le temps moyen issue → live

## Check de validation

Tu sais :
- Workflow issue → branche → PR → live en < 1h
- Rollback en < 5 min
- Observabilité minimale en place
- Itération calibrée (3 priorités/semaine, pas 30)

## Piège classique

Coder à toute vitesse sans observabilité. Tu shippes des features que personne n'utilise. Setup analytics au J0, pas au J60.
