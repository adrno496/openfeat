# Module 01 — Architecture Vanilla JS + Capacitor + Supabase

**Niveau** : 🟡 — **Durée** : 40 min lecture + 20 min pratique

## Théorie

### Le stack complet

```
+-----------------+
|  Frontend Web   |  Vanilla JS (ES Modules), pas de framework
+-----------------+
|  Mobile         |  Capacitor 6 (wrapper natif autour du web)
+-----------------+
|  Backend        |  Supabase (Postgres + Auth + Storage + Edge Functions)
+-----------------+
|  Hébergement    |  Vercel (Hobby tier gratuit)
+-----------------+
|  Paiements      |  Lemonsqueezy (web) + RevenueCat (mobile)
+-----------------+
```

### Pourquoi pas React/Vue/Svelte ?

3 raisons techniques :
1. **Bundle size** : un Vanilla JS ne dépasse pas ~50 ko gzipped, un framework t'amène facilement à 200-500 ko
2. **Compétences durables** : DOM API, fetch, ES Modules — tout ça est natif et ne bougera pas
3. **Démarrage instantané** : pas de `npm install`, pas de toolchain, pas de bundler

3 raisons business :
1. **Vitesse au début** : tu shippes plus vite avec ce que tu connais nativement
2. **Maintenance** : pas de breaking change Next 14 → 15
3. **Performance** : un site Vanilla est rapide par défaut, sans optimisation

### Quand cette stack ne marche pas

- Apps avec UI très complexe (éditeurs WYSIWYG, dashboards à 50 widgets temps réel)
- Equipes de 10 devs qui veulent une orthogonalité forte (les frameworks aident là)
- Apps qui exigent SSR avancé (SEO complexe, e-commerce avec milliers de produits)

Pour 80 % des SaaS solo founder : Vanilla suffit.

## Coûts réels

### Mois 1 (0-100 users)

- Supabase Free : 0 €
- Vercel Hobby : 0 €
- Lemonsqueezy : 5 % + 0,50 $ par transaction (pas de fixe)
- RevenueCat Free : 0 €
- Domaine : 12 €/an
- Google Play : 25 € une fois

**Total : ~3 €/mois en moyenne**

### Mois 6 (1000 users actifs, ~10 % payants)

- Supabase Pro (si dépassement) : 25 $/mois
- Vercel Hobby suffit toujours
- Lemonsqueezy : variable (5 % CA)
- RevenueCat Free suffit (jusqu'à 10 k$ MTR)

**Total : ~25-50 €/mois**

Comparer avec une stack lourde (Next + AWS + Stripe + serveurs custom) qui démarre à 200 €/mois.

## Démo : structure de projet type

```
mon-saas/
├── public/
│   ├── index.html
│   ├── styles.css
│   └── app.js              # ES Module entry
├── src/
│   ├── routes/             # SPA router custom
│   ├── components/         # Composants natifs (web components)
│   ├── services/           # Auth, API, payments
│   └── utils/
├── android/                # Capacitor build
├── supabase/
│   ├── migrations/
│   └── functions/          # Edge functions
├── package.json
├── capacitor.config.ts
├── vercel.json
└── CLAUDE.md
```

Pas de bundler. Pas de transpiler. Le browser lit ton JS directement.

## Exemple : `index.html` minimal

```html
<!doctype html>
<html lang="fr">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Mon SaaS</title>
  <link rel="stylesheet" href="styles.css">
  <script type="module" src="app.js"></script>
</head>
<body>
  <main id="app"></main>
</body>
</html>
```

`type="module"` permet d'utiliser `import` natif.

## Exemple : `app.js`

```js
import { initRouter } from './src/routes/router.js'
import { supabase } from './src/services/supabase.js'

async function bootstrap() {
  const { data: { session } } = await supabase.auth.getSession()
  initRouter({ session })
}

bootstrap()
```

ES Modules natifs. Pas de framework. Le browser charge `app.js`, qui importe le router, qui charge ses propres dépendances.

## Exercice

1. Crée le squelette de ton projet selon la structure ci-dessus
2. `index.html` + `app.js` minimal qui affiche "Hello, [ton-projet]"
3. Sers en local avec `npx serve public` ou `python -m http.server 8000 --directory public`
4. Vérifie : ça marche sans `npm install`

## Check de validation

Tu sais :
- pourquoi cette stack
- quand elle ne marche pas
- les coûts réels
- la structure de projet type

Tu n'as pas encore Supabase ou Capacitor de configuré — c'est dans les modules suivants.

## Piège classique

Vouloir ajouter un bundler "au cas où". Non. Tu pourras en ajouter plus tard si vraiment nécessaire. Démarre nu.
