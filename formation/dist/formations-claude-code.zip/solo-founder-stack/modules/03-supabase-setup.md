# Module 03 — Setup Supabase : auth, RLS, schemas

**Niveau** : 🟡 — **Durée** : 50 min lecture + 25 min pratique

## Théorie

Supabase = Postgres + Auth + Storage + Edge Functions, avec une UI et des SDKs.

Pour un SaaS, on va construire :
- Auth fonctionnelle (email + password OU magic link)
- Table `profiles` pour les infos utilisateur étendues
- Table `subscriptions` pour les abonnements (synced via webhooks)
- RLS partout
- RPC pour muter les flags critiques

## Setup initial

```bash
npm install -g supabase
supabase init
supabase start    # Postgres local + UI sur localhost:54323
```

Ou utiliser le projet hébergé directement (recommandé pour solo founder) : `supabase.com` → New project.

## Schéma de base

```sql
-- supabase/migrations/20260101000000_initial_schema.sql

-- Activer extensions utiles
create extension if not exists "uuid-ossp";

-- Table profiles (extension de auth.users)
create table public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  email text not null unique,
  display_name text,
  avatar_url text,
  is_premium boolean not null default false,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

-- RLS
alter table public.profiles enable row level security;

create policy "users_can_read_own_profile" on public.profiles
  for select using (auth.uid() = id);

create policy "users_can_update_own_profile_safe_fields" on public.profiles
  for update using (auth.uid() = id)
  with check (
    auth.uid() = id
    and is_premium = (select is_premium from public.profiles where id = auth.uid())
  );

-- Note critique : la politique UPDATE ci-dessus empêche la mutation de is_premium
-- côté client (la valeur après update doit être identique à la valeur actuelle).
-- Pour modifier is_premium, on passe par la RPC set_premium_status (server-side).
```

```sql
-- Table subscriptions
create table public.subscriptions (
  id uuid primary key default uuid_generate_v4(),
  user_id uuid not null references public.profiles(id) on delete cascade,
  provider text not null check (provider in ('lemonsqueezy', 'revenuecat')),
  external_id text not null,
  status text not null check (status in ('active', 'cancelled', 'expired', 'past_due')),
  product_name text,
  current_period_end timestamptz,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  unique (provider, external_id)
);

alter table public.subscriptions enable row level security;

create policy "users_can_read_own_subscriptions" on public.subscriptions
  for select using (auth.uid() = user_id);

-- Pas de policy INSERT/UPDATE/DELETE côté user.
-- Toutes les mutations passent par les webhooks (server-side, service_key).
```

## RPC sécurisée pour `is_premium`

```sql
-- Edge function ou function SQL : set_premium_status
create or replace function public.set_premium_status(
  target_user_id uuid,
  new_status boolean
)
returns void
language plpgsql
security definer
as $$
begin
  -- Cette fonction ne peut être appelée que par le service_role
  -- (car appel via Edge Function avec service_key, jamais côté client)
  if current_setting('request.jwt.claims', true)::json->>'role' != 'service_role' then
    raise exception 'unauthorized';
  end if;

  update public.profiles
  set is_premium = new_status, updated_at = now()
  where id = target_user_id;
end;
$$;

revoke all on function public.set_premium_status from public;
grant execute on function public.set_premium_status to service_role;
```

## Côté client : auth + lecture

```js
// src/services/supabase.js
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2'

const SUPABASE_URL = import.meta.env?.VITE_SUPABASE_URL || window.SUPABASE_URL
const SUPABASE_ANON_KEY = import.meta.env?.VITE_SUPABASE_ANON_KEY || window.SUPABASE_ANON_KEY

export const supabase = createClient(SUPABASE_URL, SUPABASE_ANON_KEY)
```

```js
// src/services/auth.js
import { supabase } from './supabase.js'

export async function signUp(email, password) {
  const { data, error } = await supabase.auth.signUp({ email, password })
  if (error) return { error }
  return { user: data.user }
}

export async function signIn(email, password) {
  const { data, error } = await supabase.auth.signInWithPassword({ email, password })
  if (error) return { error }
  return { session: data.session }
}

export async function signOut() {
  const { error } = await supabase.auth.signOut()
  if (error) return { error }
  return { ok: true }
}

export async function getCurrentProfile() {
  const { data: { user } } = await supabase.auth.getUser()
  if (!user) return { profile: null }
  const { data, error } = await supabase
    .from('profiles')
    .select('id, email, display_name, avatar_url, is_premium')
    .eq('id', user.id)
    .single()
  if (error) return { error }
  return { profile: data }
}
```

Note : `select('id, email, display_name, avatar_url, is_premium')` — colonnes explicites. Jamais `select('*')`.

## Anti-patterns à éviter absolument

### `is_premium` muté côté client
```js
// JAMAIS
await supabase.from('profiles').update({ is_premium: true }).eq('id', userId)
```
La RLS doit déjà empêcher ça (cf. policy ci-dessus). Mais tu n'écris jamais cette ligne, point.

### `select('*')`
```js
// JAMAIS
const { data } = await supabase.from('profiles').select('*')

// TOUJOURS
const { data } = await supabase.from('profiles').select('id, email, display_name')
```

### Service key côté client
```js
// JAMAIS, vraiment jamais
const supabase = createClient(URL, SERVICE_ROLE_KEY)  // catastrophe
```
Service role contourne RLS. Si elle leak côté client, ton DB est compromis.

## Démo : flow complet auth + read profile

```js
// app.js
import { signIn, getCurrentProfile } from './src/services/auth.js'

const result = await signIn('test@example.com', 'password123')
if (result.error) {
  console.error('Auth failed:', result.error)
} else {
  const { profile } = await getCurrentProfile()
  console.log('User:', profile.display_name, '| Premium:', profile.is_premium)
}
```

## Exercice

1. Crée un projet Supabase (gratuit)
2. Applique la migration ci-dessus
3. Setup `auth.js` côté frontend
4. Test : signup + login + read profile depuis ton app local
5. Vérifie : tu ne peux PAS muter `is_premium` directement (la RLS te refuse)

## Check de validation

Tu as :
- Tables profiles + subscriptions avec RLS
- Auth qui marche (signup, login, logout)
- Lecture de profile avec colonnes explicites
- RPC `set_premium_status` callable seulement par service_role
- Confirmation que la mutation `is_premium` côté client est bloquée

## Piège classique

Activer RLS mais oublier la policy SELECT → ta table devient inaccessible (même pour le user owner). Toujours tester `select` après chaque migration.
