# Positioning — Solo Founder Stack

## USP

La seule formation FR qui te montre **un stack vraiment léger** pour ship un SaaS — pas un framework JS de 200 MB de node_modules.

## Cible

- Indie hackers FR avec 1-5 ans d'XP dev
- Solo founders qui veulent ship sans investir
- Devs qui en ont marre de l'overhead React/Next/Nuxt

## Pas la cible

- Devs qui adorent leur framework moderne — F2 ne te convertira pas
- Equipes de 5+ devs (cette stack est pensée pour le solo/duo)
- Ceux qui veulent le hype tech à tout prix

## Promesse

À la fin des 30 jours :
- 1 SaaS web live avec auth + paiements + DB
- Optionnel : version mobile via Capacitor sur Play Store
- Coût infra < 30 €/mois pour les 1000 premiers users
- Process ship-iterate avec Claude Code maîtrisé

## Anti-promesse

- On ne te promet pas X €/mois de revenus (ça dépend de toi et de ton produit)
- On ne fait pas le marketing/sales à ta place
- On ne couvre pas les apps complexes type AAA (cette stack a ses limites)

## Stack pratique, projet fil rouge

Les exemples sont ancrés sur un projet fictif fil rouge (un SaaS de gestion de quotes pour entrepreneurs) que tu peux soit suivre tel quel, soit adapter à ton propre projet. Toutes les preuves sociales utilisent des placeholders à remplir avec des témoignages réels collectés.
