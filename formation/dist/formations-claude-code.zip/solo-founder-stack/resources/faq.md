# FAQ — Solo Founder Stack

### Pourquoi pas Next.js / Nuxt / SvelteKit ?

Pour un SaaS solo founder qui ship en 30 jours, le poids du framework dépasse le bénéfice. Vanilla est plus rapide à démarrer, plus simple à maintenir, suffisant pour 95 % des SaaS solo.

### Et si je veux du SSR pour le SEO ?

Le SSR n'est nécessaire que pour les pages publiques massives (blog, e-commerce avec milliers de pages). Pour un SaaS, ta landing peut être statique (Astro, ou même Vanilla pré-rendu) et le reste de l'app authentifiée n'a pas besoin de SEO.

### Capacitor vs React Native ?

Capacitor : tu réutilises ton frontend web tel quel. Plus simple si tu pars du web.
React Native : performance UI native légèrement supérieure mais tu dois maintenir 2 codebases ou tout dev en RN.
Pour un solo founder qui ship d'abord en web : Capacitor.

### Lemonsqueezy fee de 5 % c'est cher non ?

Comparé à Stripe (~3 %) oui. Mais Lemonsqueezy gère pour toi : factures, TVA UE, OSS, conformité. Si tu factures Stripe direct, tu vas payer un comptable spécialisé en e-commerce international, plus cher que les 2 % d'écart.

### Combien de temps pour finir la formation ?

8h de contenu. 30 jours de pratique. Si tu suis vraiment le rythme, tu shippes à J30.

### Faut-il avoir une idée de produit avant de commencer ?

Idéalement oui. Sinon, suis avec le projet "gestion de quotes" fil rouge, mais tu vas perdre de la motivation à un moment (parce que ce n'est pas TON projet).

### Et iOS ?

Capacitor supporte iOS aussi. Mais l'écosystème Apple est plus contraint (compte Apple Developer 99 €/an, MacBook obligatoire pour build, review plus stricte). Cette formation focus sur Android pour démarrer. iOS = même méthodologie, plus de friction.

### J'ai déjà un projet en cours, je peux suivre la formation dessus ?

Oui. Adapte les exemples. Si ton projet utilise React et que tu refuses de le quitter, F2 est moins direct mais les modules sécurité, paiements, mobile, déploiement sont quasi 100 % réutilisables.

### Garantie de remboursement ?

Cf. CGV et `LEGAL-NOTES.md`.

### Communauté ?

Discord de founders qui shippent. Pas de discussions de "best practices" théoriques. On parle de vrais blocages techniques et business.

### Et le marketing / le sales ?

Cette formation n'en parle pas. On ship un produit. La distribution est un autre sujet (et un autre talent). Tu trouveras des ressources externes dans `ressources-externes.md`.

### Est-ce que tu donnes un repo template ?

Oui. Un repo `solo-founder-stack-starter` fork-able est fourni avec la formation, contenant la structure de projet, le `CLAUDE.md`, les migrations, le vercel.json, etc.
