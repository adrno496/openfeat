# Cheatsheet — Solo Founder Stack

## Stack

```
Frontend: Vanilla JS + ES Modules + Capacitor (mobile)
Backend:  Supabase (Postgres + Auth + Storage + Edge Functions)
Deploy:   Vercel (web) + Play Store (Android)
Pay:      Lemonsqueezy (web) + RevenueCat (mobile)
```

## Commandes essentielles

```
# Frontend
npx serve public/                                   # serveur local
npx supabase start                                  # Postgres local
npx supabase migration new <nom>                    # nouvelle migration
npx supabase db reset                               # reset DB locale
npx supabase functions deploy <fn> --no-verify-jwt  # webhook public

# Mobile
npx cap sync android
npx cap open android
./gradlew bundleRelease

# Deploy
git push                                            # Vercel auto-deploy
```

## Sécurité — règles dures

- `is_premium` muté UNIQUEMENT via RPC server-side
- Aucun `select('*')`, toujours colonnes explicites
- Aucun `innerHTML` avec données externes sans `escapeHtml()`
- CSP en prod : pas de `unsafe-inline`, pas de `unsafe-eval`
- Webhooks : toujours vérifier la signature
- Service key Supabase : JAMAIS côté client
- `.gitignore` : `.env`, `.local.json`, `release.keystore`

## RLS minimum par table

```sql
alter table public.X enable row level security;

-- SELECT minimal pour le owner
create policy "owner_read" on public.X
  for select using (auth.uid() = user_id);

-- UPDATE qui interdit la mutation des flags critiques
create policy "owner_update_safe" on public.X
  for update using (auth.uid() = user_id)
  with check (
    auth.uid() = user_id
    and is_premium = (select is_premium from public.X where id = auth.uid())
  );
```

## Workflow d'itération

```
Issue GitHub → branch → code (Claude Code) → PR → preview Vercel → merge → live
```

Cycle attendu : < 1h pour un fix, 1-3h pour une feature.

## Headers de sécurité (vercel.json)

```
X-Frame-Options: DENY
X-Content-Type-Options: nosniff
Referrer-Policy: strict-origin-when-cross-origin
Content-Security-Policy: [voir module 07]
```

## Coût mensuel cible

```
0-100 users :    ~3 €
100-1000 :      ~25 €
1000-5000 :     ~50-100 €
```

Si ça dépasse, audit conso.

## Plan 30 jours

```
J0-J3   : repo + Vercel + Hello World live
J3-J7   : Auth Supabase + 1ère feature métier
J7-J14  : Paiements web (Lemonsqueezy)
J14-J21 : Mobile Capacitor + interne Play Store
J21-J28 : Audit sécurité complet
J28-J30 : Premier user payant ou bêta payante
```

## Anti-patterns à éviter

```
❌ select('*')
❌ is_premium muté côté client
❌ innerHTML avec userInput
❌ Service key côté client
❌ Webhook sans signature
❌ Refonte d'archi avant 10k users
❌ Hire avant le product-market fit
❌ Ship sans observabilité
```
