# Glossaire — Solo Founder Stack

**AAB (Android App Bundle)** — Format de package Android moderne, remplace l'APK pour le Play Store.

**Anon key (Supabase)** — Clé publique côté client, contrainte par RLS.

**Capacitor** — Outil qui wrappe ton site web en app native (Android/iOS).

**CSP (Content Security Policy)** — En-tête HTTP qui contrôle ce que le browser peut exécuter / charger.

**Edge Function** — Fonction serverless Supabase, runtime Deno, déclenchée par HTTP.

**ES Modules** — Système de modules natifs JavaScript, chargés directement par le browser via `import`.

**Keystore** — Fichier qui signe ton AAB Android. Indispensable et irremplaçable.

**Lemonsqueezy** — Merchant of Record pour SaaS. Gère TVA UE, OSS, factures.

**MoR (Merchant of Record)** — Le service joue le rôle de vendeur officiel, gère TVA et conformité fiscale.

**Play Console** — Interface Google pour publier sur Play Store.

**RevenueCat** — Service qui simplifie la gestion des abonnements in-app (iOS, Android).

**RLS (Row Level Security)** — Mécanisme Postgres pour filtrer l'accès aux lignes selon l'utilisateur.

**RPC (Supabase)** — Function PostgreSQL exposée comme endpoint, utile pour les opérations sensibles.

**Service key (Supabase)** — Clé qui contourne RLS. Côté serveur uniquement, jamais côté client.

**Vercel** — Plateforme d'hébergement frontend, déploiement continu via Git.

**Webhook signing secret** — Secret partagé entre toi et le service (Lemonsqueezy/RevenueCat) pour signer les webhooks et empêcher le spoofing.
