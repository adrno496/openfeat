# Ressources externes — Solo Founder Stack

## Documentation

- Supabase docs : `supabase.com/docs`
- Capacitor docs : `capacitorjs.com/docs`
- Vercel docs : `vercel.com/docs`
- Lemonsqueezy docs : `docs.lemonsqueezy.com`
- RevenueCat docs : `revenuecat.com/docs`
- Google Play Console : `support.google.com/googleplay/android-developer`

## Tools

- gitleaks (secret scanner)
- Plausible / Umami (analytics privacy-first)
- Sentry (error tracking)
- ngrok (tunneling local pour webhooks)

## Lectures (sélection)

- "The Mom Test" de Rob Fitzpatrick (interview users sans biais)
- "Hooked" de Nir Eyal (rétention)
- "Lean Analytics" (métriques par stade)
- Articles de Patrick McKenzie (patio11) sur les SaaS

## Communautés

- Indie Hackers
- Hacker News (Show HN)
- Reddit r/SaaS, r/EntrepreneurRideAlong
- Discord de la formation (privé)

## Veille spécifique

- Compte X de Pieter Levels (@levelsio) — solo founder de référence
- "How I Built This" podcast (NPR)

## Templates et boilerplates

- Repo template `solo-founder-stack-starter` (à fork — fourni avec la formation)
- Templates Supabase migrations dans `templates/`
- vercel.json prêt avec headers de sécurité

## Pour aller plus loin

- F3 — `skills-mcp-builder-pro/` — créer des MCP custom pour ton SaaS
- F5 — `ai-agency-toolkit/` — passer du SaaS solo à l'agence
- F1 — `claude-code-mastery-fr/` — référence complète Claude Code
