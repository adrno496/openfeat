# Script vidéo — Intro hook (≤ 90 sec)

## Plan

### 0:00 — 0:15 — Hook
"Tu as une idée de SaaS. Tu as 30 jours et tu veux pas claquer 50 000 € avant ton premier user."

### 0:15 — 0:35 — Problème
"L'erreur classique : tu choisis un framework lourd, une infra AWS complexe, et 3 mois plus tard t'as toujours pas shippé."

### 0:35 — 1:00 — Solution
"Solo Founder Stack te montre une stack vraiment légère pour ship un SaaS solo : Vanilla JS, Capacitor, Supabase, Vercel, Lemonsqueezy, RevenueCat. Coût mensuel sous 30 €. Auth, paiements web et mobile, deploy continu."

### 1:00 — 1:20 — Différenciation
"Pas de hype framework. Pas de bullshit. Le process réel pour solo founders qui ne veulent pas perdre 6 mois."

### 1:20 — 1:30 — CTA
"30 jours pour ship. C'est par là : [LIEN]"

## Notes tournage

- Plan poitrine, regard caméra, énergie posée
- B-roll : screencast d'un déploiement Vercel + Play Console (5 sec chacun)
- Pas de musique épique
