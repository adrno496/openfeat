# Scripts vidéo — Solo Founder Stack (consolidé)

Au tournage, splitter en fichiers séparés (00 à 10) selon le pipeline de prod.

---

## 00 — Intro hook (≤ 90 sec)

- "Tu as une idée. Tu as 30 jours et un budget mini. Tu veux ship."
- "Solo Founder Stack te montre comment shipper un SaaS production-ready en 30 jours."
- "Vanilla JS, Capacitor, Supabase, Vercel, Lemonsqueezy, RevenueCat. Pas de bullshit, pas de framework lourd."
- "Si tu veux ship sans investir 50 k$ en infra et 6 mois en dev : c'est ici."
- CTA.

---

## 01 — Architecture (8-10 min)

- Pourquoi Vanilla JS (3 raisons techniques + 3 business)
- Quand cette stack ne marche pas
- Coûts réels (mois 1, mois 6)
- Démo : structure projet
- Servir en local sans bundler

---

## 02 — `CLAUDE.md` production (6-8 min)

- Pourquoi un `CLAUDE.md` "ship + sécurité"
- Les 6 sections critiques
- Avant/après sur un vrai exemple
- Les anti-patterns spécifiques au "ship rapide"

---

## 03 — Setup Supabase (10-12 min)

- Setup local + projet hébergé
- Schémas profiles + subscriptions
- RLS partout (démos)
- RPC `set_premium_status` (sécurité)
- Code frontend services/auth.js
- Test "is_premium côté client bloqué"

---

## 04 — Frontend Vanilla (8-10 min)

- Routing client custom
- State minimal (pas de Redux)
- Components avec template strings
- Échappement XSS
- Web Components natifs (optionnel)

---

## 05 — Mobile Capacitor (10-12 min)

- Setup Capacitor
- Build Android, install émulateur
- Plugins essentiels (Browser, Preferences, App)
- Permissions minimales
- Génération keystore + backup

---

## 06 — Paiements (12-15 min)

- Architecture cible (web vs mobile)
- Setup Lemonsqueezy + checkout link
- Edge Function webhook avec vérification signature
- Setup RevenueCat
- Test E2E achat → premium activé

---

## 07 — Déploiement (8-10 min)

- Vercel : config, env vars, headers, rewrites
- Domaine custom
- Play Store : compte, listing, AAB upload
- Pipeline d'itération web vs mobile

---

## 08 — Sécurité (10-12 min)

- CSP en prod
- XSS prévention (escapeHtml, textContent)
- Audit RLS (script SQL)
- Gestion des secrets (client / Edge Function)
- Webhook signatures
- Checklist pré-launch

---

## 09 — Itération rapide (6-8 min)

- Workflow issue → branche → PR → live
- Slash commands `/from-issue`, `/ship`
- Rollback en < 5 min
- Observabilité (analytics, Sentry)
- Le piège de la sur-itération

---

## 10 — Conclusion (4-6 min)

- Récap du stack
- Plan J+30 à J+90 (conversion → rétention → croissance)
- Anti-patterns post-ship
- Vers F5/F3/F4/F1 selon profil

---

## Notes générales

- Beaucoup de démos terminal + browser (split-screen)
- Inclure des vraies captures de Supabase Dashboard, Vercel, Lemonsqueezy, Play Console
- Pas de musique pendant les démos techniques
- Sous-titrer FR a minima
