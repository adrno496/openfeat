# Exercice 05 — Audit sécurité complet pré-launch

Niveau : 🔴
Durée : 2h

## Énoncé

Avant ton premier user payant, applique la checklist du module 08 :

1. CSP en prod activée et testée
2. Audit XSS : grep tous les `innerHTML` du projet, vérifie échappement
3. Run le script SQL d'audit RLS (tables sans RLS, policies trop permissives)
4. `gitleaks detect --source .` sur le repo, corrige tout finding
5. Test E2E "is_premium côté client bloqué" depuis la console navigateur
6. Webhook signatures vérifiées (Lemonsqueezy, RevenueCat)
7. Toutes les Edge Functions déployées avec `--no-verify-jwt` UNIQUEMENT pour les webhooks publics
8. Variables d'env client : aucun secret (vérification manuelle)
9. Variables d'env serveur : tous les secrets via `supabase secrets set`
10. `.gitignore` audité

## Critères de réussite

10 cases cochées. Si 1 case reste, tu n'es pas prêt à lancer.

## Auto-check

- [ ] CSP en prod (sans unsafe-eval)
- [ ] Aucun innerHTML avec données utilisateur sans escapeHtml
- [ ] RLS activé partout, aucune policy `true` injustifiée
- [ ] gitleaks clean
- [ ] is_premium côté client bloqué (testé en console)
- [ ] Webhook signatures vérifiées
- [ ] --no-verify-jwt seulement pour webhooks publics
- [ ] Aucun secret en env client
- [ ] Tous secrets serveur configurés via supabase secrets
- [ ] .gitignore audité
