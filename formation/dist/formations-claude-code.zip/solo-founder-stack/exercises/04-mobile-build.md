# Exercice 04 — Build mobile et soumission interne

Niveau : 🟡
Durée : 3h

## Énoncé

1. Setup Capacitor sur ton projet (cf. module 05)
2. Build et test sur émulateur Android
3. Génère ta keystore de release et **stocke-la dans 1Password / vault**
4. Build le `.aab` de release
5. Crée le compte Play Console (25 €)
6. Crée l'app, remplis le listing minimum (titre, description courte/longue, captures d'écran, icône)
7. Politique de confidentialité publiée à l'URL `https://tonsite.fr/privacy`
8. Soumets en test interne avec ton email comme tester
9. Installe l'app via lien interne, vérifie qu'elle marche

## Critères de réussite

- App lance sur émulateur
- Keystore générée + sauvegardée 2 endroits
- AAB de release correct
- Listing Play Console rempli
- Test interne accessible
- App fonctionne en mobile (auth, lecture profile)

## Auto-check

- [ ] Capacitor setup
- [ ] Build émulateur OK
- [ ] Keystore sauvegardée 2x
- [ ] AAB release uploadé
- [ ] Listing Play Console complet
- [ ] Politique de confidentialité publiée
- [ ] Test interne fonctionne
