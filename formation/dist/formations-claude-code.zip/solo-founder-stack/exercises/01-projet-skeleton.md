# Exercice 01 — Squelette de projet

Niveau : 🟢
Durée : 1h

## Énoncé

Crée le squelette de ton projet selon la structure Vanilla JS + Supabase + Capacitor :

```
mon-saas/
├── public/
│   ├── index.html
│   └── app.js
├── src/
│   ├── routes/
│   ├── components/
│   ├── services/
│   └── utils/
├── supabase/
├── package.json
├── CLAUDE.md
└── .gitignore
```

Inclure :
- `index.html` minimal avec CSP meta + script type module
- `app.js` qui affiche "Hello, [nom-projet]"
- `CLAUDE.md` complet (cf. module 02)
- `.gitignore` avec entrées correctes

Servir en local avec `npx serve public/`.

## Critères de réussite

- Structure exacte créée
- Page accessible sur localhost
- `CLAUDE.md` < 100 lignes, sections complètes
- `.gitignore` correct (.env, settings.local.json, node_modules, keystore)

## Auto-check

- [ ] Squelette créé
- [ ] Hello world s'affiche
- [ ] CLAUDE.md committed
- [ ] .gitignore correct
- [ ] CSP meta présente dans index.html
