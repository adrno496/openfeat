# Exercice 03 — Paiement E2E (Lemonsqueezy)

Niveau : 🟡
Durée : 2h30

## Énoncé

1. Configure Lemonsqueezy (mode test) avec un produit subscription
2. Code l'Edge Function `lemonsqueezy-webhook` (cf. module 06)
3. Déploie : `npx supabase functions deploy lemonsqueezy-webhook --no-verify-jwt`
4. Configure le webhook Lemonsqueezy → URL de ton Edge Function
5. Achète depuis ton site avec une carte de test
6. Vérifie : ligne en `subscriptions`, `profiles.is_premium = true`
7. Annule l'abonnement (depuis Lemonsqueezy) et vérifie que `is_premium` repasse à false

## Critères de réussite

- Webhook signature vérifiée (sinon 401)
- Test E2E réussi : achat → premium activé
- Test annulation : premium désactivé
- Aucune mutation de `is_premium` initiée côté client
- Logs de l'Edge Function visibles dans Supabase Dashboard

## Auto-check

- [ ] Lemonsqueezy configuré
- [ ] Edge function déployée (--no-verify-jwt)
- [ ] Achat test → DB updated
- [ ] is_premium = true après achat
- [ ] Annulation → is_premium = false
- [ ] Signature vérifiée correctement
