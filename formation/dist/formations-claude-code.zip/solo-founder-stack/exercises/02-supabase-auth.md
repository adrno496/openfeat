# Exercice 02 — Setup Supabase complet

Niveau : 🟡
Durée : 2h

## Énoncé

1. Crée un projet Supabase
2. Applique la migration du module 03 (profiles + subscriptions + RLS + RPC)
3. Code `services/supabase.js`, `services/auth.js` côté frontend
4. Implémente signup + login + logout + read profile
5. Test E2E : crée un user via UI, vérifie qu'il apparaît dans `auth.users` ET `profiles`
6. Test : tente de muter `is_premium` côté client, vérifie que ça refuse

## Critères de réussite

- Migration appliquée sans erreur
- RLS activé sur les 2 tables
- Auth signup/login/logout fonctionnel
- read profile : colonnes explicites, jamais select('*')
- Mutation is_premium côté client : refusée

## Auto-check

- [ ] Migration appliquée
- [ ] Auth signup OK
- [ ] Auth login OK
- [ ] Profile lisible
- [ ] Mutation is_premium côté client : KO (RLS bloque)
