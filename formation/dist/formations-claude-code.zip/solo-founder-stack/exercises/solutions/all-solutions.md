# Solutions — Solo Founder Stack (consolidées)

Solutions des 5 exercices, en mode synthèse pour gagner en lisibilité. Chaque section couvre un exercice.

---

## Solution 01 — Squelette de projet

### Structure attendue

```
mon-saas/
├── public/
│   ├── index.html
│   ├── styles.css
│   └── app.js
├── src/
│   ├── routes/
│   │   ├── router.js
│   │   └── index.js
│   ├── components/
│   ├── services/
│   │   └── supabase.js (placeholder)
│   ├── utils/
│   │   └── escape.js
│   └── store.js
├── supabase/
│   ├── config.toml
│   └── migrations/
├── package.json
├── capacitor.config.ts (optionnel à ce stade)
├── vercel.json
├── CLAUDE.md
├── .gitignore
└── .env.example
```

### `index.html` minimal

```html
<!doctype html>
<html lang="fr">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Mon SaaS</title>
  <meta http-equiv="Content-Security-Policy" content="default-src 'self'; script-src 'self' https://esm.sh; style-src 'self' 'unsafe-inline'; connect-src 'self' https://*.supabase.co; img-src 'self' data: https:;">
  <link rel="stylesheet" href="styles.css">
  <script type="module" src="app.js"></script>
</head>
<body>
  <main id="app"></main>
</body>
</html>
```

### `app.js`

```js
import './src/routes/index.js'

console.log('Mon SaaS booted')
```

### `.gitignore` minimal

```
node_modules/
.env
.env.*
!.env.example
.claude/settings.local.json
.claude/logs/
android/release.keystore
android/local.properties
.DS_Store
```

---

## Solution 02 — Setup Supabase

Migration : copier-coller le SQL du module 03.

Côté frontend, `src/services/supabase.js` :

```js
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2'

const SUPABASE_URL = window.SUPABASE_URL || ''
const SUPABASE_ANON_KEY = window.SUPABASE_ANON_KEY || ''

if (!SUPABASE_URL || !SUPABASE_ANON_KEY) {
  console.error('Missing Supabase env vars. Configure window.SUPABASE_URL/ANON_KEY before script type=module loads.')
}

export const supabase = createClient(SUPABASE_URL, SUPABASE_ANON_KEY)
```

`src/services/auth.js` : copier le code du module 03.

### Test "is_premium côté client bloqué"

```js
const { error } = await supabase
  .from('profiles')
  .update({ is_premium: true })
  .eq('id', userId)

console.assert(error !== null, 'RLS should have blocked the update')
```

Si `error` est null, ta policy UPDATE n'est pas bonne — rétrograde au module 03.

---

## Solution 03 — Paiement E2E

### Edge function complète

Voir module 06, code complet déjà commenté.

### Configuration webhook Lemonsqueezy

Dashboard Lemonsqueezy → Settings → Webhooks → Add webhook
- URL : `https://<projet-id>.supabase.co/functions/v1/lemonsqueezy-webhook`
- Secret : `<ton-secret>` (à mettre aussi dans `LEMONSQUEEZY_WEBHOOK_SECRET` côté Supabase)
- Events : `subscription_created`, `subscription_updated`, `subscription_cancelled`, `subscription_expired`

### Test E2E

1. Achat avec carte de test : `4242 4242 4242 4242`
2. Lemonsqueezy envoie webhook
3. Vérifier les logs Supabase : log positif ?
4. SQL : `SELECT * FROM subscriptions;` → ligne ajoutée
5. SQL : `SELECT id, is_premium FROM profiles WHERE id = '<userId>';` → `true`

### Cas où ça casse

- Webhook 401 : signature mauvaise → vérifier secret matchant
- Webhook 400 "Missing user_id" : tu n'as pas passé `checkout[custom][user_id]` à l'achat
- DB pas mis à jour : `--no-verify-jwt` oublié au déploiement

---

## Solution 04 — Build mobile

### Génération keystore

```bash
keytool -genkey -v -keystore release.keystore -alias release-key \
  -keyalg RSA -keysize 2048 -validity 10000

# Mots de passe : noter dans 1Password sous "Mon SaaS - Android Keystore"
# Backuper le fichier .keystore lui-même dans 2 endroits chiffrés
```

### `android/app/build.gradle` (signing)

```groovy
android {
    signingConfigs {
        release {
            storeFile file('../../release.keystore')
            keyAlias 'release-key'
            storePassword System.getenv('ANDROID_STORE_PASSWORD')
            keyPassword System.getenv('ANDROID_KEY_PASSWORD')
        }
    }
    buildTypes {
        release {
            signingConfig signingConfigs.release
            minifyEnabled false
        }
    }
}
```

### Build

```bash
ANDROID_STORE_PASSWORD=xxx ANDROID_KEY_PASSWORD=yyy ./gradlew bundleRelease
```

### Listing Play Console

- **Titre** : 30 caractères max
- **Description courte** : 80 caractères, vendeur (le hook)
- **Description longue** : 4000 caractères, structurée (problème, solution, bénéfices, fonctionnalités)
- **Captures** : 4-8 minimum, taille 1080×1920 ou similaire
- **Icône** : 512×512, fond opaque
- **Privacy URL** : doit pointer vers une vraie page hébergée

---

## Solution 05 — Audit sécurité

### Script d'audit complet

```bash
#!/bin/bash
# audit.sh

echo "=== Audit XSS ==="
rg -n 'innerHTML' src/ public/ | rg -v 'escapeHtml\|textContent'

echo "=== Audit secrets ==="
gitleaks detect --source . -v

echo "=== Audit RLS ==="
# Lance le SQL d'audit du module 08

echo "=== Headers prod ==="
curl -I https://tonsite.fr | grep -iE 'csp|x-frame|x-content|referrer'

echo "=== Edge functions ==="
ls supabase/functions/ | while read fn; do
  echo "Function: $fn"
  grep -l 'verifySignature\|verify_signature' "supabase/functions/$fn/" || echo "  WARNING: no signature verification found"
done
```

### Test "is_premium bloqué" en prod

Dans la console navigateur sur ton site déployé :

```js
const { error } = await supabase.from('profiles').update({ is_premium: true }).eq('id', currentUserId)
console.log({ blocked: error !== null, error })
```

Si `blocked: false`, **n'ouvre pas en public**, retourne au module 03.
