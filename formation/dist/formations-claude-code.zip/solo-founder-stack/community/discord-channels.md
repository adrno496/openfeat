# Structure Discord — Solo Founder Stack

Communauté de founders qui shippent. Pas de discussions théoriques.

---

## 👋 Bienvenue
- `#règles`
- `#présente-toi` (avec format imposé : projet, stack actuel, où tu en es dans ship)
- `#annonces`

## 🚀 Ship
- `#vos-projets` — montre ce que tu construis (URL ou capture obligatoire)
- `#shipping-this-week` — engagement public sur ce que tu vas ship cette semaine
- `#first-user` — célèbre tes 1ers users payants
- `#ship-stories` — post-mortem de ce qui a bien ou mal marché

## 📚 Formation
- `#questions-modules` — questions techniques sur les 10 modules
- `#questions-stack` — questions sur Vanilla / Capacitor / Supabase / Vercel / Lemonsqueezy / RevenueCat
- `#feedback-formation`

## 🛠 Tech entraide
- `#supabase-help`
- `#capacitor-help`
- `#paiements-help`
- `#deploiement-help`

## 📊 Business
- `#pricing-debat` — comment tu tarifes
- `#growth` — stratégies acquisition
- `#metrics` — partage chiffres anonymisés

## 💬 Off-topic
- `#café` — détendu, dev/startup
- `#stack-watch` — outils complémentaires (analytics, support, email marketing)

## 🔧 Support
- `#support-technique`
- `#support-direct` (privé)

---

## Règles spécifiques

- **Bienveillance**. Tout le monde est passé par "j'ai pas encore shippé".
- **Pas de promo agressive**. Tu peux mentionner ton projet, pas le spammer 5x par jour.
- **Pas de faux chiffres**. Si tu prétends faire 10k MRR, on le verra. Reste honnête.
- **Pas de DM spam**.
- **Pas de partage du contenu de la formation**.

## Ambiance

L'objectif : que chaque membre puisse dire à la fin "j'ai shippé grâce à ce groupe". Si le groupe devient un café à théoriser, il a échoué.

Hosts : 1 fois par mois, "ship retro" : qui a shippé quoi ce mois-ci ? Format 5 min/personne max.
