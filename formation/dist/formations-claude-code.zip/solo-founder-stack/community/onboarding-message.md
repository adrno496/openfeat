# Onboarding message — Solo Founder Stack

DM automatique aux nouveaux membres.

---

## Version DM

```
Salut [PRENOM] et bienvenue chez les founders de Solo Founder Stack.

Ici on ship. Pas de discussions théoriques sur "le meilleur framework". Tout le monde a un produit live ou en route.

3 étapes pour démarrer :
1. Lis #règles (l'esprit du groupe)
2. Présente-toi dans #présente-toi (format imposé)
3. Engage-toi dans #shipping-this-week sur ce que tu vas ship cette semaine

Pour les questions :
- #questions-modules pour la formation
- #questions-stack pour les outils
- #supabase-help, #capacitor-help, etc. pour tech ciblé

Pour célébrer tes wins : #first-user 🎉

Pas de DM directs au créateur — l'entraide passe par les canaux publics.

Ship,
[SIGNATURE]
```

---

## Template "présente-toi"

```
Prénom: [PRENOM]
Projet: [NOM_PROJET] ([URL si live]) — [domaine en 1 ligne]
Stack actuel: [ex: Vanilla JS + Capacitor + Supabase + RevenueCat]
Où j'en suis: [statut concret, ex: dev semaine 2, live depuis 1 mois, etc.]
Mon biggest blocker actuel: [un blocage concret]

Hâte d'échanger.
```

Format imposé pour éviter les "salut tout le monde, je suis là 👋" qui n'apportent rien.

---

## Notes

- Les nouveaux qui n'engage pas dans #shipping-this-week au bout d'1 semaine reçoivent un nudge gentil
- Les wins (first user payant, premier 1k MRR, etc.) sont mis en avant dans #annonces
- 1 ship retro mensuelle hosted (visio ou async)
