# Weekly Prompts — Solo Founder Stack

12 prompts hebdomadaires pour entretenir l'activité founders.

---

## S1 — Ton stack actuel
"Poste ton stack actuel (frontend, backend, paiements, deploy). Si c'est différent du Solo Founder Stack, dis pourquoi."

## S2 — Ton blocker #1
"Quel est ton biggest blocker cette semaine ? Code ? Sales ? Pricing ? Support ?"

## S3 — Ton CLAUDE.md
"Partage ton `CLAUDE.md` projet (anonymisé). Combien de lignes ? Plus utile section ?"

## S4 — Ton coût mensuel
"Coût mensuel total (infra + services + outils). On compare. On apprend."

## S5 — Ta première vente
"Raconte ta première vente : combien, quand, comment ? Ou si pas encore : où tu en es ?"

## S6 — Le bug en prod le plus mémorable
"Un bug en prod qui t'a marqué. Ce que tu as appris."

## S7 — Ton process de rollback
"Comment tu rollback en prod ? En combien de temps ? On compare."

## S8 — Ton ratio dev / non-dev
"Sur une semaine type, combien d'heures sur le dev pur vs sales/support/admin ?"

## S9 — Une feature que tu as shippée et qui s'est avérée inutile
"Tu as construit X. Personne ne l'a utilisée. Qu'est-ce que tu as appris ?"

## S10 — Ton stack auth
"Magic link ? Email/password ? OAuth ? Lequel et pourquoi ?"

## S11 — Ton expérience Lemonsqueezy
"Pour ceux en Lemonsqueezy : quelle setup ? Webhook events que tu écoutes ? Anomalies vues ?"

## S12 — Ship retro 30 jours
"Récap des 30 derniers jours. 3 wins. 3 blockers. 1 décision pour le mois prochain."

---

## Notes facilitation

- Prompt publié le lundi
- Le créateur poste sa propre réponse en exemple
- Le vendredi : mise en avant des 3 réponses les plus utiles
- Si participation faible (< 5 réponses) : nudge en DM des actifs habituels
