# 🚀 Solo Founder Stack

**Ship un SaaS production-ready en 30 jours avec Claude Code.**

Stack léger pour solo founder : Vanilla JS + Capacitor + Supabase + Vercel + Lemonsqueezy + RevenueCat. Coût d'infra dérisoire, time-to-ship court.

---

## Pour qui

Indie hackers, devs solo, créateurs de SaaS qui veulent shipper sans :
- s'enliser dans un framework JS lourd
- payer 200 €/mois en infra avant la première vente
- coder 6 mois avant d'avoir un user

---

## Ce que tu obtiens

- 9 modules pratiques (≈ 8h de contenu)
- Templates de projet vanilla JS + Capacitor + Supabase prêts à fork
- Scripts SQL pour la base (auth, paiements, RLS)
- CLAUDE.md production-ready
- Workflow Vercel + Play Store + RevenueCat + Lemonsqueezy
- Audit sécurité (CSP, XSS, RLS)
- Communauté de founders

---

## Structure

```
solo-founder-stack/
├── 00-syllabus.md
├── 01-positioning.md
├── modules/
├── exercises/
├── resources/
├── templates/
├── video-scripts/
├── marketing/
└── community/
```

---

## Prérequis

- Niveau dev intermédiaire (JS solide, bases SQL, terminal)
- Avoir suivi F6 (`vibe-coding-workflow/`) ou maîtriser Claude Code en pratique
- Avoir une idée de produit qu'on va shipper ensemble

---

## La promesse en chiffres

À la fin des 30 jours :
- App live (web + mobile si tu veux)
- Auth, paiements, base de données fonctionnels
- Premiers utilisateurs payants ou en bêta payante
- Coût infra mensuel < 30 € (pour < 1000 users actifs)
